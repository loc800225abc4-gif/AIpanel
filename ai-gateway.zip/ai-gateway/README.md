# AI Gateway - OpenAI Compatible Proxy

![Python](https://img.shields.io/badge/Python-3.12-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.115-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

A production-ready AI Gateway that acts as a proxy between your users and AI providers (OpenAI, DeepSeek, Claude, etc.). Your users **never see** real API keys, base URLs, or actual model names.

---

## Features

- 🔐 **Full API Key Hiding** - Users only use gateway keys (`sk-user-xxx`), never real provider keys
- 🔄 **Model Mapping** - `gpt-4` → `deepseek-ai/DeepSeek-V4` transparently
- 📊 **Admin Dashboard** - Beautiful Bootstrap 5 dark mode dashboard with statistics
- 🚦 **Rate Limiting** - Per-key RPM (requests per minute) and TPM (tokens per minute)
- 📈 **Quota Management** - Daily, monthly, token-based quotas per API key
- 📝 **Request Logging** - Full audit trail with search, pagination, CSV export
- 🔑 **API Key Management** - Create, lock, unlock, delete, copy keys
- 🌊 **Streaming Support** - Full SSE streaming proxy, just like OpenAI
- 🔗 **OpenAI Compatible** - Works with any OpenAI SDK client
- 🐳 **Docker Ready** - One command deployment
- 🛡️ **Security** - JWT auth, bcrypt passwords, CORS, security headers, no stack traces

## Architecture

```
Client (OpenAI SDK)
        |
        v
   AI Gateway (FastAPI)
        |
        ├── Auth: JWT + bcrypt (Admin Dashboard)
        ├── API Key Validation: sk-user-xxx
        ├── Model Mapping: gpt-4 → actual model
        ├── Rate Limiter: RPM / TPM
        ├── Quota Checker: daily/monthly/token
        ├── HTTPX Proxy → Real Provider
        └── Logging → SQLite
```

## Quick Start (Docker)

### Prerequisites
- Docker & Docker Compose installed
- Ubuntu 20.04+ (or any Linux with Docker)

### 1. Clone & Configure

```bash
git clone <your-repo> ai-gateway
cd ai-gateway
cp .env.example .env
```

### 2. Edit Environment (Optional)

```bash
nano .env
```

Default values:
```env
SECRET_KEY=change-me-to-a-random-secret-string
JWT_SECRET=change-me-jwt-secret-string
DATABASE_URL=sqlite+aiosqlite:///./data/gateway.db
HOST=0.0.0.0
PORT=8000
LOG_LEVEL=info
ENVIRONMENT=production
DEBUG=false
```

### 3. Start

```bash
docker compose up -d
```

### 4. Access
- **Dashboard**: http://your-server-ip:8000/dashboard
- **Default Login**: `admin` / `Loc12345s@`

## Manual Setup (Ubuntu)

### Prerequisites
```bash
sudo apt update
sudo apt install -y python3.12 python3.12-venv python3-pip
```

### Setup
```bash
cd ai-gateway
python3.12 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
mkdir -p data
python main.py
```

## Configuration

### Adding an AI Provider

1. Login to dashboard (`/dashboard`)
2. Navigate to **Providers** → **Add Provider**
3. Fill in:
   - **Name**: e.g., `DeepSeek Production`
   - **Base URL**: `https://api.deepseek.com/v1`
   - **API Key**: `sk-your-real-deepseek-api-key`
   - **Model**: `deepseek-ai/DeepSeek-V3`
   - **Timeout**: `120`
   - **Streaming**: ✓ Enabled
4. Optional: Add model mappings (`gpt-4` → actual model)

### Creating API Keys for Users

1. Navigate to **API Keys** → **Create API Key**
2. Set:
   - **Name**: e.g., `My App`
   - **Quota Type**: Unlimited / Daily / Monthly / Token
   - **Quota Limit**: e.g., 1000
   - **RPM**: e.g., 60
   - **TPM**: e.g., 100000

### Client Usage

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://your-server:8000/v1",
    api_key="sk-user-xxxxxxxxxxxxxxxxxxxxxxxx"
)

response = client.chat.completions.create(
    model="gpt-4",  # Mapped to whatever provider you configured
    messages=[{"role": "user", "content": "Hello!"}]
)
print(response.choices[0].message.content)
```

## API Endpoints

### OpenAI Compatible (`/v1`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/models` | List available models |
| POST | `/v1/chat/completions` | Chat completions |
| POST | `/v1/responses` | Responses |
| POST | `/v1/embeddings` | Embeddings |
| POST | `/v1/images/generations` | Image generation |

### Management (`/api/management`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/management/providers` | Create provider |
| GET | `/api/management/providers` | List providers |
| GET | `/api/management/providers/{id}` | Get provider details |
| PUT | `/api/management/providers/{id}` | Update provider |
| DELETE | `/api/management/providers/{id}` | Delete provider |
| POST | `/api/management/apikeys` | Create API key |
| GET | `/api/management/apikeys` | List API keys |
| DELETE | `/api/management/apikeys/{id}` | Delete API key |
| POST | `/api/management/apikeys/{id}/toggle-lock` | Lock/unlock key |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| SECRET_KEY | (required) | Flask session secret |
| JWT_SECRET | (required) | JWT signing key |
| DATABASE_URL | sqlite+aiosqlite:///./data/gateway.db | Database URL |
| HOST | 0.0.0.0 | Bind address |
| PORT | 8000 | Bind port |
| LOG_LEVEL | info | Logging level |
| ENVIRONMENT | production | Environment name |
| DEBUG | false | Debug mode |

## Security

- ✅ Real API keys stored encrypted in database
- ✅ Passwords hashed with bcrypt
- ✅ JWT authentication for dashboard
- ✅ Security headers (X-Content-Type-Options, X-Frame-Options, etc.)
- ✅ CORS configured
- ✅ No stack traces in production errors
- ✅ No default API docs exposed
- ✅ API key format: `sk-user-{random}` (no real key exposure)
- ✅ Server info hidden

## Production Notes

1. **Change default password** immediately after first login
2. **Use strong SECRET_KEY and JWT_SECRET** in `.env`
3. **Use PostgreSQL** for production (change `DATABASE_URL`):
   ```
   DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/dbname
   ```
4. **Use reverse proxy** (nginx/caddy) with HTTPS
5. **Enable firewall** and only expose port 443/80

## Project Structure

```
ai-gateway/
├── main.py                 # Application entry point
├── requirements.txt        # Python dependencies
├── Dockerfile              # Docker build
├── docker-compose.yml      # Docker deployment
├── .env                    # Environment variables
├── README.md               # This file
├── data/                   # SQLite database (persisted)
├── static/                 # Static assets
├── templates/              # Jinja2 HTML templates
│   ├── base.html           # Base layout with sidebar
│   ├── login.html          # Login page
│   ├── dashboard.html      # Admin dashboard
│   ├── providers.html      # Provider management
│   ├── api_keys.html       # API key management
│   └── logs.html           # Request logs
└── app/
    ├── config.py           # Settings & config
    ├── api/                # API route handlers
    │   ├── auth_routes.py
    │   ├── dashboard_routes.py
    │   ├── management_routes.py
    │   └── proxy_routes.py
    ├── auth/               # Authentication
    │   └── security.py
    ├── database/           # Database layer
    │   ├── base.py
    │   └── session.py
    ├── models/             # SQLAlchemy models
    │   └── models.py
    ├── schemas/            # Pydantic schemas
    │   └── schemas.py
    ├── services/           # Business logic
    │   ├── apikey_service.py
    │   ├── dashboard_service.py
    │   ├── log_service.py
    │   ├── provider_service.py
    │   └── proxy_service.py
    ├── middleware/         # HTTP middleware
    │   └── middleware.py
    └── dashboard/          # Template engine
        └── templates.py
```

## License

MIT