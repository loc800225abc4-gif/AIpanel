"""Security utilities: password hashing, JWT creation/verification."""

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database.session import get_async_session
from app.models.models import AdminUser

# Password hashing context using bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Cookie name for dashboard session
COOKIE_NAME = "ai_gateway_session"

# Bearer token scheme for API
bearer_scheme = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash."""
    return pwd_context.verify(plain_password, hashed_password)


def hash_api_key(api_key: str) -> str:
    """Create a SHA256 hash of an API key for fast prefix lookup."""
    return hashlib.sha256(api_key[:32].encode()).hexdigest()


def hash_full_api_key(api_key: str) -> str:
    """Create a bcrypt hash of the full API key for secure verification."""
    return pwd_context.hash(api_key)


def verify_api_key_hash(api_key: str, hashed: str) -> bool:
    """Verify an API key against its bcrypt hash."""
    return pwd_context.verify(api_key, hashed)


import logging

logger = logging.getLogger(__name__)


async def seed_default_admin(session: AsyncSession) -> None:
    """Create default admin user if not exists."""
    from sqlalchemy import select

    result = await session.execute(
        select(AdminUser).where(AdminUser.username == settings.admin_username)
    )
    existing_admin = result.scalar_one_or_none()

    if existing_admin is None:
        admin = AdminUser(
            username=settings.admin_username,
            password_hash=hash_password(settings.admin_password),
            is_active=True,
        )
        session.add(admin)
        await session.commit()
        logger.info(f"Default admin user '{settings.admin_username}' created.")
    else:
        logger.info(f"Admin user '{settings.admin_username}' already exists.")


def generate_api_key() -> str:
    """Generate a user API key in format: sk-user-{random_hex}."""
    random_part = secrets.token_hex(24)  # 48 hex chars
    return f"sk-user-{random_part}"


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.jwt_expiration_minutes
        )
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(
        to_encode, settings.jwt_secret, algorithm=settings.jwt_algorithm
    )
    return encoded_jwt


def decode_access_token(token: str) -> Optional[dict]:
    """Decode and validate a JWT access token."""
    try:
        payload = jwt.decode(
            token, settings.jwt_secret, algorithms=[settings.jwt_algorithm]
        )
        return payload
    except JWTError:
        return None


async def get_current_user_from_cookie(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
) -> AdminUser:
    """Extract current admin user from session cookie."""
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"X-Redirect": "/login"},
        )

    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"X-Redirect": "/login"},
        )

    username: Optional[str] = payload.get("sub")
    if username is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )

    result = await session.execute(
        select(AdminUser).where(AdminUser.username == username)
    )
    user = result.scalar_one_or_none()

    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    return user


async def get_current_user(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
) -> AdminUser:
    """Get current user from cookie (for dashboard) or bearer token (for API)."""
    # Try cookie first (for dashboard)
    token = request.cookies.get(COOKIE_NAME)
    if token:
        payload = decode_access_token(token)
        if payload:
            username = payload.get("sub")
            if username:
                result = await session.execute(
                    select(AdminUser).where(AdminUser.username == username)
                )
                user = result.scalar_one_or_none()
                if user and user.is_active:
                    return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
    )