"""Application configuration loaded from environment variables."""

import os
from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application
    app_name: str = "AI Gateway"
    app_version: str = "1.0.0"
    debug: bool = False

    # Security
    secret_key: str = "change-this-secret-key"
    jwt_secret: str = "change-this-jwt-secret"
    jwt_algorithm: str = "HS256"
    jwt_expiration_minutes: int = 480  # 8 hours

    # Database
    database_url: str = "sqlite+aiosqlite:///./data/gateway.db"
    sync_database_url: str = "sqlite:///./data/gateway.db"

    # Server
    host: str = "0.0.0.0"
    port: int = 8000

    # Admin defaults
    admin_username: str = "admin"
    admin_password: str = "Loc12345s@"

    # Logging
    log_level: str = "info"

    # Rate Limiting
    rate_limit_enabled: bool = True
    rate_limit_default: str = "100/minute"

    # Proxy
    proxy_timeout: int = 120

    BASE_DIR: Path = Path(__file__).resolve().parent.parent

    environment: str = "production"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()