"""SQLAlchemy declarative base and table creation."""

from sqlalchemy.orm import DeclarativeBase

from app.database.session import async_engine


class Base(DeclarativeBase):
    """Base class for all database models."""
    pass


async def create_tables() -> None:
    """Create all database tables if they don't exist."""
    from app.models.models import AdminUser, Provider, ModelMapping, APIKey, RequestLog  # noqa: F401

    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
