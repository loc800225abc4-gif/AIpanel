"""Database session management for SQLAlchemy with async support."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.config import settings

# Async engine for FastAPI
async_engine = create_async_engine(
    settings.database_url,
    echo=False,
    future=True,
)

# Thêm dòng này
engine = async_engine

# Sync engine for Alembic and seed data
sync_engine = create_engine(
    settings.sync_database_url,
    echo=False,
)

# Session factories
async_session_factory = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

sync_session_factory = sessionmaker(
    sync_engine,
    expire_on_commit=False,
)


@asynccontextmanager
async def get_session_context():
    """Async context manager that provides a database session for startup tasks."""
    session = async_session_factory()
    try:
        yield session
    finally:
        await session.close()


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency that provides an async database session."""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()