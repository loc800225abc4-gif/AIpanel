"""All SQLAlchemy database models for the AI Gateway."""

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


def generate_uuid() -> str:
    """Generate a UUID4 string."""
    return str(uuid.uuid4())


def utcnow() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


class AdminUser(Base):
    """Admin user for dashboard authentication."""

    __tablename__ = "admin_users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    def __repr__(self) -> str:
        return f"<AdminUser(id={self.id}, username='{self.username}')>"


class Provider(Base):
    """AI Provider configuration."""

    __tablename__ = "providers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    base_url: Mapped[str] = mapped_column(String(500), nullable=False)
    api_key: Mapped[str] = mapped_column(Text, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    timeout: Mapped[int] = mapped_column(Integer, default=120)
    verify_ssl: Mapped[bool] = mapped_column(Boolean, default=True)
    supports_streaming: Mapped[bool] = mapped_column(Boolean, default=True)
    health_status: Mapped[str] = mapped_column(String(50), default="unknown")  # unknown, healthy, unhealthy
    last_checked: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    # Relationships
    model_mappings: Mapped[list["ModelMapping"]] = relationship(
        "ModelMapping", back_populates="provider", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Provider(id={self.id}, name='{self.name}')>"


class ModelMapping(Base):
    """Mapping between user-facing model names and actual provider models."""

    __tablename__ = "model_mappings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    provider_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("providers.id", ondelete="CASCADE"), nullable=False
    )
    external_model: Mapped[str] = mapped_column(
        String(200), nullable=False, comment="Model name exposed to clients (e.g., gpt-4)"
    )
    actual_model: Mapped[str] = mapped_column(
        String(200), nullable=False, comment="Actual model name on the provider (e.g., deepseek-ai/DeepSeek-V4-Pro)"
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow
    )

    # Relationships
    provider: Mapped["Provider"] = relationship("Provider", back_populates="model_mappings")

    def __repr__(self) -> str:
        return (
            f"<ModelMapping(id={self.id}, "
            f"external='{self.external_model}' -> actual='{self.actual_model}')>"
        )


class APIKey(Base):
    """User API keys for gateway access."""

    __tablename__ = "api_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    key_hash: Mapped[str] = mapped_column(
        String(255), nullable=False, index=True,
        comment="SHA256 hash of the API key prefix for fast lookup"
    )
    key_prefix: Mapped[str] = mapped_column(
        String(20), nullable=False, index=True,
        comment="First 8 chars of the API key for display (sk-user-)"
    )
    key_suffix: Mapped[str] = mapped_column(
        String(10), nullable=False,
        comment="Last 4 chars for display"
    )
    full_key_hash: Mapped[str] = mapped_column(
        String(255), nullable=False, unique=True,
        comment="Full bcrypt hash of the complete key for verification"
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_locked: Mapped[bool] = mapped_column(Boolean, default=False)

    # Quota
    quota_type: Mapped[str] = mapped_column(
        String(20), default="unlimited",
        comment="Quota type: unlimited, daily, monthly, total_tokens"
    )
    quota_value: Mapped[int] = mapped_column(Integer, default=0)
    quota_used: Mapped[int] = mapped_column(Integer, default=0)
    quota_reset_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Rate limiting
    rpm_limit: Mapped[int] = mapped_column(
        Integer, default=0, comment="Requests per minute, 0 = unlimited"
    )
    tpm_limit: Mapped[int] = mapped_column(
        Integer, default=0, comment="Tokens per minute, 0 = unlimited"
    )

    # Expiry
    expires_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Usage tracking
    last_used_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_used_ip: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    total_requests: Mapped[int] = mapped_column(Integer, default=0)
    total_prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )

    def __repr__(self) -> str:
        return f"<APIKey(id={self.id}, name='{self.name}', active={self.is_active})>"


class RequestLog(Base):
    """Detailed request log for monitoring and analytics."""

    __tablename__ = "request_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[str] = mapped_column(String(100), index=True)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, index=True
    )
    ip_address: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    api_key_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
    api_key_name: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    endpoint: Mapped[str] = mapped_column(String(200), nullable=False, index=True)
    method: Mapped[str] = mapped_column(String(10), nullable=False)
    external_model: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    actual_model: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    provider_name: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    latency_ms: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    status_code: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_streaming: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow
    )

    def __repr__(self) -> str:
        return f"<RequestLog(id={self.id}, endpoint='{self.endpoint}', status={self.status_code})>"