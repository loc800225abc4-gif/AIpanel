"""Authentication routes for dashboard login/logout."""

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import RedirectResponse, JSONResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database.session import get_async_session
from app.models.models import AdminUser
from app.auth.security import (
    hash_password,
    verify_password,
    create_access_token,
    decode_access_token,
    get_current_user_from_cookie,
    COOKIE_NAME,
)
from app.schemas.schemas import LoginRequest, TokenResponse, AdminUserResponse

router = APIRouter(tags=["auth"])


@router.post("/api/auth/login", response_model=TokenResponse)
async def login(
    data: LoginRequest,
    session: AsyncSession = Depends(get_async_session),
):
    """Authenticate admin user and return JWT token."""
    result = await session.execute(
        select(AdminUser).where(AdminUser.username == data.username)
    )
    user = result.scalar_one_or_none()

    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    if not verify_password(data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    expires_delta = timedelta(minutes=settings.jwt_expiration_minutes)
    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=expires_delta,
    )

    response = TokenResponse(
        access_token=access_token,
        token_type="bearer",
        username=user.username,
        expires_in=settings.jwt_expiration_minutes * 60,
    )

    return response


@router.post("/auth/login")
async def dashboard_login(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
):
    """Dashboard login handler - sets cookie and redirects."""
    form_data = await request.form()
    username = form_data.get("username", "")
    password = form_data.get("password", "")

    result = await session.execute(
        select(AdminUser).where(AdminUser.username == username)
    )
    user = result.scalar_one_or_none()

    if user is None or not user.is_active:
        return RedirectResponse(
            url="/login?error=1",
            status_code=status.HTTP_302_FOUND,
        )

    if not verify_password(password, user.password_hash):
        return RedirectResponse(
            url="/login?error=1",
            status_code=status.HTTP_302_FOUND,
        )

    expires_delta = timedelta(minutes=settings.jwt_expiration_minutes)
    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=expires_delta,
    )

    response = RedirectResponse(
        url="/dashboard",
        status_code=status.HTTP_302_FOUND,
    )
    response.set_cookie(
        key=COOKIE_NAME,
        value=access_token,
        httponly=True,
        max_age=settings.jwt_expiration_minutes * 60,
        samesite="lax",
        secure=False,  # Set to True in production with HTTPS
    )
    return response


@router.get("/auth/logout")
async def dashboard_logout():
    """Logout handler - clears cookie."""
    response = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    response.delete_cookie(COOKIE_NAME)
    return response


@router.get("/api/auth/me", response_model=AdminUserResponse)
async def get_current_user_info(
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Get current authenticated user info."""
    return AdminUserResponse(
        id=user.id,
        username=user.username,
        is_active=user.is_active,
        created_at=user.created_at,
    )