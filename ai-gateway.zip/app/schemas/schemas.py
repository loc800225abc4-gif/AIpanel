"""Pydantic schemas for all API request/response validation."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


# ─── Auth Schemas ────────────────────────────────────────────────────────────


class LoginRequest(BaseModel):
    """Login request body."""
    username: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=1, max_length=255)


class TokenResponse(BaseModel):
    """JWT token response."""
    access_token: str
    token_type: str = "bearer"
    username: str
    expires_in: int


class AdminUserResponse(BaseModel):
    """Admin user info."""
    id: int
    username: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ─── Provider Schemas ────────────────────────────────────────────────────────


class ProviderCreate(BaseModel):
    """Create a new AI provider."""
    name: str = Field(..., min_length=1, max_length=200)
    base_url: str = Field(..., min_length=1, max_length=500)
    api_key: str = Field(..., min_length=1)
    timeout: int = Field(default=120, ge=1, le=600)
    verify_ssl: bool = True
    supports_streaming: bool = True
    is_active: bool = True


class ProviderUpdate(BaseModel):
    """Update an existing provider."""
    name: Optional[str] = Field(None, max_length=200)
    base_url: Optional[str] = Field(None, max_length=500)
    api_key: Optional[str] = None
    timeout: Optional[int] = Field(None, ge=1, le=600)
    verify_ssl: Optional[bool] = None
    supports_streaming: Optional[bool] = None
    is_active: Optional[bool] = None


class ModelMappingResponse(BaseModel):
    """Model mapping response."""
    id: int
    external_model: str
    actual_model: str
    is_active: bool
    provider_id: int

    class Config:
        from_attributes = True


class ProviderResponse(BaseModel):
    """Provider response (without the real API key)."""
    id: int
    name: str
    base_url: str
    api_key: str  # Will be masked in the service layer
    timeout: int
    verify_ssl: bool
    supports_streaming: bool
    is_active: bool
    health_status: str
    last_checked: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    model_mappings: List[ModelMappingResponse] = []

    class Config:
        from_attributes = True


class ModelMappingCreate(BaseModel):
    """Create a model mapping."""
    external_model: str = Field(..., min_length=1, max_length=200)
    actual_model: str = Field(..., min_length=1, max_length=200)
    is_active: bool = True


# ─── API Key Schemas ─────────────────────────────────────────────────────────


class APIKeyCreate(BaseModel):
    """Create a new API key."""
    name: str = Field(..., min_length=1, max_length=200)
    quota_type: str = Field(
        default="unlimited",
        pattern="^(unlimited|daily|monthly|total_tokens)$"
    )
    quota_value: int = Field(default=0, ge=0)
    rpm_limit: int = Field(default=0, ge=0, description="Requests per minute, 0=unlimited")
    tpm_limit: int = Field(default=0, ge=0, description="Tokens per minute, 0=unlimited")
    expires_at: Optional[datetime] = None


class APIKeyUpdate(BaseModel):
    """Update an existing API key."""
    name: Optional[str] = Field(None, max_length=200)
    is_active: Optional[bool] = None
    is_locked: Optional[bool] = None
    quota_type: Optional[str] = Field(None, pattern="^(unlimited|daily|monthly|total_tokens)$")
    quota_value: Optional[int] = Field(None, ge=0)
    rpm_limit: Optional[int] = Field(None, ge=0)
    tpm_limit: Optional[int] = Field(None, ge=0)
    expires_at: Optional[datetime] = None


class APIKeyResponse(BaseModel):
    """API key response (the full key is only shown once at creation)."""
    id: int
    name: str
    key_display: str = ""  # e.g., "sk-user-abc123...wxyz"
    is_active: bool
    is_locked: bool
    quota_type: str
    quota_value: int
    quota_used: int
    rpm_limit: int
    tpm_limit: int
    expires_at: Optional[datetime] = None
    last_used_at: Optional[datetime] = None
    last_used_ip: Optional[str] = None
    total_requests: int
    total_prompt_tokens: int
    total_completion_tokens: int
    total_tokens: int
    created_at: datetime

    class Config:
        from_attributes = True


class APIKeyCreateResponse(BaseModel):
    """Response after creating an API key, includes the full key once."""
    id: int
    name: str
    api_key: str  # Full key, only shown once
    key_display: str
    created_at: datetime


# ─── Request Log Schemas ─────────────────────────────────────────────────────


class RequestLogResponse(BaseModel):
    """Request log entry."""
    id: int
    request_id: str
    timestamp: datetime
    ip_address: Optional[str] = None
    api_key_name: Optional[str] = None
    endpoint: str
    method: str
    external_model: Optional[str] = None
    actual_model: Optional[str] = None
    provider_name: Optional[str] = None
    latency_ms: Optional[float] = None
    status_code: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    error_message: Optional[str] = None
    is_streaming: bool

    class Config:
        from_attributes = True


# ─── Dashboard Schemas ───────────────────────────────────────────────────────


class DashboardStats(BaseModel):
    """Dashboard statistics."""
    total_api_keys: int
    active_api_keys: int
    requests_today: int
    total_requests: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    avg_latency_ms: float
    providers_count: int
    active_providers: int
    healthy_providers: int


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = "healthy"
    version: str
    uptime: float

class MessageResponse(BaseModel):
    success: bool = True
    message: str