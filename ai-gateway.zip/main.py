"""AI Gateway - Main Application Entry Point.

Production-ready AI Gateway that proxies requests to configured AI providers.
Users never see real API keys, base URLs, or model names.
"""

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database.base import create_tables
from app.database.session import get_session_context
from app.auth.security import seed_default_admin
from app.api.auth_routes import router as auth_router
from app.api.dashboard_routes import router as dashboard_router
from app.api.management_routes import router as management_router
from app.api.proxy_routes import router as proxy_router
from app.middleware.middleware import (
    SecurityHeadersMiddleware,
    ExceptionHandlerMiddleware,
    RequestLoggingMiddleware,
)

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown events."""
    # Startup
    logger.info("Starting AI Gateway...")
    logger.info(f"Environment: {settings.environment}")

    # Create database tables
    await create_tables()
    logger.info("Database tables verified.")

    # Seed default admin user
    async with get_session_context() as session:
        await seed_default_admin(session)

    logger.info("AI Gateway started successfully.")

    yield

    # Shutdown
    logger.info("Shutting down AI Gateway...")


def create_application() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Production AI Gateway - OpenAI Compatible Proxy",
        docs_url=None,  # Disable default Swagger (security)
        redoc_url=None,  # Disable default ReDoc (security)
        openapi_url=None,  # Disable OpenAPI schema (security)
        lifespan=lifespan,
    )

    # Add CORS middleware (must be added first for preflight requests)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Add custom middleware (order matters - last added runs first)
    app.add_middleware(ExceptionHandlerMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestLoggingMiddleware)

    # Mount static files
    static_dir = settings.BASE_DIR / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Include routers
    app.include_router(auth_router)
    app.include_router(dashboard_router)
    app.include_router(management_router)
    app.include_router(proxy_router)

    # Health check endpoint
    @app.get("/health", include_in_schema=False)
    async def health_check():
        """Health check for load balancers."""
        return {
            "status": "healthy",
            "app": settings.app_name,
            "version": settings.app_version,
            "environment": settings.environment,
        }

    return app


# Create the application instance
app = create_application()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level=settings.log_level,
    )