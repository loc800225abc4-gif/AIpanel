<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

// Auto-migrate: add missing columns to chat_history
$db = getDB();
if ($db) {
    @$db->query("ALTER TABLE chat_history ADD COLUMN session_id VARCHAR(64) DEFAULT NULL AFTER user_id");
    @$db->query("ALTER TABLE chat_history ADD COLUMN model_id INT DEFAULT NULL AFTER session_id");
    @$db->query("ALTER TABLE chat_history ADD COLUMN tokens_prompt INT NOT NULL DEFAULT 0 AFTER content");
    @$db->query("ALTER TABLE chat_history ADD COLUMN tokens_completion INT NOT NULL DEFAULT 0 AFTER tokens_prompt");
    @$db->query("ALTER TABLE chat_history ADD COLUMN response_time_ms INT DEFAULT NULL AFTER tokens_total");
    @$db->query("ALTER TABLE users ADD COLUMN api_key VARCHAR(64) DEFAULT NULL AFTER credits");
    @$db->query("ALTER TABLE users ADD UNIQUE INDEX idx_api_key (api_key)");
}

// Vệ sinh output buffer
while (ob_get_level()) { ob_end_clean(); }
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Parse input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$message = trim($input['message'] ?? '');
$modelId = intval($input['model_id'] ?? 0);
$sessionId = $input['session_id'] ?? generateUUID();
$stream = !empty($input['stream']);
$images = $input['images'] ?? [];
$images = is_array($images) ? $images : [];
$files = $input['files'] ?? [];
$files = is_array($files) ? $files : [];

// Auth check
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Vui lòng đăng nhập để sử dụng AI']);
    exit;
}

// Allow empty message only if images or files present
if (empty($message) && empty($images) && empty($files)) {
    echo json_encode(['error' => 'Message is empty']);
    exit;
}

$user = getUser();
if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'User not found']);
    exit;
}

// Build file content ONLY for current message (not history)
$fileContent = '';
if (!empty($files)) {
    $fileContent = "The user has uploaded the following file(s). Use this content to answer their questions:\n\n";
    foreach ($files as $file) {
        $fileName = $file['name'] ?? 'unknown';
        $fileText = $file['content'] ?? '';
        $fileContent .= "--- FILE: {$fileName} ---\n{$fileText}\n\n";
    }
    $fileContent .= "--- END OF FILES ---\n\n";
}
$currentMessage = $fileContent . $message;

// Load chat history for context (isolated by user_id + session_id — no cross-contamination)
$history = loadChatHistory($user['id'], $sessionId, 20);

// Build messages array: history + current message
$messages = $history;
if (!empty($images)) {
    $lastContent = [];
    if (!empty($currentMessage)) {
        $lastContent[] = ['type' => 'text', 'text' => $currentMessage];
    }
    foreach ($images as $url) {
        $lastContent[] = ['type' => 'image_url', 'image_url' => ['url' => $url]];
    }
    $messages[] = ['role' => 'user', 'content' => $lastContent];
} else {
    $messages[] = ['role' => 'user', 'content' => $currentMessage];
}

$model = getModelById($modelId);
if (!$model) {
    $defaultModelId = intval(getSetting('default_model', 1));
    $model = getModelById($defaultModelId);
    if (!$model) {
        $activeModels = getActiveModels();
        if (!empty($activeModels)) {
            $model = $activeModels[0];
        }
    }
    if (!$model) {
        echo json_encode(['error' => 'Không tìm thấy model AI. Vui lòng vào admin panel để thêm model.']);
        exit;
    }
}

$baseUrl = $model['base_url'] ?: getSetting('base_url', 'https://api.openai.com');
$apiKey = $model['api_key'] ?: getSetting('api_key', '');
$modelIdStr = $model['model_id'];
$maxTokens = intval($model['max_tokens'] ?: 4096);
$temperature = floatval($model['temperature'] ?: 0.7);

// Cost estimation (include full messages context + history)
$allContent = '';
foreach ($messages as $msg) {
    $allContent .= is_string($msg['content']) ? $msg['content'] : json_encode($msg['content']);
}
$estimatedTokens = ceil(strlen($allContent) / 3) + 500;
$creditsPerToken = floatval(getSetting('credits_per_token', '0.001'));
$estimatedCost = ceil($estimatedTokens * $creditsPerToken);

if ($user['credits'] < $estimatedCost) {
    echo json_encode(['error' => 'Không đủ credits. Bạn cần ' . $estimatedCost . ' credits. Hiện có: ' . $user['credits']]);
    exit;
}

// Save user message
$userTokens = ceil(strlen($message) / 3);
try {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt) VALUES (?, ?, ?, 'user', ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isisi", $user['id'], $sessionId, $model['id'], $message, $userTokens);
        $stmt->execute();
    }
} catch (Exception $e) {}

// Call AI API
$startTime = microtime(true);

if ($stream) {
    // ========== STREAMING ==========
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');

    deductCredits($user['id'], $estimatedCost, "Chat (stream) with {$model['name']}");

    $fullText = callAIStream($baseUrl, $apiKey, $modelIdStr, $messages, $maxTokens, $temperature, function($chunk) {
        echo "data: " . json_encode(['delta' => $chunk], JSON_UNESCAPED_UNICODE) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
    });

    $responseTimeMs = round((microtime(true) - $startTime) * 1000);

    if ($fullText === null) {
        echo "data: " . json_encode(['error' => 'Không thể kết nối đến AI server']) . "\n\n";
        if (ob_get_level()) ob_flush(); flush();
        exit;
    }

    $outputTokens = ceil(strlen($fullText) / 3);
    $totalTokens = $userTokens + $outputTokens;
    $actualCost = ceil($totalTokens * $creditsPerToken);

    $diff = $actualCost - $estimatedCost;
    if ($diff > 0) {
        deductCredits($user['id'], $diff, "Chat (stream) adjustment {$model['name']}");
    } elseif ($diff < 0) {
        $db = getDB();
        if ($db) {
            $refund = abs($diff);
            $db->query("UPDATE users SET credits = credits + {$refund} WHERE id = " . intval($user['id']));
            $db->query("INSERT INTO credit_logs (user_id, amount, type, description) VALUES (" . intval($user['id']) . ", {$refund}, 'refund', 'Stream refund " . $model['name'] . "')");
        }
    }

    try {
        $stmt = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt, tokens_completion, tokens_total, response_time_ms) VALUES (?, ?, ?, 'assistant', ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("isisiiii", $user['id'], $sessionId, $model['id'], $fullText, $userTokens, $outputTokens, $totalTokens, $responseTimeMs);
            $stmt->execute();
        }
    } catch (Exception $e) {}

    logUsage($user['id'], null, $model['model_id'], $model['provider'], 'chat', $userTokens, $outputTokens, $actualCost, $actualCost, 'success', $responseTimeMs, $_SERVER['REMOTE_ADDR'] ?? '');

    echo "data: " . json_encode([
        'done' => true,
        'model' => $model['name'],
        'tokens' => $totalTokens,
        'credits_used' => $actualCost,
        'credits_remaining' => $user['credits'] - $diff,
        'response_time_ms' => $responseTimeMs
    ], JSON_UNESCAPED_UNICODE) . "\n\n";

    if (ob_get_level()) ob_flush();
    flush();
    exit;
} else {
    // ========== NORMAL ==========
    $response = callAI($baseUrl, $apiKey, $modelIdStr, $messages, $maxTokens, $temperature);
    $responseTimeMs = round((microtime(true) - $startTime) * 1000);

    if ($response === null) {
        echo json_encode(['error' => 'Không thể kết nối đến AI server.']);
        exit;
    }

    $responseText = $response['choices'][0]['message']['content'] ?? '';
    $inputTokens = $response['usage']['prompt_tokens'] ?? $userTokens;
    $outputTokens = $response['usage']['completion_tokens'] ?? ceil(strlen($responseText) / 3);
    $totalTokens = $inputTokens + $outputTokens;
    $actualCost = ceil($totalTokens * $creditsPerToken);

    deductCredits($user['id'], $actualCost, "Chat with {$model['name']}");

    try {
        $stmt = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt, tokens_completion, tokens_total, response_time_ms) VALUES (?, ?, ?, 'assistant', ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("isisiiii", $user['id'], $sessionId, $model['id'], $responseText, $inputTokens, $outputTokens, $totalTokens, $responseTimeMs);
            $stmt->execute();
        }
    } catch (Exception $e) {}

    logUsage($user['id'], null, $model['model_id'], $model['provider'], 'chat', $inputTokens, $outputTokens, $actualCost, $actualCost, 'success', $responseTimeMs, $_SERVER['REMOTE_ADDR'] ?? '');

    echo json_encode([
        'response' => $responseText,
        'model' => $model['name'],
        'tokens' => $totalTokens,
        'credits_used' => $actualCost,
        'credits_remaining' => $user['credits'] - $actualCost,
        'response_time_ms' => $responseTimeMs
    ]);
}

// ========== FUNCTIONS ==========

/**
 * Load chat history for a specific user + session.
 * ISOLATED: WHERE user_id = ? AND session_id = ? ensures no cross-session contamination.
 */
function loadChatHistory($userId, $sessionId, $limit = 20) {
    $db = getDB();
    $stmt = $db->prepare("SELECT role, content FROM chat_history WHERE user_id = ? AND session_id = ? AND role IN ('user', 'assistant') ORDER BY id ASC LIMIT ?");
    if (!$stmt) return [];
    $stmt->bind_param("isi", $userId, $sessionId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $history = [];
    while ($row = $result->fetch_assoc()) {
        $history[] = ['role' => $row['role'], 'content' => $row['content']];
    }
    return $history;
}

function callAI($baseUrl, $apiKey, $model, $messages, $maxTokens, $temperature) {
    $url = rtrim($baseUrl, '/') . '/v1/chat/completions';

    $payload = json_encode([
        'model' => $model,
        'messages' => $messages,
        'max_tokens' => $maxTokens,
        'temperature' => $temperature,
        'stream' => false
    ]);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey
        ],
        CURLOPT_TIMEOUT => 120,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0
    ]);

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        error_log('AI API cURL error: ' . $error);
        return null;
    }

    $data = json_decode($result, true);

    if ($httpCode !== 200 || isset($data['error'])) {
        error_log("AI API error: HTTP $httpCode, message: " . ($data['error']['message'] ?? 'Unknown'));
        return null;
    }

    if (empty($data['choices'][0]['message']['content'])) {
        error_log('AI API: unexpected response structure');
        return null;
    }

    return $data;
}

function callAIStream($baseUrl, $apiKey, $model, $messages, $maxTokens, $temperature, $onDelta) {
    $url = rtrim($baseUrl, '/') . '/v1/chat/completions';

    $payload = json_encode([
        'model' => $model,
        'messages' => $messages,
        'max_tokens' => $maxTokens,
        'temperature' => $temperature,
        'stream' => true
    ]);

    $fullText = '';
    $buffer = '';

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'Accept: text/event-stream'
        ],
        CURLOPT_TIMEOUT => 120,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_WRITEFUNCTION => function($ch, $data) use ($onDelta, &$fullText, &$buffer) {
            $buffer .= $data;
            while (($pos = strpos($buffer, "\n")) !== false) {
                $line = substr($buffer, 0, $pos);
                $buffer = substr($buffer, $pos + 1);

                if (strpos($line, 'data: ') === 0) {
                    $json = substr($line, 6);
                    if ($json === '[DONE]') continue;

                    $chunk = json_decode($json, true);
                    $delta = $chunk['choices'][0]['delta']['content'] ?? '';
                    if ($delta !== '') {
                        $fullText .= $delta;
                        $onDelta($delta);
                    }
                }
            }
            return strlen($data);
        }
    ]);

    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        error_log('AI API stream cURL error: ' . $error);
        return null;
    }

    if ($httpCode !== 200) {
        error_log("AI API stream error: HTTP $httpCode");
        return null;
    }

    if (empty($fullText)) {
        error_log('AI API stream: no content received');
        return null;
    }

    return $fullText;
}