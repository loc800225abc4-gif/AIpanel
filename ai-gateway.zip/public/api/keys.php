<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

while (ob_get_level()) { ob_end_clean(); }
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// Auth
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Vui lòng đăng nhập']);
    exit;
}

$user = getUser();
$userId = $user['id'];
$db = getDB();

// Ensure table exists
@$db->query("CREATE TABLE IF NOT EXISTS user_api_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) DEFAULT NULL,
    api_key VARCHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // List user's API keys
    $result = $db->query("SELECT id, name, api_key, created_at FROM user_api_keys WHERE user_id = $userId ORDER BY created_at DESC");
    $keys = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) { $keys[] = $row; }
    }
    echo json_encode(['success' => true, 'keys' => $keys, 'max' => 5, 'count' => count($keys)]);
    exit;
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $name = trim($input['name'] ?? '');

    if (empty($name)) {
        echo json_encode(['success' => false, 'error' => 'Vui lòng nhập tên key']);
        exit;
    }

    // Check limit
    $countResult = $db->query("SELECT COUNT(*) as cnt FROM user_api_keys WHERE user_id = $userId");
    $cnt = $countResult->fetch_assoc()['cnt'] ?? 0;
    if ($cnt >= 5) {
        echo json_encode(['success' => false, 'error' => 'Tối đa 5 API key']);
        exit;
    }

    // Use the standardized generateApiKey() function (loc_sk_ prefix)
    $apiKey = generateApiKey();
    $stmt = $db->prepare("INSERT INTO user_api_keys (user_id, name, api_key) VALUES (?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("iss", $userId, $name, $apiKey);
        if ($stmt->execute()) {
            $newId = $db->insert_id;
            // Also insert into api_keys table for backward compatibility
            @$db->query("INSERT INTO api_keys (user_id, api_key, name, status) VALUES ($userId, '$apiKey', '$name', 'active')");
            echo json_encode([
                'success' => true,
                'key' => 'Key created successfully',
                'data' => ['id' => $newId, 'name' => $name, 'api_key' => $apiKey]
            ]);
            exit;
        }
    }
    echo json_encode(['success' => false, 'error' => 'Không thể tạo key']);
    exit;
}

if ($method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $keyId = intval($input['id'] ?? 0);

    if ($keyId <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid key ID']);
        exit;
    }

    // Get key before deleting to also remove from api_keys table
    $keyRow = $db->query("SELECT api_key FROM user_api_keys WHERE id = $keyId AND user_id = $userId")->fetch_assoc();
    
    $stmt = $db->prepare("DELETE FROM user_api_keys WHERE id = ? AND user_id = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $keyId, $userId);
        if ($stmt->execute()) {
            // Also delete from api_keys
            if ($keyRow) {
                $apiKey = $db->real_escape_string($keyRow['api_key']);
                @$db->query("DELETE FROM api_keys WHERE api_key = '$apiKey' AND user_id = $userId");
            }
            echo json_encode(['success' => true, 'message' => 'Key deleted']);
            exit;
        }
    }
    echo json_encode(['success' => false, 'error' => 'Không thể xóa key']);
    exit;
}

echo json_encode(['error' => 'Method not allowed']);