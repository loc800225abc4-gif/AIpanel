<?php
/**
 * OpenAI-compatible Chat Completions API
 * Endpoint: /api/v1/chat/completions
 * 
 * Usage with OpenAI Python SDK:
 *   from openai import OpenAI
 *   client = OpenAI(api_key="loc_sk_...", base_url="https://your-server.com/api/v1")
 *   response = client.chat.completions.create(model="model-id", messages=[...])
 */

error_reporting(0);
ini_set('display_errors', 0);

// Ensure clean output
while (ob_get_level()) { ob_end_clean(); }

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => ['message' => 'Method not allowed. Use POST.', 'type' => 'invalid_request_error', 'code' => 'method_not_allowed']]);
    exit;
}

require_once __DIR__ . '/../../../../config/database.php';
require_once __DIR__ . '/../../../../config/functions.php';

// ==================== AUTHENTICATION ====================
$apiUser = authenticateApiKey();
if (!$apiUser) {
    http_response_code(401);
    echo json_encode([
        'error' => [
            'message' => 'Invalid API key. Provide via Authorization: Bearer <key> or ?api_key=<key>',
            'type' => 'authentication_error',
            'code' => 'invalid_api_key'
        ]
    ]);
    exit;
}

$userId = $apiUser['user_id'] ?? $apiUser['id'];
$apiKeyId = $apiUser['api_key_id'] ?? null;
$user = getUserById($userId);

if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => ['message' => 'User not found.', 'type' => 'authentication_error', 'code' => 'user_not_found']]);
    exit;
}

// ==================== PARSE REQUEST ====================
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !is_array($input)) {
    http_response_code(400);
    echo json_encode(['error' => ['message' => 'Invalid JSON body.', 'type' => 'invalid_request_error', 'code' => 'invalid_json']]);
    exit;
}

if (empty($input['messages']) || !is_array($input['messages'])) {
    http_response_code(400);
    echo json_encode(['error' => ['message' => 'Missing required field: messages', 'type' => 'invalid_request_error', 'code' => 'missing_messages']]);
    exit;
}

$modelName   = trim($input['model'] ?? '');
$messages    = $input['messages'];
$stream      = !empty($input['stream']);
$temperature = floatval($input['temperature'] ?? 0.7);
$maxTokens   = intval($input['max_tokens'] ??   1000000);

// ==================== FIND MODEL ====================
$db = getDB();
if (!$db) {
    http_response_code(500);
    echo json_encode(['error' => ['message' => 'Database connection failed.', 'type' => 'server_error', 'code' => 'db_error']]);
    exit;
}

// Try to find model by model_id first, then by name, then by id
$model = null;
$searchTerms = [$modelName];

if (!empty($modelName)) {
    // Also try without provider prefix (e.g. "deepseek-chat" from "deepseek-ai/deepseek-chat")
    if (strpos($modelName, '/') !== false) {
        $searchTerms[] = substr($modelName, strrpos($modelName, '/') + 1);
    }
}

foreach ($searchTerms as $term) {
    if (empty($term)) continue;
    $stmt = $db->prepare("SELECT * FROM ai_models WHERE (model_id = ? OR name = ?) AND is_active = 1 LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("ss", $term, $term);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $model = $row;
            break;
        }
    }
}

// Fallback: if no model specified, use default
if (!$model) {
    $defaultModelId = intval(getSetting('default_model', 1));
    $model = getModelById($defaultModelId);
}

// Last resort: first active model
if (!$model) {
    $activeModels = getActiveModels();
    $model = !empty($activeModels) ? $activeModels[0] : null;
}

if (!$model) {
    http_response_code(500);
    echo json_encode(['error' => ['message' => 'No AI model available. Please contact administrator.', 'type' => 'server_error', 'code' => 'no_model']]);
    exit;
}

// ==================== MODEL CONFIG ====================
$baseUrl      = $model['base_url'] ?: getSetting('base_url', 'https://api.openai.com');
$apiKey       = $model['api_key'] ?: getSetting('api_key', '');
$modelIdStr   = $model['model_id'];
$maxTokens    = intval($model['max_tokens'] ?: $maxTokens);
$temperature  = floatval($model['temperature'] ?: $temperature);

if (empty($apiKey)) {
    http_response_code(500);
    echo json_encode(['error' => ['message' => 'Model API key not configured.', 'type' => 'server_error', 'code' => 'model_config_error']]);
    exit;
}

// ==================== CREDITS CHECK ====================
$allContent = '';
foreach ($messages as $msg) {
    if (is_array($msg['content'])) {
        // Handle multimodal content array
        foreach ($msg['content'] as $part) {
            $allContent .= $part['text'] ?? ($part['image_url']['url'] ?? '');
        }
    } else {
        $allContent .= $msg['content'] ?? '';
    }
}
$estimatedTokens = ceil(strlen($allContent) / 3) + 500;
$creditsPerToken = floatval(getSetting('credits_per_token', '0.001'));
$estimatedCost = ceil($estimatedTokens * $creditsPerToken);

if (floatval($user['credits']) < $estimatedCost) {
    http_response_code(402);
    echo json_encode([
        'error' => [
            'message' => 'Insufficient credits. Need ' . $estimatedCost . ', have ' . $user['credits'],
            'type' => 'insufficient_quota',
            'code' => 'insufficient_credits'
        ]
    ]);
    exit;
}

// ==================== SAVE USER MESSAGE ====================
$sessionId = $input['session_id'] ?? ('sess_' . bin2hex(random_bytes(12)));
$lastUserMsg = end($messages);
$userMsgContent = is_string($lastUserMsg['content']) ? $lastUserMsg['content'] : json_encode($lastUserMsg['content']);
$userTokens = ceil(strlen($userMsgContent) / 3);

try {
    $stmt2 = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt) VALUES (?, ?, ?, 'user', ?, ?)");
    if ($stmt2) {
        $stmt2->bind_param("isisi", $userId, $sessionId, $model['id'], $userMsgContent, $userTokens);
        $stmt2->execute();
    }
} catch (Exception $e) {
    // Non-critical, continue
}

// ==================== CALL AI API ====================
$startTime = microtime(true);
$completionId = 'chatcmpl-' . bin2hex(random_bytes(16));

if ($stream) {
    // ==================== STREAMING MODE (SSE) ====================
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    deductCredits($userId, $estimatedCost, "Chat (stream) with {$model['name']}");

    $fullText = callAIStream($baseUrl, $apiKey, $modelIdStr, $messages, $maxTokens, $temperature, function($chunk) use ($completionId, $modelIdStr, $modelName) {
        $data = [
            'id' => $completionId,
            'object' => 'chat.completion.chunk',
            'created' => time(),
            'model' => $modelIdStr ?: $modelName,
            'choices' => [[
                'index' => 0,
                'delta' => ['content' => $chunk],
                'finish_reason' => null
            ]]
        ];
        echo "data: " . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
    });

    if ($fullText === null) {
        echo "data: " . json_encode(['error' => ['message' => 'Cannot connect to AI server', 'type' => 'server_error']]) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
        exit;
    }

    // Final chunk with finish_reason
    $final = [
        'id' => $completionId,
        'object' => 'chat.completion.chunk',
        'created' => time(),
        'model' => $modelIdStr ?: $modelName,
        'choices' => [[
            'index' => 0,
            'delta' => [],
            'finish_reason' => 'stop'
        ]]
    ];
    echo "data: " . json_encode($final, JSON_UNESCAPED_UNICODE) . "\n\n";
    echo "data: [DONE]\n\n";
    if (ob_get_level()) ob_flush();
    flush();

    // Post-processing
    $outputTokens = ceil(strlen($fullText) / 3);
    $totalTokens = $userTokens + $outputTokens;
    $responseTimeMs = round((microtime(true) - $startTime) * 1000);
    $actualCost = ceil($totalTokens * $creditsPerToken);

    // Adjust credits
    $diff = $actualCost - $estimatedCost;
    if ($diff > 0) {
        deductCredits($userId, $diff, "Chat (stream) adjustment {$model['name']}");
    } elseif ($diff < 0) {
        $refund = abs($diff);
        $db->query("UPDATE users SET credits = credits + {$refund} WHERE id = " . intval($userId));
        $db->query("INSERT INTO credit_logs (user_id, amount, type, description) VALUES (" . intval($userId) . ", {$refund}, 'refund', 'Stream refund " . $model['name'] . "')");
    }

    // Save assistant response
    try {
        $stmt3 = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt, tokens_completion, tokens_total, response_time_ms) VALUES (?, ?, ?, 'assistant', ?, ?, ?, ?, ?)");
        if ($stmt3) {
            $stmt3->bind_param("isisiiii", $userId, $sessionId, $model['id'], $fullText, $userTokens, $outputTokens, $totalTokens, $responseTimeMs);
            $stmt3->execute();
        }
    } catch (Exception $e) {}

    // Log usage
    logUsage($userId, $apiKeyId, $model['model_id'], $model['provider'], 'chat', $userTokens, $outputTokens, $actualCost, $actualCost, 'success', $responseTimeMs, $_SERVER['REMOTE_ADDR'] ?? '');

    exit;

} else {
    // ==================== NON-STREAMING MODE ====================
    deductCredits($userId, $estimatedCost, "Chat with {$model['name']}");

    $aiResponse = callAI($baseUrl, $apiKey, $modelIdStr, $messages, $maxTokens, $temperature);
    $responseTimeMs = round((microtime(true) - $startTime) * 1000);

    if ($aiResponse === null) {
        http_response_code(502);
        echo json_encode(['error' => ['message' => 'Cannot connect to AI upstream server.', 'type' => 'server_error', 'code' => 'upstream_error']]);
        exit;
    }

    $responseText = $aiResponse['choices'][0]['message']['content'] ?? '';
    $inputTokens  = $aiResponse['usage']['prompt_tokens'] ?? $userTokens;
    $outputTokens = $aiResponse['usage']['completion_tokens'] ?? ceil(strlen($responseText) / 3);
    $totalTokens  = $inputTokens + $outputTokens;
    $actualCost   = ceil($totalTokens * $creditsPerToken);

    // Adjust credits
    $diff = $actualCost - $estimatedCost;
    if ($diff > 0) {
        deductCredits($userId, $diff, "Chat adjustment {$model['name']}");
    } elseif ($diff < 0) {
        $refund = abs($diff);
        $db->query("UPDATE users SET credits = credits + {$refund} WHERE id = " . intval($userId));
        $db->query("INSERT INTO credit_logs (user_id, amount, type, description) VALUES (" . intval($userId) . ", {$refund}, 'refund', 'Chat refund " . $model['name'] . "')");
    }

    // Save assistant response
    try {
        $stmt3 = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt, tokens_completion, tokens_total, response_time_ms) VALUES (?, ?, ?, 'assistant', ?, ?, ?, ?, ?)");
        if ($stmt3) {
            $stmt3->bind_param("isisiiii", $userId, $sessionId, $model['id'], $responseText, $inputTokens, $outputTokens, $totalTokens, $responseTimeMs);
            $stmt3->execute();
        }
    } catch (Exception $e) {}

    // Log usage
    logUsage($userId, $apiKeyId, $model['model_id'], $model['provider'], 'chat', $inputTokens, $outputTokens, $actualCost, $actualCost, 'success', $responseTimeMs, $_SERVER['REMOTE_ADDR'] ?? '');

    // OpenAI-compatible response format
    $response = [
        'id' => $completionId,
        'object' => 'chat.completion',
        'created' => time(),
        'model' => $modelIdStr ?: $modelName,
        'choices' => [[
            'index' => 0,
            'message' => [
                'role' => 'assistant',
                'content' => $responseText
            ],
            'finish_reason' => 'stop'
        ]],
        'usage' => [
            'prompt_tokens' => $inputTokens,
            'completion_tokens' => $outputTokens,
            'total_tokens' => $totalTokens
        ]
    ];

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}

// ==================== HELPER FUNCTIONS ====================

/**
 * Call upstream AI API (non-streaming)
 */
function callAI($baseUrl, $apiKey, $model, $messages, $maxTokens, $temperature) {
    $url = rtrim($baseUrl, '/');
    // If the base_url already contains /v1, don't add it again
    if (strpos($url, '/v1') === false) {
        $url .= '/v1/chat/completions';
    } else {
        $url .= '/chat/completions';
    }

    $payload = json_encode([
        'model' => $model,
        'messages' => $messages,
        'max_tokens' => $maxTokens,
        'temperature' => $temperature,
        'stream' => false
    ]);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey
        ],
        CURLOPT_TIMEOUT => 180,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0
    ]);

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        error_log('AI API cURL error: ' . $error);
        return null;
    }

    $data = json_decode($result, true);

    if ($httpCode !== 200 || isset($data['error'])) {
        error_log("AI API error: HTTP $httpCode, message: " . ($data['error']['message'] ?? 'Unknown'));
        return null;
    }

    if (empty($data['choices'][0]['message']['content'])) {
        error_log('AI API: unexpected response structure: ' . substr($result, 0, 500));
        return null;
    }

    return $data;
}

/**
 * Call upstream AI API (streaming)
 */
function callAIStream($baseUrl, $apiKey, $model, $messages, $maxTokens, $temperature, $onDelta) {
    $url = rtrim($baseUrl, '/');
    if (strpos($url, '/v1') === false) {
        $url .= '/v1/chat/completions';
    } else {
        $url .= '/chat/completions';
    }

    $payload = json_encode([
        'model' => $model,
        'messages' => $messages,
        'max_tokens' => $maxTokens,
        'temperature' => $temperature,
        'stream' => true
    ]);

    $fullText = '';
    $buffer = '';

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'Accept: text/event-stream'
        ],
        CURLOPT_TIMEOUT => 180,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_WRITEFUNCTION => function($ch, $data) use ($onDelta, &$fullText, &$buffer) {
            $buffer .= $data;
            while (($pos = strpos($buffer, "\n")) !== false) {
                $line = substr($buffer, 0, $pos);
                $buffer = substr($buffer, $pos + 1);

                if (strpos($line, 'data: ') === 0) {
                    $json = substr($line, 6);
                    if ($json === '[DONE]') continue;

                    $chunk = json_decode($json, true);
                    if (!$chunk) continue;

                    $delta = $chunk['choices'][0]['delta']['content'] ?? '';
                    if ($delta !== '') {
                        $fullText .= $delta;
                        $onDelta($delta);
                    }
                }
            }
            return strlen($data);
        }
    ]);

    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        error_log('AI API stream cURL error: ' . $error);
        return null;
    }

    if ($httpCode !== 200) {
        error_log("AI API stream error: HTTP $httpCode");
        return null;
    }

    if (empty($fullText)) {
        error_log('AI API stream: no content received');
        return null;
    }

    return $fullText;
}