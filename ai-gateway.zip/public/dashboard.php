<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

if (!isLoggedIn()) { header('Location: login.php'); exit; }

$user = getUser();
$userId = $user['id'];
$db = getDB();

// Create api keys table if missing
@$db->query("CREATE TABLE IF NOT EXISTS user_api_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) DEFAULT NULL,
    api_key VARCHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Handle GET: delete key
if (isset($_GET['delete_key'])) {
    $keyId = intval($_GET['delete_key']);
    $db->query("DELETE FROM user_api_keys WHERE id = $keyId AND user_id = $userId");
    header('Location: dashboard.php');
    exit;
}

// Load keys
$keys = [];
$keysResult = $db->query("SELECT * FROM user_api_keys WHERE user_id = $userId ORDER BY created_at DESC");
if ($keysResult && $keysResult->num_rows > 0) {
    while ($row = $keysResult->fetch_assoc()) { $keys[] = $row; }
}

// Get recent usage
$recentUsage = [];
$usageResult = $db->query("SELECT ch.model_id, ch.tokens_total, ch.created_at, am.name as model_name FROM chat_history ch LEFT JOIN ai_models am ON ch.model_id = am.id WHERE ch.user_id = $userId ORDER BY ch.created_at DESC LIMIT 10");
if ($usageResult && $usageResult->num_rows > 0) {
    while ($row = $usageResult->fetch_assoc()) { $recentUsage[] = $row; }
}

// Get stats
$totalTokens = 0;
$totalChats = 0;
$statsResult = $db->query("SELECT SUM(tokens_total) as total, COUNT(*) as cnt FROM chat_history WHERE user_id = $userId AND role='assistant'");
if ($statsResult && $row = $statsResult->fetch_assoc()) { $totalTokens = $row['total'] ?: 0; $totalChats = $row['cnt']; }

// API doc data
$siteUrl = getSetting('site_url', 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
$apiBaseUrl = rtrim($siteUrl, '/') . '/api';
$firstKey = !empty($keys) ? sanitize($keys[0]['api_key']) : 'sk-your-api-key-here';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - LocNguyen AI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #030712; --card: #0f172a; --card2: #1e293b;
            --border: #1e293b; --border-light: #334155;
            --text: #f1f5f9; --text2: #94a3b8; --text3: #64748b;
            --accent: #6366f1; --accent-light: #818cf8;
            --accent-glow: rgba(99,102,241,0.3);
            --green: #22c55e; --red: #ef4444; --radius: 12px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
        a { text-decoration: none; color: inherit; }

        .topnav {
            background: var(--card); border-bottom: 1px solid var(--border);
            padding: 14px 24px; display: flex; align-items: center; justify-content: space-between;
            position: sticky; top: 0; z-index: 100;
        }
        .topnav .logo { display: flex; align-items: center; gap: 10px; font-weight: 700; font-size: 1.1rem; }
        .topnav .logo span { background: linear-gradient(135deg, #fff, #a5b4fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .topnav .nav-links { display: flex; gap: 20px; align-items: center; }
        .topnav .nav-links a { color: var(--text2); font-size: 0.9rem; transition: color 0.2s; padding: 6px 0; }
        .topnav .nav-links a:hover { color: var(--text); }
        .topnav .nav-links a.active { color: var(--accent-light); }
        .topnav .nav-links .btn-out { color: var(--red); }

        .container { max-width: 1000px; margin: 0 auto; padding: 32px 20px; }

        .page-title { font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; }
        .page-sub { color: var(--text3); font-size: 0.9rem; margin-bottom: 28px; }

        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 32px; }
        .stat-card {
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius); padding: 20px;
            display: flex; align-items: flex-start; gap: 14px;
        }
        .stat-icon {
            width: 44px; height: 44px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.2rem; flex-shrink: 0;
        }
        .stat-info .stat-num { font-size: 1.5rem; font-weight: 700; }
        .stat-info .stat-lbl { font-size: 0.8rem; color: var(--text3); margin-top: 2px; }

        .card {
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius); padding: 24px; margin-bottom: 24px;
        }
        .card h3 { font-size: 1rem; font-weight: 600; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }

        table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
        th { text-align: left; padding: 10px 12px; color: var(--text3); font-weight: 500; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid var(--border); }
        td { padding: 12px; border-bottom: 1px solid var(--border); }
        tr:last-child td { border-bottom: none; }
        .badge { display: inline-block; padding: 4px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 500; }
        .badge-green { background: rgba(34,197,94,0.1); color: var(--green); }

        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 10px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 500; cursor: pointer; transition: all 0.3s; border: none; font-family: 'Inter', sans-serif; }
        .btn-primary { background: linear-gradient(135deg, var(--accent), #7c3aed); color: #fff; }
        .btn-primary:hover { box-shadow: 0 4px 16px var(--accent-glow); }
        .btn-outline { background: transparent; border: 1px solid var(--border-light); color: var(--text2); }
        .btn-outline:hover { border-color: var(--accent); color: var(--text); }
        .btn-sm { padding: 6px 12px; font-size: 0.8rem; }

        .key-row { display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--card2); border-radius: 8px; margin-bottom: 8px; }
        .key-row code { flex: 1; font-size: 0.85rem; color: var(--accent-light); word-break: break-all; }
        .copy-btn { padding: 8px 14px; background: var(--card); border: 1px solid var(--border-light); color: var(--text2); border-radius: 6px; cursor: pointer; font-size: 0.8rem; transition: all 0.2s; }
        .copy-btn:hover { border-color: var(--accent); color: var(--text); }

        .flash-msg { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 0.9rem; font-weight: 500; }
        .flash-msg.success { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); color: #22c55e; }
        .flash-msg.error { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; }

        .empty { text-align: center; padding: 40px; color: var(--text3); }
        .empty i { font-size: 3rem; margin-bottom: 12px; display: block; }

        /* API Doc styles */
        .api-section { margin-bottom: 16px; border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
        .api-section-header { padding: 14px 18px; background: var(--card2); display: flex; align-items: center; gap: 10px; cursor: pointer; user-select: none; }
        .api-section-header:hover { background: var(--border); }
        .api-section-header .method { display:inline-block; padding:4px 10px;border-radius:6px;font-size:0.75rem;font-weight:700;font-family:'JetBrains Mono',monospace;text-transform:uppercase; }
        .method-get { background: rgba(34,197,94,0.15); color: #22c55e; }
        .method-post { background: rgba(99,102,241,0.15); color: #818cf8; }
        .api-section-header .endpoint { font-family: 'JetBrains Mono', 'Consolas', monospace; font-size: 0.85rem; color: var(--text); }
        .api-section-header .desc { font-size:0.82rem; color: var(--text2); margin-left: auto; }
        .api-section-body { display: none; padding: 18px; background: #0d1117; border-top: 1px solid var(--border); }
        .api-section.open .api-section-body { display: block; }
        .api-section-body h5 { font-size: 0.78rem; color: var(--text3); text-transform: uppercase; letter-spacing: 0.5px; margin: 14px 0 8px; }
        .api-section-body h5:first-child { margin-top: 0; }
        .code-block { background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 14px 16px; overflow-x: auto; font-family: 'JetBrains Mono', 'Consolas', monospace; font-size: 0.78rem; line-height: 1.6; color: #c9d1d9; position: relative; white-space: pre; }
        .code-block .btn-copy-code { position: absolute; top: 8px; right: 10px; padding: 4px 10px; background: #21262d; border: 1px solid #30363d; border-radius: 6px; color: #c9d1d9; font-size: 0.7rem; cursor: pointer; font-family: 'Inter', sans-serif; }
        .code-block .btn-copy-code:hover { background: #30363d; }
        .params-table { width:100%; border-collapse: collapse; font-size:0.85rem; margin:8px 0; }
        .params-table th { background: var(--card2); text-align: left; padding: 8px 12px; font-size:0.75rem; border-bottom: 1px solid var(--border); }
        .params-table td { padding: 8px 12px; border-bottom: 1px solid var(--border); font-size:0.82rem; }
        .params-table code { font-family: 'JetBrains Mono', monospace; font-size: 0.78rem; background: rgba(99,102,241,0.1); padding: 2px 6px; border-radius: 4px; color: var(--accent-light); }

        #keyFormMsg { display: none; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; font-size: 0.85rem; font-weight: 500; }
        #keyFormMsg.success { display: block; background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); color: #22c55e; }
        #keyFormMsg.error { display: block; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; }
        #keyFormMsg.info { display: block; background: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.3); color: #818cf8; }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            .container { max-width: 100%; padding: 12px; }
            .topnav { padding: 10px 14px; }
            .topnav .nav-links { gap: 10px; }
            .topnav .nav-links a { font-size: 0.8rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
            .page-title { font-size: 1.2rem; }
            .key-row { flex-wrap: wrap; gap: 8px; }
            .key-row code { font-size: 0.7rem; }
            table { font-size: 0.7rem; }
            th, td { padding: 8px 6px; }
            .api-section-header { flex-wrap: wrap; }
            .api-section-header .desc { margin-left: 0; width: 100%; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr; }
            .topnav .nav-links { flex-wrap: wrap; gap: 4px; }
            .topnav .nav-links a { font-size: 0.7rem; padding: 4px 8px; }
            .key-row { flex-direction: column; }
            .key-row span { width: 100%; }
            .key-row code { width: 100%; word-break: break-all; }
        }
    </style>
</head>
<body>
    <nav class="topnav">
        <div class="logo"><i class="fa-solid fa-brain"></i> <span>LocNguyen AI</span></div>
        <div class="nav-links">
            <a href="index.php"><i class="fas fa-comments"></i> Chat</a>
            <a href="dashboard.php" class="active"><i class="fas fa-user"></i> Dashboard</a>
            <a href="logout.php" class="btn-out"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="page-title">👋 Chào, <?php echo sanitize($user['full_name'] ?: $user['username']); ?></h1>
        <p class="page-sub">Quản lý tài khoản, API keys và theo dõi sử dụng</p>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(99,102,241,0.15);">💎</div>
                <div class="stat-info">
                    <div class="stat-num"><?php echo formatNumber($user['credits'] ?? 0); ?></div>
                    <div class="stat-lbl">Credits còn lại</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(34,197,94,0.15);">📊</div>
                <div class="stat-info">
                    <div class="stat-num"><?php echo formatNumber($totalTokens); ?></div>
                    <div class="stat-lbl">Tokens đã dùng</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(245,158,11,0.15);">💬</div>
                <div class="stat-info">
                    <div class="stat-num"><?php echo $totalChats; ?></div>
                    <div class="stat-lbl">Tổng chats</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(236,72,153,0.15);">🔑</div>
                <div class="stat-info">
                    <div class="stat-num"><?php echo count($keys); ?></div>
                    <div class="stat-lbl">API Keys</div>
                </div>
            </div>
        </div>

        <!-- API Keys -->
        <div class="card">
            <h3><i class="fas fa-key"></i> API Keys của bạn</h3>
            <div id="keyFormMsg"></div>
            <div style="margin-bottom:16px;display:flex;gap:10px;">
                <input type="text" id="keyNameInput" placeholder="Tên key (VD: My App)" required style="flex:1;padding:10px 14px;background:var(--card2);border:1px solid var(--border-light);border-radius:8px;color:var(--text);font-family:'Inter',sans-serif;">
                <button onclick="createApiKey()" id="createKeyBtn" class="btn btn-primary btn-sm">Tạo Key</button>
            </div>
            <?php if (empty($keys)): ?>
                <div class="empty"><i class="fas fa-key"></i>Chưa có API key nào. Tạo key đầu tiên của bạn ở trên!</div>
            <?php else: ?>
                <?php foreach ($keys as $k): ?>
                <div class="key-row">
                    <span style="font-size:0.85rem;width:120px;flex-shrink:0;"><?php echo sanitize($k['name'] ?? ''); ?></span>
                    <code><?php echo $k['api_key'] ?? ''; ?></code>
                    <button class="copy-btn" onclick="navigator.clipboard.writeText('<?php echo $k['api_key'] ?? ''; ?>');this.textContent='Copied!';setTimeout(()=>this.textContent='Copy',1500);">Copy</button>
                    <a href="?delete_key=<?php echo $k['id']; ?>" onclick="return confirm('Xóa key này?')" style="color:var(--red);font-size:0.85rem;"><i class="fas fa-trash"></i></a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- API Documentation -->
        <div class="card">
            <h3><i class="fas fa-book"></i> Hướng dẫn sử dụng API</h3>
            <p style="color:var(--text2);font-size:0.9rem;margin-bottom:20px;line-height:1.6;">
                API tương thích với <strong>OpenAI SDK</strong>. Bạn có thể dùng <code style="background:rgba(99,102,241,0.1);padding:2px 6px;border-radius:4px;">openai</code> Python package
                hoặc <code style="background:rgba(99,102,241,0.1);padding:2px 6px;border-radius:4px;">openai</code> npm package để gọi.
                Xác thực qua <strong>Authorization: Bearer <api_key></strong>.
            </p>

            <!-- Python OpenAI SDK -->
            <div class="api-section open">
                <div class="api-section-header" onclick="this.parentElement.classList.toggle('open')">
                    <span class="method method-post">🐍</span>
                    <span class="endpoint">Python SDK</span>
                    <span class="desc">from openai import OpenAI</span>
                </div>
                <div class="api-section-body">
                    <h5>📦 Cài đặt</h5>
                    <div class="code-block" style="padding:10px 16px;">pip install openai</div>

                    <h5>💻 Code mẫu</h5>
                    <div class="code-block">
                        <button class="btn-copy-code" onclick="var t=this.parentElement.textContent.replace('Copy','').trim();navigator.clipboard.writeText(t);this.textContent='Copied!';setTimeout(()=>this.textContent='Copy',1500);">Copy</button>
from openai import OpenAI

client = OpenAI(
    base_url='<?php echo $apiBaseUrl; ?>/v1/',
    api_key='<?php echo $firstKey; ?>',
)

response = client.chat.completions.create(
    model='deepseek-ai/DeepSeek-V4-Pro',
    messages=[
        {
            'role': 'user',
            'content': 'Hello, how are you?'
        }
    ],
)

print(response.to_json())
                    </div>
                </div>
            </div>

            <!-- JavaScript/Node.js OpenAI SDK -->
            <div class="api-section">
                <div class="api-section-header" onclick="this.parentElement.classList.toggle('open')">
                    <span class="method method-post">📜</span>
                    <span class="endpoint">JavaScript / Node.js SDK</span>
                    <span class="desc">import OpenAI from 'openai'</span>
                </div>
                <div class="api-section-body">
                    <h5>📦 Cài đặt</h5>
                    <div class="code-block" style="padding:10px 16px;">npm install openai</div>

                    <h5>💻 Code mẫu</h5>
                    <div class="code-block">
                        <button class="btn-copy-code" onclick="var t=this.parentElement.textContent.replace('Copy','').trim();navigator.clipboard.writeText(t);this.textContent='Copied!';setTimeout(()=>this.textContent='Copy',1500);">Copy</button>
import OpenAI from 'openai';

const client = new OpenAI({
  baseURL: '<?php echo $apiBaseUrl; ?>/v1/',
  apiKey: '<?php echo $firstKey; ?>',
});

client.chat.completions
  .create({
    model: 'deepseek-ai/DeepSeek-V4-Pro',
    messages: [
      {
        role: 'user',
        content: 'Hello, how are you?'
      }
    ],
  })
  .then((response) => console.log(response));
                    </div>
                </div>
            </div>

            <!-- cURL -->
            <div class="api-section">
                <div class="api-section-header" onclick="this.parentElement.classList.toggle('open')">
                    <span class="method method-post">📋</span>
                    <span class="endpoint">cURL</span>
                    <span class="desc">HTTP request trực tiếp</span>
                </div>
                <div class="api-section-body">
                    <h5>📥 Request</h5>
                    <div class="code-block">
                        <button class="btn-copy-code" onclick="var t=this.parentElement.textContent.replace('Copy','').trim();navigator.clipboard.writeText(t);this.textContent='Copied!';setTimeout(()=>this.textContent='Copy',1500);">Copy</button>
curl '<?php echo $apiBaseUrl; ?>/v1/chat/completions' \
  -X 'POST' \
  -H 'Authorization: Bearer <?php echo $firstKey; ?>' \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "deepseek-ai/DeepSeek-V4-Pro",
    "messages": [
      {
        "role": "user",
        "content": "Hello, how are you?"
      }
    ]
  }'
                    </div>

                    <h5>📤 Response (JSON)</h5>
                    <div class="code-block">
{
  "id": "chatcmpl-...",
  "object": "chat.completion",
  "created": 1721814000,
  "model": "deepseek-ai/DeepSeek-V4-Pro",
  "choices": [{
    "index": 0,
    "message": {
      "role": "assistant",
      "content": "Hello! I'm doing great, thank you for asking."
    },
    "finish_reason": "stop"
  }],
  "usage": {
    "prompt_tokens": 15,
    "completion_tokens": 12,
    "total_tokens": 27
  }
}
                    </div>
                </div>
            </div>

            <!-- Models -->
            <div class="api-section">
                <div class="api-section-header" onclick="this.parentElement.classList.toggle('open')">
                    <span class="method method-get">GET</span>
                    <span class="endpoint">/v1/models</span>
                    <span class="desc">Lấy danh sách model</span>
                </div>
                <div class="api-section-body">
                    <h5>📋 cURL</h5>
                    <div class="code-block" style="padding:10px 16px;">
curl -H "Authorization: Bearer <?php echo $firstKey; ?>" <?php echo $apiBaseUrl; ?>/v1/models
                    </div>
                </div>
            </div>

            <div style="margin-top:18px;padding:14px 18px;background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.25);border-radius:10px;font-size:0.85rem;color:#fbbf24;">
                <strong>⚠️ Lưu ý:</strong> Mỗi API key giới hạn <strong>5 key / tài khoản</strong>. Giữ bí mật key của bạn! Nếu key bị lộ, hãy xóa ngay lập tức.
                Sử dụng <code style="background:rgba(245,158,11,0.2);padding:2px 6px;border-radius:4px;">base_url</code> và <code style="background:rgba(245,158,11,0.2);padding:2px 6px;border-radius:4px;">api_key</code> trong OpenAI SDK để kết nối.
            </div>
        </div>

        <!-- Recent Usage -->
        <div class="card">
            <h3><i class="fas fa-history"></i> Lịch sử sử dụng gần đây</h3>
            <?php if (empty($recentUsage)): ?>
                <div class="empty"><i class="fas fa-inbox"></i>Chưa có hoạt động nào. <a href="index.php" style="color:var(--accent-light);">Bắt đầu chat ngay!</a></div>
            <?php else: ?>
                <table>
                    <thead><tr><th>Model</th><th>Tokens</th><th>Thời gian</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentUsage as $r): ?>
                    <tr>
                        <td><span class="badge badge-green"><?php echo sanitize($r['model_name'] ?: 'N/A'); ?></span></td>
                        <td><?php echo formatNumber($r['tokens_total'] ?? 0); ?></td>
                        <td style="color:var(--text3);"><?php echo date('d/m/Y H:i', strtotime($r['created_at'] ?? '')); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <script>
    async function createApiKey() {
        var btn = document.getElementById('createKeyBtn');
        var input = document.getElementById('keyNameInput');
        var msg = document.getElementById('keyFormMsg');
        var name = input.value.trim();
        
        if (!name) {
            msg.className = 'error';
            msg.textContent = '⚠️ Vui lòng nhập tên key';
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Đang tạo...';
        msg.className = 'info';
        msg.textContent = 'Đang tạo API key...';

        try {
            var resp = await fetch('/api/keys.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: name })
            });
            var data = await resp.json();
            
            if (data.success) {
                msg.className = 'success';
                msg.textContent = '✅ Key đã được tạo thành công! Đang tải lại...';
                setTimeout(function() { location.reload(); }, 800);
            } else {
                msg.className = 'error';
                msg.textContent = '❌ ' + (data.error || 'Không thể tạo key. Vui lòng thử lại.');
                btn.disabled = false;
                btn.textContent = 'Tạo Key';
            }
        } catch (e) {
            msg.className = 'error';
            msg.textContent = '❌ Lỗi kết nối. Bạn có thể đã bị đăng xuất. Vui lòng <a href="login.php">đăng nhập lại</a>.';
            btn.disabled = false;
            btn.textContent = 'Tạo Key';
        }
    }

    // Allow Enter key to submit
    document.getElementById('keyNameInput').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); createApiKey(); }
    });
    </script>
</body>
</html>