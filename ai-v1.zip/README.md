# AI Gateway - All-in-One Docker Deployment

Hệ thống AI Gateway tích hợp PHP Dashboard + Python FastAPI Gateway, chạy trên Docker.

## Cấu trúc
- **Port 8080**: PHP Frontend Dashboard (Apache)
- **Port 8000**: AI Gateway API (Python FastAPI)
- **Port 3306**: MySQL Database (shared)

## Cài đặt nhanh

```bash
chmod +x setup.sh
./setup.sh
```

Sau khi cài đặt:
- PHP Dashboard: `http://localhost:8080`
- AI Gateway API: `http://localhost:8000`
- Login: `locnguyen` / `Loc12345s@`

## Rebuild (giữ database)

```bash
chmod +x quick-rebuild.sh
./quick-rebuild.sh
```

## Fix lỗi + rebuild (xóa sạch database)

```bash
chmod +x fix-and-rebuild.sh
./fix-and-rebuild.sh
```

## Debug endpoints

```bash
# Health check
curl http://localhost:8000/health

# Kiểm tra hash bcrypt
curl "http://localhost:8000/debug/hash?password=Loc12345s@"

# Kiểm tra tài khoản admin
curl http://localhost:8000/debug/check-admin

# Xem logs
docker compose logs ai-gateway --tail 50
docker compose logs php-apache --tail 50
```

## Quản lý Docker

```bash
docker compose ps                    # Xem trạng thái containers
docker compose logs -f               # Xem tất cả logs
docker compose restart               # Khởi động lại
docker compose stop                  # Dừng (giữ data)
docker compose down                  # Xóa containers (giữ data)
docker compose down -v               # Xóa tất cả (kể cả database)