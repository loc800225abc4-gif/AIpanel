"""Validation script that checks all imports and module connectivity."""
import sys
import traceback

print("=" * 70)
print("AI GATEWAY - IMPORT VALIDATION")
print("=" * 70)

tests = []

# 1. Config
try:
    from app.config import settings
    print(f"✓ config.py: HOST={settings.HOST}, PORT={settings.PORT}")
    tests.append(True)
except Exception as e:
    print(f"✗ config.py: {e}")
    tests.append(False)

# 2. Database base
try:
    from app.database.base import Base
    print("✓ database/base.py: Base class loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ database/base.py: {e}")
    tests.append(False)

# 3. Database session
try:
    from app.database.session import get_async_session, async_engine
    print("✓ database/session.py: get_async_session loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ database/session.py: {e}")
    tests.append(False)

# 4. Models
try:
    from app.models.models import AdminUser, APIKey, Provider, ModelMapping, RequestLog
    print("✓ models/models.py: All 5 models loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ models/models.py: {e}")
    tests.append(False)

# 5. Schemas
try:
    from app.schemas.schemas import (
        ProviderCreate, ProviderUpdate, ProviderResponse,
        ModelMappingCreate, ModelMappingResponse,
        APIKeyCreate, APIKeyUpdate, APIKeyResponse, APIKeyCreateResponse,
        MessageResponse, TokenResponse, LoginRequest,
    )
    print("✓ schemas/schemas.py: All schemas loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ schemas/schemas.py: {e}")
    tests.append(False)

# 6. Auth security
try:
    from app.auth.security import (
        hash_password, verify_password, create_access_token,
        decode_access_token, get_current_user_from_cookie, COOKIE_NAME,
    )
    print("✓ auth/security.py: All security functions loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ auth/security.py: {e}")
    tests.append(False)

# 7. Auth routes
try:
    from app.api.auth_routes import router as auth_router
    print("✓ api/auth_routes.py: Router loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ api/auth_routes.py: {e}")
    tests.append(False)

# 8. Dashboard routes
try:
    from app.api.dashboard_routes import router as dashboard_router
    print("✓ api/dashboard_routes.py: Router loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ api/dashboard_routes.py: {e}")
    tests.append(False)

# 9. Management routes
try:
    from app.api.management_routes import router as mgmt_router
    print("✓ api/management_routes.py: Router loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ api/management_routes.py: {e}")
    tests.append(False)

# 10. Proxy routes
try:
    from app.api.proxy_routes import router as proxy_router, verify_api_key
    print("✓ api/proxy_routes.py: Router loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ api/proxy_routes.py: {e}")
    tests.append(False)

# 11. Middleware
try:
    from app.middleware.middleware import (
        SecurityHeadersMiddleware,
        ExceptionHandlerMiddleware,
        RequestLoggingMiddleware,
    )
    print("✓ middleware/middleware.py: All middleware classes loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ middleware/middleware.py: {e}")
    tests.append(False)

# 12. Services - ProxyService
try:
    from app.services.proxy_service import ProxyService
    print("✓ services/proxy_service.py: ProxyService loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ services/proxy_service.py: {e}")
    tests.append(False)

# 13. Services - ProviderService
try:
    from app.services.provider_service import ProviderService
    print("✓ services/provider_service.py: ProviderService loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ services/provider_service.py: {e}")
    tests.append(False)

# 14. Services - APIKeyService
try:
    from app.services.apikey_service import APIKeyService
    print("✓ services/apikey_service.py: APIKeyService loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ services/apikey_service.py: {e}")
    tests.append(False)

# 15. Services - LogService
try:
    from app.services.log_service import LogService
    print("✓ services/log_service.py: LogService loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ services/log_service.py: {e}")
    tests.append(False)

# 16. Services - DashboardService
try:
    from app.services.dashboard_service import DashboardService
    print("✓ services/dashboard_service.py: DashboardService loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ services/dashboard_service.py: {e}")
    tests.append(False)

# 17. Dashboard templates
try:
    from app.dashboard.templates import render_template
    print("✓ dashboard/templates.py: render_template loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ dashboard/templates.py: {e}")
    tests.append(False)

# 18. Main app
try:
    from main import app
    print("✓ main.py: FastAPI app loaded")
    tests.append(True)
except Exception as e:
    print(f"✗ main.py: {e}")
    tests.append(False)

print("\n" + "=" * 70)
passed = sum(1 for t in tests if t)
total = len(tests)
if all(tests):
    print(f"✓ ALL {total}/{total} IMPORT TESTS PASSED - Project is ready!")
else:
    print(f"✗ {passed}/{total} IMPORT TESTS PASSED - {total - passed} failures")
print("=" * 70)
sys.exit(0 if all(tests) else 1)