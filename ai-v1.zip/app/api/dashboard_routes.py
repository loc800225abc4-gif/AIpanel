"""Dashboard routes for the admin interface."""

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_async_session
from app.models.models import AdminUser
from app.auth.security import get_current_user_from_cookie
from app.services.dashboard_service import DashboardService
from app.services.provider_service import ProviderService
from app.services.apikey_service import APIKeyService
from app.services.log_service import LogService

router = APIRouter(tags=["dashboard"])


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Render the login page."""
    from app.dashboard.templates import render_template
    return HTMLResponse(render_template("login.html", {"request": request}))


@router.get("/", response_class=HTMLResponse)
async def root():
    """Redirect root to dashboard or login."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/dashboard")


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
):
    """Render the main dashboard."""
    try:
        user = await get_current_user_from_cookie(request, session)
    except Exception:
        return RedirectResponse(url="/login")

    try:
        stats = (await DashboardService.get_stats(session)).model_dump()
    except Exception as e:
        import logging
        logger = logging.getLogger("ai_gateway.dashboard")
        logger.error(f"Dashboard stats error: {type(e).__name__}: {e}", exc_info=True)
        stats = {
            "total_api_keys": 0,
            "active_api_keys": 0,
            "requests_today": 0,
            "total_requests": 0,
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "avg_latency_ms": 0.0,
            "providers_count": 0,
            "active_providers": 0,
            "healthy_providers": 0,
        }
    from app.dashboard.templates import render_template
    return HTMLResponse(
        render_template("dashboard.html", {
            "request": request,
            "user": {"username": user.username},
            "stats": stats,
            "active_page": "dashboard",
        })
    )


@router.get("/dashboard/providers", response_class=HTMLResponse)
async def providers_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
):
    """Render the providers management page."""
    try:
        user = await get_current_user_from_cookie(request, session)
    except Exception:
        return RedirectResponse(url="/login")

    try:
        providers = await ProviderService.get_all(session)
        provider_responses = [
            (await ProviderService.to_response(p)).model_dump(mode="json")
            for p in providers
        ]

        from app.dashboard.templates import render_template
        return HTMLResponse(
            render_template("providers.html", {
                "request": request,
                "user": {"username": user.username},
                "providers": provider_responses,
                "active_page": "providers",
            })
        )
    except Exception as e:
        import logging
        logger = logging.getLogger("ai_gateway.dashboard")
        logger.error(f"Providers page error: {type(e).__name__}: {e}", exc_info=True)
        return HTMLResponse(
            content=f"""<html><body style="font-family:sans-serif;padding:40px;text-align:center">
<h1>500 - Internal Server Error</h1>
<p>Failed to load providers: {type(e).__name__}</p>
<pre style="background:#f5f5f5;padding:15px;text-align:left;max-width:800px;margin:20px auto;border-radius:5px;overflow:auto">{str(e)}</pre>
<a href="/dashboard">Back to Dashboard</a>
</body></html>""",
            status_code=500,
        )


@router.get("/dashboard/api-keys", response_class=HTMLResponse)
async def apikeys_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
):
    """Render the API keys management page."""
    try:
        user = await get_current_user_from_cookie(request, session)
    except Exception:
        return RedirectResponse(url="/login")

    try:
        keys, total = await APIKeyService.get_all(session, page=1, page_size=100)
        key_responses = [
            APIKeyService.to_response(k).model_dump()
            for k in keys
        ]

        from app.dashboard.templates import render_template
        return HTMLResponse(
            render_template("api_keys.html", {
                "request": request,
                "user": {"username": user.username},
                "api_keys": key_responses,
                "total": total,
                "active_page": "api_keys",
            })
        )
    except Exception as e:
        import logging
        logger = logging.getLogger("ai_gateway.dashboard")
        logger.error(f"API keys page error: {type(e).__name__}: {e}", exc_info=True)
        return HTMLResponse(
            content=f"""<html><body style="font-family:sans-serif;padding:40px;text-align:center">
<h1>500 - Internal Server Error</h1>
<p>Failed to load API keys: {type(e).__name__}</p>
<pre style="background:#f5f5f5;padding:15px;text-align:left;max-width:800px;margin:20px auto;border-radius:5px;overflow:auto">{str(e)}</pre>
<a href="/dashboard">Back to Dashboard</a>
</body></html>""",
            status_code=500,
        )


@router.get("/dashboard/logs", response_class=HTMLResponse)
async def logs_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    page: int = Query(1, ge=1),
    search: str = Query(""),
    status_filter: str = Query(""),
):
    """Render the request logs page."""
    try:
        user = await get_current_user_from_cookie(request, session)
    except Exception:
        return RedirectResponse(url="/login")

    try:
        status_code = int(status_filter) if status_filter else None
        logs, total = await LogService.get_logs(
            session, page=page, page_size=50, search=search, status_code=status_code
        )

        from app.dashboard.templates import render_template
        from app.schemas.schemas import RequestLogResponse
        log_responses = [
            RequestLogResponse(
                id=l.id,
                request_id=l.request_id,
                timestamp=l.timestamp,
                ip_address=l.ip_address,
                api_key_name=l.api_key_name,
                endpoint=l.endpoint,
                method=l.method,
                external_model=l.external_model,
                actual_model=l.actual_model,
                provider_name=l.provider_name,
                latency_ms=l.latency_ms,
                status_code=l.status_code,
                prompt_tokens=l.prompt_tokens,
                completion_tokens=l.completion_tokens,
                total_tokens=l.total_tokens,
                error_message=l.error_message,
                is_streaming=l.is_streaming,
            )
            for l in logs
        ]

        # Pagination
        total_pages = max(1, (total + 49) // 50)

        return HTMLResponse(
            render_template("logs.html", {
                "request": request,
                "user": {"username": user.username},
                "logs": log_responses,
                "total": total,
                "page": page,
                "total_pages": total_pages,
                "search": search,
                "status_filter": status_filter,
                "active_page": "logs",
            })
        )
    except Exception as e:
        import logging
        logger = logging.getLogger("ai_gateway.dashboard")
        logger.error(f"Logs page error: {type(e).__name__}: {e}", exc_info=True)
        return HTMLResponse(
            content=f"""<html><body style="font-family:sans-serif;padding:40px;text-align:center">
<h1>500 - Internal Server Error</h1>
<p>Failed to load logs: {type(e).__name__}</p>
<pre style="background:#f5f5f5;padding:15px;text-align:left;max-width:800px;margin:20px auto;border-radius:5px;overflow:auto">{str(e)}</pre>
<a href="/dashboard">Back to Dashboard</a>
</body></html>""",
            status_code=500,
        )


@router.get("/dashboard/logs/export")
async def export_logs(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
):
    """Export logs as CSV."""
    try:
        user = await get_current_user_from_cookie(request, session)
    except Exception:
        return RedirectResponse(url="/login")

    csv_data = await LogService.export_csv(session)

    return StreamingResponse(
        iter([csv_data]),
        media_type="text/csv",
        headers={
            "Content-Disposition": "attachment; filename=logs_export.csv"
        },
    )