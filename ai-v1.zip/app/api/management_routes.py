"""Management API routes for providers and API keys CRUD."""

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_async_session
from app.models.models import AdminUser
from app.auth.security import get_current_user_from_cookie
from app.services.provider_service import ProviderService
from app.services.apikey_service import APIKeyService
from app.schemas.schemas import (
    ProviderCreate,
    ProviderUpdate,
    ProviderResponse,
    ModelMappingCreate,
    ModelMappingResponse,
    APIKeyCreate,
    APIKeyUpdate,
    APIKeyResponse,
    APIKeyCreateResponse,
    MessageResponse,
)

router = APIRouter(prefix="/api/management", tags=["management"])


# ─── Provider Routes ─────────────────────────────────────────────────────

@router.get("/providers", response_model=list[ProviderResponse])
async def list_providers(
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """List all providers."""
    providers = await ProviderService.get_all(session)
    return [await ProviderService.to_response(p) for p in providers]


@router.get("/providers/{provider_id}", response_model=ProviderResponse)
async def get_provider(
    provider_id: int,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Get a specific provider."""
    provider = await ProviderService.get_by_id(session, provider_id)
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    return await ProviderService.to_response(provider)


@router.post("/providers", response_model=ProviderResponse, status_code=201)
async def create_provider(
    data: ProviderCreate,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Create a new provider."""
    provider = await ProviderService.create(session, data)
    return await ProviderService.to_response(provider)


@router.put("/providers/{provider_id}", response_model=ProviderResponse)
async def update_provider(
    provider_id: int,
    data: ProviderUpdate,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Update a provider."""
    provider = await ProviderService.update(session, provider_id, data)
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    return await ProviderService.to_response(provider)


@router.delete("/providers/{provider_id}", response_model=MessageResponse)
async def delete_provider(
    provider_id: int,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Delete a provider."""
    success = await ProviderService.delete(session, provider_id)
    if not success:
        raise HTTPException(status_code=404, detail="Provider not found")
    return MessageResponse(message="Provider deleted successfully")


@router.post("/providers/{provider_id}/check-health")
async def check_provider_health(
    provider_id: int,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Check the health of a provider."""
    health = await ProviderService.check_health(session, provider_id)
    return {"health_status": health}


# ─── Model Mapping Routes ────────────────────────────────────────────────

@router.post(
    "/providers/{provider_id}/mappings",
    response_model=ModelMappingResponse,
    status_code=201,
)
async def add_model_mapping(
    provider_id: int,
    data: ModelMappingCreate,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Add a model mapping to a provider."""
    mapping = await ProviderService.add_model_mapping(session, provider_id, data)
    if not mapping:
        raise HTTPException(status_code=404, detail="Provider not found")
    return ModelMappingResponse(
        id=mapping.id,
        external_model=mapping.external_model,
        actual_model=mapping.actual_model,
        is_active=mapping.is_active,
        provider_id=mapping.provider_id,
    )


@router.delete(
    "/providers/mappings/{mapping_id}",
    response_model=MessageResponse,
)
async def remove_model_mapping(
    mapping_id: int,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Remove a model mapping."""
    success = await ProviderService.remove_model_mapping(session, mapping_id)
    if not success:
        raise HTTPException(status_code=404, detail="Model mapping not found")
    return MessageResponse(message="Model mapping removed successfully")


# ─── API Key Routes ──────────────────────────────────────────────────────

@router.get("/apikeys", response_model=list[APIKeyResponse])
async def list_apikeys(
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """List all API keys."""
    keys, total = await APIKeyService.get_all(session, page=page, page_size=page_size)
    return [APIKeyService.to_response(k) for k in keys]


@router.post("/apikeys", response_model=APIKeyCreateResponse, status_code=201)
async def create_apikey(
    data: APIKeyCreate,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Create a new API key. THE PLAIN-TEXT KEY IS ONLY SHOWN ONCE."""
    api_key, plain_key = await APIKeyService.create(session, data)
    return APIKeyService.to_create_response(api_key, plain_key)


@router.put("/apikeys/{key_id}", response_model=APIKeyResponse)
async def update_apikey(
    key_id: int,
    data: APIKeyUpdate,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Update an API key."""
    api_key = await APIKeyService.update(session, key_id, data)
    if not api_key:
        raise HTTPException(status_code=404, detail="API key not found")
    return APIKeyService.to_response(api_key)


@router.delete("/apikeys/{key_id}", response_model=MessageResponse)
async def delete_apikey(
    key_id: int,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Delete an API key."""
    success = await APIKeyService.delete(session, key_id)
    if not success:
        raise HTTPException(status_code=404, detail="API key not found")
    return MessageResponse(message="API key deleted successfully")


@router.post("/apikeys/{key_id}/toggle-lock", response_model=APIKeyResponse)
async def toggle_apikey_lock(
    key_id: int,
    session: AsyncSession = Depends(get_async_session),
    user: AdminUser = Depends(get_current_user_from_cookie),
):
    """Toggle the lock status of an API key."""
    api_key = await APIKeyService.toggle_lock(session, key_id)
    if not api_key:
        raise HTTPException(status_code=404, detail="API key not found")
    return APIKeyService.to_response(api_key)