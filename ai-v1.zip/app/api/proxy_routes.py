"""OpenAI-compatible API proxy routes.

These are the public endpoints that clients connect to.
The gateway transparently proxies requests to configured AI providers.
"""

import json
import logging

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_async_session
from app.services.apikey_service import APIKeyService
from app.services.proxy_service import ProxyService

logger = logging.getLogger("ai_gateway")

router = APIRouter(tags=["proxy"])


async def verify_api_key(
    authorization: str = Header(None),
    session: AsyncSession = Depends(get_async_session),
):
    """Verify the API key from the Authorization header and return the APIKey model."""
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": {
                    "message": "Missing API key. Use 'Bearer sk-user-...' in Authorization header.",
                    "type": "authentication_error",
                    "code": "missing_api_key",
                }
            },
        )

    # Extract the key from "Bearer xxx" format
    token = authorization
    if authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()

    # Validate the API key
    api_key = await APIKeyService.validate_key(session, token)
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": {
                    "message": "Invalid API key. Please check your API key and try again.",
                    "type": "authentication_error",
                    "code": "invalid_api_key",
                }
            },
        )

    return api_key, token


def get_client_ip(request: Request) -> str:
    """Extract client IP from request, considering proxy headers."""
    x_forwarded_for = request.headers.get("x-forwarded-for")
    if x_forwarded_for:
        return x_forwarded_for.split(",")[0].strip()
    x_real_ip = request.headers.get("x-real-ip")
    if x_real_ip:
        return x_real_ip.strip()
    client = request.client
    if client:
        return client.host
    return "unknown"


# ─── OpenAI-Compatible Endpoints ─────────────────────────────────────────

@router.get("/v1/models")
async def list_models(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    api_key_data: tuple = Depends(verify_api_key),
):
    """List available models. Proxies to the upstream provider."""
    api_key_model, api_key_str = api_key_data
    ip_address = get_client_ip(request)

    from app.services.provider_service import ProviderService

    active_providers = await ProviderService.get_active(session)
    if not active_providers:
        return JSONResponse(
            status_code=200,
            content={
                "object": "list",
                "data": [],
            },
        )

    provider = active_providers[0]
    result = await ProxyService.forward_request(
        session=session,
        provider=provider,
        actual_model=None,
        endpoint_path="/v1/models",
        body={},
        headers=dict(request.headers),
        method="GET",
    )

    await APIKeyService.update_usage(
        session, api_key_model, ip_address=ip_address
    )

    return JSONResponse(
        status_code=result["status_code"],
        content=result["body"],
    )


@router.post("/v1/chat/completions")
async def chat_completions(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    api_key_data: tuple = Depends(verify_api_key),
):
    """OpenAI-compatible chat completions endpoint."""
    api_key_model, api_key_str = api_key_data
    ip_address = get_client_ip(request)

    return await ProxyService.proxy_openai_endpoint(
        session=session,
        request=request,
        endpoint_path="/v1/chat/completions",
        api_key_model=api_key_model,
        api_key_name=api_key_model.name,
        ip_address=ip_address,
    )


@router.post("/v1/responses")
async def responses(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    api_key_data: tuple = Depends(verify_api_key),
):
    """OpenAI-compatible responses endpoint."""
    api_key_model, api_key_str = api_key_data
    ip_address = get_client_ip(request)

    return await ProxyService.proxy_openai_endpoint(
        session=session,
        request=request,
        endpoint_path="/v1/responses",
        api_key_model=api_key_model,
        api_key_name=api_key_model.name,
        ip_address=ip_address,
    )


@router.post("/v1/embeddings")
async def embeddings(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    api_key_data: tuple = Depends(verify_api_key),
):
    """OpenAI-compatible embeddings endpoint."""
    api_key_model, api_key_str = api_key_data
    ip_address = get_client_ip(request)

    return await ProxyService.proxy_openai_endpoint(
        session=session,
        request=request,
        endpoint_path="/v1/embeddings",
        api_key_model=api_key_model,
        api_key_name=api_key_model.name,
        ip_address=ip_address,
    )


@router.post("/v1/images/generations")
async def images_generations(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    api_key_data: tuple = Depends(verify_api_key),
):
    """OpenAI-compatible image generation endpoint."""
    api_key_model, api_key_str = api_key_data
    ip_address = get_client_ip(request)

    return await ProxyService.proxy_openai_endpoint(
        session=session,
        request=request,
        endpoint_path="/v1/images/generations",
        api_key_model=api_key_model,
        api_key_name=api_key_model.name,
        ip_address=ip_address,
    )


# ─── Generic catch-all for any future OpenAI endpoints ───────────────────

@router.api_route("/v1/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def generic_proxy(
    path: str,
    request: Request,
    session: AsyncSession = Depends(get_async_session),
    api_key_data: tuple = Depends(verify_api_key),
):
    """Catch-all proxy for any future OpenAI-compatible endpoints."""
    api_key_model, api_key_str = api_key_data
    ip_address = get_client_ip(request)

    return await ProxyService.proxy_openai_endpoint(
        session=session,
        request=request,
        endpoint_path=f"/v1/{path}",
        api_key_model=api_key_model,
        api_key_name=api_key_model.name,
        ip_address=ip_address,
    )