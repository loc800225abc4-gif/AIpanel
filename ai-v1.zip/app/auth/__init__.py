"""Authentication module with JWT and password hashing."""
from app.auth.security import (
    hash_password,
    verify_password,
    create_access_token,
    decode_access_token,
    get_current_user_from_cookie,
    COOKIE_NAME,
)

__all__ = [
    "hash_password",
    "verify_password",
    "create_access_token",
    "decode_access_token",
    "get_current_user_from_cookie",
    "COOKIE_NAME",
]