"""Security utilities: password hashing, JWT creation/verification."""

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database.session import get_async_session
from app.models.models import AdminUser

# Cookie name for dashboard session
COOKIE_NAME = "ai_gateway_session"

# Bearer token scheme for API
bearer_scheme = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash (PHP $2y$ and Python $2b$ compatible)."""
    # PHP uses $2y$ prefix; normalize to $2b$ for bcrypt library
    if hashed_password.startswith("$2y$"):
        hashed_password = "$2b$" + hashed_password[4:]
    try:
        return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())
    except ValueError:
        return False


def hash_api_key(api_key: str) -> str:
    """Create a SHA256 hash of an API key for fast prefix lookup."""
    return hashlib.sha256(api_key[:32].encode()).hexdigest()


def hash_full_api_key(api_key: str) -> str:
    """Create a SHA256 hash of the full API key for secure verification."""
    return hashlib.sha256(api_key.encode()).hexdigest()


def verify_api_key_hash(api_key: str, hashed: str) -> bool:
    """Verify an API key against its SHA256 hash."""
    return hashlib.sha256(api_key.encode()).hexdigest() == hashed


import logging

logger = logging.getLogger(__name__)


async def seed_default_admin(session: AsyncSession) -> None:
    """Ensure default admin exists (check existing PHP admins table first)."""
    from sqlalchemy import select

    result = await session.execute(
        select(AdminUser).where(AdminUser.username == settings.admin_username)
    )
    existing_admin = result.scalar_one_or_none()

    if existing_admin is None:
        admin = AdminUser(
            username=settings.admin_username,
            password=hash_password(settings.admin_password),
            email="admin@locnguyen.ai",
            full_name="AI Gateway Admin",
            role='super_admin',
            is_active=True,
        )
        session.add(admin)
        await session.commit()
        logger.info(f"Default admin user '{settings.admin_username}' created in admins table.")
    else:
        logger.info(f"Admin user '{settings.admin_username}' already exists.")


def generate_api_key() -> str:
    """Generate a user API key in format: loc_sk_{random_hex} (PHP-compatible)."""
    chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
    random_part = ''.join(secrets.choice(chars) for _ in range(48))
    return f"loc_sk_{random_part}"


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.jwt_expiration_minutes
        )
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(
        to_encode, settings.jwt_secret, algorithm=settings.jwt_algorithm
    )
    return encoded_jwt


def decode_access_token(token: str) -> Optional[dict]:
    """Decode and validate a JWT access token."""
    try:
        payload = jwt.decode(
            token, settings.jwt_secret, algorithms=[settings.jwt_algorithm]
        )
        return payload
    except JWTError:
        return None


async def get_current_user_from_cookie(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
) -> AdminUser:
    """Extract current admin user from session cookie or PHP session."""
    # First try JWT cookie (Python gateway session)
    token = request.cookies.get(COOKIE_NAME)
    if token:
        payload = decode_access_token(token)
        if payload:
            username: Optional[str] = payload.get("sub")
            if username:
                result = await session.execute(
                    select(AdminUser).where(AdminUser.username == username)
                )
                user = result.scalar_one_or_none()
                if user and user.is_active:
                    return user

    # Fallback: check PHP session (cookie: PHPSESSID)
    # The PHP login system uses a different auth flow
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"X-Redirect": "/login"},
    )


async def get_current_user(
    request: Request,
    session: AsyncSession = Depends(get_async_session),
) -> AdminUser:
    """Get current user from cookie (for dashboard) or bearer token (for API)."""
    # Try cookie first (for dashboard)
    token = request.cookies.get(COOKIE_NAME)
    if token:
        payload = decode_access_token(token)
        if payload:
            username = payload.get("sub")
            if username:
                result = await session.execute(
                    select(AdminUser).where(AdminUser.username == username)
                )
                user = result.scalar_one_or_none()
                if user and user.is_active:
                    return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
    )