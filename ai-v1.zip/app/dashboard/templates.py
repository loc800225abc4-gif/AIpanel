"""Jinja2 template rendering engine."""

import os
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

# Determine template directory
TEMPLATE_DIR = Path(__file__).resolve().parent.parent.parent / "templates"

# Initialize Jinja2 environment
_env = Environment(
    loader=FileSystemLoader(str(TEMPLATE_DIR)),
    autoescape=select_autoescape(["html", "xml"]),
    enable_async=False,
)

# Common context for all templates
BASE_CONTEXT = {
    "app_name": "AI Gateway",
    "app_version": "1.0.0",
    "current_year": "2026",
}


def render_template(template_name: str, context: dict[str, Any]) -> str:
    """Render a Jinja2 template with the given context.

    Args:
        template_name: Name of the template file (e.g., 'dashboard.html').
        context: Dictionary of template variables.

    Returns:
        Rendered HTML string.
    """
    merged_context = {**BASE_CONTEXT, **context}

    # Add request path for active nav highlighting
    if "request" in context:
        merged_context["current_path"] = str(context["request"].url.path)

    template = _env.get_template(template_name)
    return template.render(**merged_context)