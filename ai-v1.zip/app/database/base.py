"""SQLAlchemy declarative base and table creation (MySQL shared with PHP)."""

import logging

from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import text

from app.database.session import async_engine

logger = logging.getLogger(__name__)


class Base(DeclarativeBase):
    """Base class for all database models."""
    pass


async def create_tables() -> None:
    """Create only the gateway-specific tables (skip tables managed by PHP)."""
    from app.models.models import (
        AdminUser, User, Provider, ModelMapping, APIKey, RequestLog
    )  # noqa: F401

    async with async_engine.begin() as conn:
        # Only create gateway-specific tables that may not exist yet
        # PHP tables (admins, users, api_keys, ai_models, etc.) are already present
        await conn.run_sync(
            lambda sync_conn: Base.metadata.create_all(
                sync_conn,
                tables=[
                    Base.metadata.tables[t]
                    for t in ["providers", "model_mappings", "request_logs"]
                    if t in Base.metadata.tables
                ],
            )
        )

    # Also ensure the api_keys table has gateway columns via ALTER (safe to run)
    try:
        from app.database.session import sync_engine
        with sync_engine.begin() as conn:
            # Add gateway-specific columns to existing api_keys table (if missing)
            gateway_columns = [
                ("key_hash", "VARCHAR(255)"),
                ("key_prefix", "VARCHAR(20)"),
                ("key_suffix", "VARCHAR(10)"),
                ("full_key_hash", "VARCHAR(255) UNIQUE"),
                ("is_locked", "TINYINT(1) DEFAULT 0"),
                ("quota_type", "VARCHAR(20) DEFAULT 'unlimited'"),
                ("quota_value", "INT DEFAULT 0"),
                ("quota_used", "INT DEFAULT 0"),
                ("quota_reset_at", "DATETIME NULL"),
                ("rpm_limit", "INT DEFAULT 0"),
                ("tpm_limit", "INT DEFAULT 0"),
                ("last_used_ip", "VARCHAR(50) NULL"),
                ("total_prompt_tokens", "INT DEFAULT 0"),
                ("total_completion_tokens", "INT DEFAULT 0"),
                ("total_tokens", "INT DEFAULT 0"),
            ]
            for col_name, col_def in gateway_columns:
                try:
                    conn.execute(text(
                        f"ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS {col_name} {col_def}"
                    ))
                except Exception:
                    pass  # MySQL doesn't support IF NOT EXISTS for ADD COLUMN
    except Exception as e:
        logger.warning(f"Could not add gateway columns to api_keys: {e}")
