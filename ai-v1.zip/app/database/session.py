"""Database session management for SQLAlchemy with async support (MySQL)."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.config import settings

# Async engine for FastAPI (MySQL via aiomysql)
async_engine = create_async_engine(
    settings.database_url,
    echo=False,
    future=True,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600,
)

# Legacy alias
engine = async_engine

# Sync engine for seed data and direct queries (MySQL via pymysql)
sync_engine = create_engine(
    settings.sync_database_url,
    echo=False,
    pool_size=5,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=3600,
)

# Session factories
async_session_factory = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

sync_session_factory = sessionmaker(
    sync_engine,
    expire_on_commit=False,
)


@asynccontextmanager
async def get_session_context():
    """Async context manager that provides a database session for startup tasks."""
    session = async_session_factory()
    try:
        yield session
    finally:
        await session.close()


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency that provides an async database session."""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
