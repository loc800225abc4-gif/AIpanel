"""Custom middleware for security headers, CORS, and exception handling."""

import time
import traceback
import logging

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import settings

logger = logging.getLogger("ai_gateway")


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add security headers to all responses."""

    async def dispatch(self, request: Request, call_next) -> Response:
        response = await call_next(request)

        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = (
            "max-age=31536000; includeSubDomains"
        )
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Server"] = ""  # Hide server info
        response.headers["X-Powered-By"] = ""  # Hide framework info

        return response


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log incoming requests with basic info."""

    async def dispatch(self, request: Request, call_next) -> Response:
        start_time = time.time()
        response = await call_next(request)
        duration_ms = (time.time() - start_time) * 1000

        # Log basic request info (avoid logging sensitive headers)
        logger.info(
            "Request: %s %s | Status: %s | Duration: %.2fms",
            request.method,
            request.url.path,
            response.status_code,
            duration_ms,
        )

        return response


class ExceptionHandlerMiddleware(BaseHTTPMiddleware):
    """Global exception handler that prevents leaking sensitive information."""

    async def dispatch(self, request: Request, call_next) -> Response:
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            logger.error(
                f"Unhandled exception on {request.method} {request.url.path}: {str(exc)}"
            )
            logger.error(traceback.format_exc())

            # Never expose stack traces
            return JSONResponse(
                status_code=500,
                content={
                    "error": {
                        "message": "Internal server error",
                        "type": "internal_error",
                        "code": "internal_error",
                    }
                },
            )


def add_middleware(app: FastAPI) -> None:
    """Add all middleware to the FastAPI application."""

    # CORS - Allow from any origin for API access
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["*"],
    )

    # Security headers
    app.add_middleware(SecurityHeadersMiddleware)

    # Exception handler
    app.add_middleware(ExceptionHandlerMiddleware)