"""Service for managing user API keys."""

from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import func, select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import APIKey
from app.auth.security import (
    generate_api_key,
    hash_api_key,
    hash_full_api_key,
)
from app.schemas.schemas import (
    APIKeyCreate,
    APIKeyUpdate,
    APIKeyResponse,
    APIKeyCreateResponse,
)


class APIKeyService:
    """Service for API key CRUD and validation."""

    @staticmethod
    async def get_all(
        session: AsyncSession,
        *,
        page: int = 1,
        page_size: int = 50,
    ) -> tuple[List[APIKey], int]:
        """Get paginated API keys."""
        # Total count
        count_query = select(func.count(APIKey.id))
        result = await session.execute(count_query)
        total = result.scalar() or 0

        # Paginated results
        query = (
            select(APIKey)
            .order_by(APIKey.created_at.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        result = await session.execute(query)
        keys = list(result.scalars().all())

        return keys, total

    @staticmethod
    async def get_by_id(
        session: AsyncSession, key_id: int
    ) -> Optional[APIKey]:
        """Get an API key by ID."""
        result = await session.execute(
            select(APIKey).where(APIKey.id == key_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_by_key_hash(
        session: AsyncSession, full_key: str
    ) -> Optional[APIKey]:
        """Find an API key by its prefix hash for fast lookup,
        then verify the full key."""
        prefix_hash = hash_api_key(full_key)
        result = await session.execute(
            select(APIKey).where(APIKey.key_hash == prefix_hash)
        )
        keys = result.scalars().all()

        # Verify against full SHA256 hash
        from app.auth.security import verify_api_key_hash
        for key in keys:
            if verify_api_key_hash(full_key, key.full_key_hash):
                return key
        return None

    @staticmethod
    async def create(
        session: AsyncSession, data: APIKeyCreate
    ) -> tuple[APIKey, str]:
        """Create a new API key. Returns the model and the plain-text key."""
        plain_key = generate_api_key()

        api_key = APIKey(
            name=data.name,
            api_key=plain_key,  # Plain key for PHP compatibility
            key_hash=hash_api_key(plain_key),
            key_prefix=plain_key[:15],
            key_suffix=plain_key[-4:],
            full_key_hash=hash_full_api_key(plain_key),
            quota_type=data.quota_type,
            quota_value=data.quota_value,
            quota_used=0,
            rpm_limit=data.rpm_limit,
            tpm_limit=data.tpm_limit,
            expires_at=data.expires_at,
        )

        session.add(api_key)
        await session.flush()
        await session.refresh(api_key)

        return api_key, plain_key

    @staticmethod
    async def update(
        session: AsyncSession, key_id: int, data: APIKeyUpdate
    ) -> Optional[APIKey]:
        """Update an existing API key."""
        api_key = await APIKeyService.get_by_id(session, key_id)
        if not api_key:
            return None

        update_data = data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(api_key, key, value)

        await session.flush()
        await session.refresh(api_key)
        return api_key

    @staticmethod
    async def delete(session: AsyncSession, key_id: int) -> bool:
        """Delete an API key."""
        api_key = await APIKeyService.get_by_id(session, key_id)
        if not api_key:
            return False
        await session.delete(api_key)
        await session.flush()
        return True

    @staticmethod
    async def toggle_lock(
        session: AsyncSession, key_id: int
    ) -> Optional[APIKey]:
        """Toggle the lock status of an API key."""
        api_key = await APIKeyService.get_by_id(session, key_id)
        if not api_key:
            return None
        api_key.is_locked = not api_key.is_locked
        await session.flush()
        await session.refresh(api_key)
        return api_key

    @staticmethod
    async def validate_key(
        session: AsyncSession, full_key: str
    ) -> Optional[APIKey]:
        """Validate an API key: check existence, active status, lock, expiry, quota."""
        api_key = await APIKeyService.get_by_key_hash(session, full_key)
        if not api_key:
            return None

        # Check if active
        if not api_key.is_active:
            return None

        # Check if locked
        if api_key.is_locked:
            return None

        # Check expiry
        if api_key.expires_at and api_key.expires_at < datetime.now(timezone.utc):
            return None

        # Check quota
        if api_key.quota_type != "unlimited" and api_key.quota_value > 0:
            if api_key.quota_used >= api_key.quota_value:
                # Check if quota should reset
                if api_key.quota_reset_at and api_key.quota_reset_at < datetime.now(timezone.utc):
                    api_key.quota_used = 0
                    api_key.quota_reset_at = APIKeyService._get_next_reset(api_key.quota_type)
                    await session.flush()
                else:
                    return None

        return api_key

    @staticmethod
    def _get_next_reset(quota_type: str) -> datetime:
        """Calculate the next quota reset time."""
        now = datetime.now(timezone.utc)
        if quota_type == "daily":
            return now.replace(hour=23, minute=59, second=59, microsecond=999999)
        elif quota_type == "monthly":
            # Last day of current month
            import calendar
            last_day = calendar.monthrange(now.year, now.month)[1]
            return now.replace(
                day=last_day, hour=23, minute=59, second=59, microsecond=999999
            )
        return now

    @staticmethod
    async def check_and_deduct_credits(
        session: AsyncSession,
        api_key: APIKey,
        *,
        estimated_tokens: int = 0,
    ) -> bool:
        """Check if the user has enough credits and deduct estimated cost.

        Returns True if credits are sufficient and deducted.
        Returns False if user has no credits or insufficient.
        """
        from app.models.models import User
        from sqlalchemy import select

        # If no user_id on the API key, skip credit check (admin-created keys)
        if not api_key.user_id:
            return True

        # Get user
        result = await session.execute(
            select(User).where(User.id == api_key.user_id)
        )
        user = result.scalar_one_or_none()
        if not user or not user.is_active:
            return False

        # Get credits_per_token setting from PHP admin_settings table
        credits_per_token = 0.001  # default
        try:
            from sqlalchemy import text
            setting_result = await session.execute(
                text("SELECT setting_value FROM admin_settings WHERE setting_key = 'credits_per_token' LIMIT 1")
            )
            row = setting_result.fetchone()
            if row and row[0]:
                credits_per_token = float(row[0])
        except Exception:
            pass

        # Calculate estimated cost
        estimated_cost = max(1, int(estimated_tokens * credits_per_token))

        # Check credits
        if float(user.credits) < estimated_cost:
            return False

        return True

    @staticmethod
    async def deduct_credits(
        session: AsyncSession,
        api_key: APIKey,
        *,
        total_tokens: int = 0,
        description: str = "",
    ) -> Optional[int]:
        """Deduct credits from user based on actual token usage.

        Returns the actual cost deducted, or None if deduction failed.
        """
        from app.models.models import User
        from sqlalchemy import select, text

        if not api_key.user_id:
            return 0

        # Get user
        result = await session.execute(
            select(User).where(User.id == api_key.user_id)
        )
        user = result.scalar_one_or_none()
        if not user:
            return None

        # Get credits_per_token setting
        credits_per_token = 0.001
        try:
            setting_result = await session.execute(
                text("SELECT setting_value FROM admin_settings WHERE setting_key = 'credits_per_token' LIMIT 1")
            )
            row = setting_result.fetchone()
            if row and row[0]:
                credits_per_token = float(row[0])
        except Exception:
            pass

        # Calculate actual cost
        actual_cost = max(1, int(total_tokens * credits_per_token))

        if float(user.credits) < actual_cost:
            actual_cost = int(float(user.credits))  # Deduct all remaining

        if actual_cost > 0:
            user.credits = float(user.credits) - actual_cost

            # Log to credit_logs
            if description:
                desc = description[:200]
            else:
                desc = f"API usage: {api_key.name}"

            try:
                await session.execute(
                    text("INSERT INTO credit_logs (user_id, amount, type, description) VALUES (:uid, :amt, 'usage', :desc)"),
                    {"uid": api_key.user_id, "amt": actual_cost, "desc": desc}
                )
            except Exception:
                pass

            await session.flush()
            return actual_cost

        return 0

    @staticmethod
    async def update_usage(
        session: AsyncSession,
        api_key: APIKey,
        *,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        ip_address: Optional[str] = None,
    ) -> None:
        """Update usage statistics for an API key."""
        total = prompt_tokens + completion_tokens

        api_key.total_requests = (api_key.total_requests or 0) + 1
        api_key.total_prompt_tokens = (api_key.total_prompt_tokens or 0) + prompt_tokens
        api_key.total_completion_tokens = (api_key.total_completion_tokens or 0) + completion_tokens
        api_key.total_tokens = (api_key.total_tokens or 0) + total
        api_key.last_used = datetime.now(timezone.utc)
        api_key.last_used_ip = ip_address

        # Update quota
        if api_key.quota_type == "total_tokens" and api_key.quota_value > 0:
            api_key.quota_used = (api_key.quota_used or 0) + total
        elif api_key.quota_type in ("daily", "monthly") and api_key.quota_value > 0:
            api_key.quota_used = (api_key.quota_used or 0) + 1

        await session.flush()

    @staticmethod
    def to_response(api_key: APIKey) -> APIKeyResponse:
        """Convert an APIKey model to a response."""
        return APIKeyResponse(
            id=api_key.id,
            name=api_key.name,
            key_display=f"{api_key.key_prefix}...{api_key.key_suffix}",
            is_active=api_key.is_active,
            is_locked=api_key.is_locked,
            quota_type=api_key.quota_type,
            quota_value=api_key.quota_value,
            quota_used=api_key.quota_used,
            rpm_limit=api_key.rpm_limit,
            tpm_limit=api_key.tpm_limit,
            expires_at=api_key.expires_at,
            last_used=api_key.last_used,
            last_used_ip=api_key.last_used_ip,
            total_requests=api_key.total_requests,
            total_prompt_tokens=api_key.total_prompt_tokens,
            total_completion_tokens=api_key.total_completion_tokens,
            total_tokens=api_key.total_tokens,
            created_at=api_key.created_at,
        )

    @staticmethod
    def to_create_response(api_key: APIKey, plain_key: str) -> APIKeyCreateResponse:
        """Convert to a create response that includes the full key once."""
        return APIKeyCreateResponse(
            id=api_key.id,
            name=api_key.name,
            api_key=plain_key,
            key_display=f"{api_key.key_prefix}...{api_key.key_suffix}",
            created_at=api_key.created_at,
        )