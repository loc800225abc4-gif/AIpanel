"""Dashboard service for gathering statistics."""

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import APIKey, Provider
from app.schemas.schemas import DashboardStats
from app.services.log_service import LogService


class DashboardService:
    """Service for dashboard data aggregation."""

    @staticmethod
    async def get_stats(session: AsyncSession) -> DashboardStats:
        """Get all dashboard statistics."""

        # API Key counts
        total_keys_result = await session.execute(
            select(func.count(APIKey.id))
        )
        total_api_keys = total_keys_result.scalar() or 0

        active_keys_result = await session.execute(
            select(func.count(APIKey.id)).where(
                APIKey.is_active == True,
                APIKey.is_locked == False,
            )
        )
        active_api_keys = active_keys_result.scalar() or 0

        # Provider counts
        providers_result = await session.execute(
            select(func.count(Provider.id))
        )
        providers_count = providers_result.scalar() or 0

        active_providers_result = await session.execute(
            select(func.count(Provider.id)).where(Provider.is_active == True)
        )
        active_providers = active_providers_result.scalar() or 0

        healthy_providers_result = await session.execute(
            select(func.count(Provider.id)).where(Provider.health_status == "healthy")
        )
        healthy_providers = healthy_providers_result.scalar() or 0

        # Get log stats
        log_stats = await LogService.get_stats(session)

        return DashboardStats(
            total_api_keys=total_api_keys,
            active_api_keys=active_api_keys,
            requests_today=log_stats["requests_today"],
            total_requests=log_stats["total_requests"],
            prompt_tokens=log_stats["prompt_tokens"],
            completion_tokens=log_stats["completion_tokens"],
            total_tokens=log_stats["total_tokens"],
            avg_latency_ms=log_stats["avg_latency_ms"],
            providers_count=providers_count,
            active_providers=active_providers,
            healthy_providers=healthy_providers,
        )