"""Service for request logging and analytics."""

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import func, select, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import RequestLog


class LogService:
    """Service for managing request logs."""

    @staticmethod
    async def create_log(
        session: AsyncSession,
        *,
        ip_address: Optional[str] = None,
        api_key_id: Optional[int] = None,
        api_key_name: Optional[str] = None,
        endpoint: str = "",
        method: str = "POST",
        external_model: Optional[str] = None,
        actual_model: Optional[str] = None,
        provider_name: Optional[str] = None,
        latency_ms: Optional[float] = None,
        status_code: int = 200,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        total_tokens: int = 0,
        error_message: Optional[str] = None,
        is_streaming: bool = False,
    ) -> RequestLog:
        """Create a new request log entry."""
        log_entry = RequestLog(
            request_id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc),
            ip_address=ip_address,
            api_key_id=api_key_id,
            api_key_name=api_key_name,
            endpoint=endpoint,
            method=method,
            external_model=external_model,
            actual_model=actual_model,
            provider_name=provider_name,
            latency_ms=latency_ms,
            status_code=status_code,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            error_message=error_message,
            is_streaming=is_streaming,
        )
        session.add(log_entry)
        await session.flush()
        return log_entry

    @staticmethod
    async def get_logs(
        session: AsyncSession,
        *,
        page: int = 1,
        page_size: int = 50,
        search: Optional[str] = None,
        status_code: Optional[int] = None,
        endpoint: Optional[str] = None,
    ) -> tuple[list[RequestLog], int]:
        """Get paginated request logs with optional filters."""
        query = select(RequestLog)

        conditions = []
        if search:
            search_term = f"%{search}%"
            conditions.append(
                (RequestLog.api_key_name.ilike(search_term))
                | (RequestLog.endpoint.ilike(search_term))
                | (RequestLog.external_model.ilike(search_term))
                | (RequestLog.ip_address.ilike(search_term))
            )
        if status_code is not None:
            conditions.append(RequestLog.status_code == status_code)
        if endpoint:
            conditions.append(RequestLog.endpoint.ilike(f"%{endpoint}%"))

        if conditions:
            query = query.where(and_(*conditions))

        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        result = await session.execute(count_query)
        total = result.scalar() or 0

        # Get paginated results
        query = query.order_by(desc(RequestLog.created_at))
        query = query.offset((page - 1) * page_size).limit(page_size)
        result = await session.execute(query)
        logs = list(result.scalars().all())

        return logs, total

    @staticmethod
    async def get_stats(
        session: AsyncSession,
    ) -> dict:
        """Get overall statistics from logs."""
        # Today's date in UTC
        now = datetime.now(timezone.utc)
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

        # Requests today
        result = await session.execute(
            select(func.count(RequestLog.id)).where(
                RequestLog.timestamp >= today_start
            )
        )
        requests_today = result.scalar() or 0

        # Total requests
        result = await session.execute(select(func.count(RequestLog.id)))
        total_requests = result.scalar() or 0

        # Token sums
        result = await session.execute(
            select(
                func.sum(RequestLog.prompt_tokens),
                func.sum(RequestLog.completion_tokens),
                func.sum(RequestLog.total_tokens),
            )
        )
        row = result.one()
        total_prompt_tokens = row[0] or 0
        total_completion_tokens = row[1] or 0
        total_tokens = row[2] or 0

        # Average latency
        result = await session.execute(
            select(func.avg(RequestLog.latency_ms)).where(
                RequestLog.latency_ms.isnot(None)
            )
        )
        avg_latency = result.scalar() or 0.0

        return {
            "requests_today": requests_today,
            "total_requests": total_requests,
            "prompt_tokens": int(total_prompt_tokens),
            "completion_tokens": int(total_completion_tokens),
            "total_tokens": int(total_tokens),
            "avg_latency_ms": round(float(avg_latency), 2),
        }

    @staticmethod
    async def export_csv(
        session: AsyncSession,
    ) -> str:
        """Export all logs as CSV string."""
        result = await session.execute(
            select(RequestLog).order_by(desc(RequestLog.created_at))
        )
        logs = result.scalars().all()

        import io
        import csv

        output = io.StringIO()
        writer = csv.writer(output)

        # Header
        writer.writerow([
            "ID", "Request ID", "Timestamp", "IP Address", "API Key",
            "Endpoint", "Method", "External Model", "Actual Model",
            "Provider", "Latency (ms)", "Status Code", "Prompt Tokens",
            "Completion Tokens", "Total Tokens", "Streaming", "Error"
        ])

        for log in logs:
            writer.writerow([
                log.id,
                log.request_id,
                log.timestamp.isoformat() if log.timestamp else "",
                log.ip_address or "",
                log.api_key_name or "",
                log.endpoint,
                log.method,
                log.external_model or "",
                log.actual_model or "",
                log.provider_name or "",
                log.latency_ms or "",
                log.status_code,
                log.prompt_tokens,
                log.completion_tokens,
                log.total_tokens,
                log.is_streaming,
                log.error_message or "",
            ])

        return output.getvalue()