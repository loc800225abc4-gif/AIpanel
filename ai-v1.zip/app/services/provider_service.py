"""Service for managing AI providers and model mappings."""

from typing import List, Optional

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Provider, ModelMapping
from app.schemas.schemas import (
    ProviderCreate,
    ProviderUpdate,
    ProviderResponse,
    ModelMappingCreate,
    ModelMappingResponse,
)


class ProviderService:
    """Service for provider CRUD and health checks."""

    @staticmethod
    def _mask_api_key(api_key: str) -> str:
        """Mask API key for safe display."""
        if len(api_key) <= 8:
            return "*" * len(api_key)
        return api_key[:6] + "*" * (len(api_key) - 10) + api_key[-4:]

    @staticmethod
    async def get_all(session: AsyncSession) -> List[Provider]:
        """Get all providers with their model mappings."""
        result = await session.execute(
            select(Provider).order_by(Provider.created_at.desc())
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_by_id(session: AsyncSession, provider_id: int) -> Optional[Provider]:
        """Get a provider by ID."""
        result = await session.execute(
            select(Provider).where(Provider.id == provider_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_active(session: AsyncSession) -> List[Provider]:
        """Get all active providers."""
        result = await session.execute(
            select(Provider).where(Provider.is_active == True)
        )
        return list(result.scalars().all())

    @staticmethod
    async def create(
        session: AsyncSession, data: ProviderCreate
    ) -> Provider:
        """Create a new provider."""
        provider = Provider(
            name=data.name,
            base_url=data.base_url.rstrip("/"),
            api_key=data.api_key,
            timeout=data.timeout,
            verify_ssl=data.verify_ssl,
            supports_streaming=data.supports_streaming,
            is_active=data.is_active,
        )
        session.add(provider)
        await session.flush()
        await session.refresh(provider)
        return provider

    @staticmethod
    async def update(
        session: AsyncSession, provider_id: int, data: ProviderUpdate
    ) -> Optional[Provider]:
        """Update an existing provider."""
        provider = await ProviderService.get_by_id(session, provider_id)
        if not provider:
            return None

        update_data = data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            if key == "base_url" and value:
                value = value.rstrip("/")
            setattr(provider, key, value)

        await session.flush()
        await session.refresh(provider)
        return provider

    @staticmethod
    async def delete(session: AsyncSession, provider_id: int) -> bool:
        """Delete a provider and its model mappings."""
        provider = await ProviderService.get_by_id(session, provider_id)
        if not provider:
            return False
        await session.delete(provider)
        await session.flush()
        return True

    @staticmethod
    async def check_health(
        session: AsyncSession, provider_id: int
    ) -> str:
        """Check the health of a provider by calling its models endpoint."""
        from datetime import datetime, timezone

        provider = await ProviderService.get_by_id(session, provider_id)
        if not provider:
            return "unknown"

        try:
            async with httpx.AsyncClient(
                timeout=10.0,
                verify=provider.verify_ssl,
            ) as client:
                response = await client.get(
                    f"{provider.base_url}/models",
                    headers={"Authorization": f"Bearer {provider.api_key}"},
                )
                if response.status_code == 200:
                    provider.health_status = "healthy"
                else:
                    provider.health_status = "unhealthy"
        except Exception:
            provider.health_status = "unhealthy"

        provider.last_checked = datetime.now(timezone.utc)
        await session.flush()
        return provider.health_status

    @staticmethod
    async def to_response(provider: Provider) -> ProviderResponse:
        """Convert a Provider model to a response with masked API key."""
        return ProviderResponse(
            id=provider.id,
            name=provider.name,
            base_url=provider.base_url,
            api_key=ProviderService._mask_api_key(provider.api_key),
            timeout=provider.timeout,
            verify_ssl=provider.verify_ssl,
            supports_streaming=provider.supports_streaming,
            is_active=provider.is_active,
            health_status=provider.health_status,
            last_checked=provider.last_checked,
            created_at=provider.created_at,
            updated_at=provider.updated_at,
            model_mappings=[],
        )

    # ─── Model Mapping Methods ─────────────────────────────────────────────

    @staticmethod
    async def add_model_mapping(
        session: AsyncSession,
        provider_id: int,
        data: ModelMappingCreate,
    ) -> Optional[ModelMapping]:
        """Add a model mapping to a provider."""
        provider = await ProviderService.get_by_id(session, provider_id)
        if not provider:
            return None

        mapping = ModelMapping(
            provider_id=provider_id,
            external_model=data.external_model,
            actual_model=data.actual_model,
            is_active=data.is_active,
        )
        session.add(mapping)
        await session.flush()
        await session.refresh(mapping)
        return mapping

    @staticmethod
    async def remove_model_mapping(
        session: AsyncSession, mapping_id: int
    ) -> bool:
        """Remove a model mapping."""
        result = await session.execute(
            select(ModelMapping).where(ModelMapping.id == mapping_id)
        )
        mapping = result.scalar_one_or_none()
        if not mapping:
            return False
        await session.delete(mapping)
        await session.flush()
        return True

    @staticmethod
    async def get_mapping_by_external_model(
        session: AsyncSession, external_model: str
    ) -> Optional[tuple[Provider, ModelMapping]]:
        """Find the active provider and mapping for an external model name."""
        result = await session.execute(
            select(ModelMapping)
            .join(Provider)
            .where(
                ModelMapping.external_model == external_model,
                ModelMapping.is_active == True,
                Provider.is_active == True,
            )
        )
        mapping = result.scalar_one_or_none()
        if mapping:
            return mapping.provider, mapping
        return None