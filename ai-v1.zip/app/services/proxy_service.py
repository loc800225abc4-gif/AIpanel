"""Proxy service for forwarding requests to AI providers."""

import json
import time
import logging
from typing import Any, AsyncGenerator, Dict, Optional

import httpx
from fastapi import Request
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.models import Provider, ModelMapping
from app.services.provider_service import ProviderService

logger = logging.getLogger("ai_gateway")


class ProxyService:
    """Service for proxying requests to upstream AI providers."""

    @staticmethod
    async def find_provider_for_model(
        session: AsyncSession,
        model: str,
    ) -> Optional[tuple[Provider, str]]:
        """Find the appropriate provider and actual model name for a given external model.

        If no mapping exists, use the model name as-is and try all active providers.
        """
        result = await ProviderService.get_mapping_by_external_model(session, model)
        if result:
            return result[0], result[1].actual_model

        # No mapping found - use the first active provider
        active_providers = await ProviderService.get_active(session)
        if active_providers:
            return active_providers[0], model

        return None

    @staticmethod
    async def forward_request(
        session: AsyncSession,
        provider: Provider,
        actual_model: Optional[str],
        endpoint_path: str,
        *,
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        method: str = "POST",
    ) -> Dict[str, Any]:
        """Forward a non-streaming request to the provider and return the response.

        Args:
            session: Database session (unused, kept for interface consistency).
            provider: The provider configuration.
            actual_model: The actual model name to send to the provider.
                If None, the original body is sent without model replacement.
            endpoint_path: The API endpoint path (e.g., /v1/chat/completions).
            body: The already-read JSON request body as a dict.
            headers: The original request headers to forward.
            method: The HTTP method to use.
        """
        start_time = time.time()

        # Clone the body so we don't mutate the caller's dict
        if body is None:
            body = {}

        # Replace the model with the actual provider model
        if actual_model is not None:
            body["model"] = actual_model

        # Build target URL
        target_url = f"{provider.base_url}{endpoint_path}"

        # Build forwarding headers
        forward_headers = dict(headers) if headers else {}
        forward_headers.pop("host", None)
        forward_headers.pop("content-length", None)
        forward_headers.pop("authorization", None)
        forward_headers["Authorization"] = f"Bearer {provider.api_key}"
        forward_headers["Content-Type"] = "application/json"

        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(provider.timeout),
                verify=provider.verify_ssl,
            ) as client:
                response = await client.request(
                    method=method,
                    url=target_url,
                    headers=forward_headers,
                    json=body,
                )

                latency_ms = (time.time() - start_time) * 1000

                # Try to parse response JSON
                response_data = {}
                try:
                    response_data = response.json()
                except Exception:
                    response_data = {}

                # Extract token usage from OpenAI-compatible response
                usage = response_data.get("usage", {})
                prompt_tokens = usage.get("prompt_tokens", 0)
                completion_tokens = usage.get("completion_tokens", 0)
                total_tokens = usage.get("total_tokens", 0)

                if response.status_code >= 400:
                    error_message = str(response_data.get("error", response.text[:500]))
                    return {
                        "status_code": response.status_code,
                        "headers": dict(response.headers),
                        "body": response_data,
                        "latency_ms": latency_ms,
                        "prompt_tokens": prompt_tokens,
                        "completion_tokens": completion_tokens,
                        "total_tokens": total_tokens,
                        "error": error_message,
                    }

                return {
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "body": response_data,
                    "latency_ms": latency_ms,
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": total_tokens,
                    "error": None,
                }

        except httpx.TimeoutException:
            latency_ms = (time.time() - start_time) * 1000
            return {
                "status_code": 504,
                "headers": {},
                "body": {"error": {"message": "Upstream provider timeout", "type": "timeout"}},
                "latency_ms": latency_ms,
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
                "error": "Upstream timeout",
            }
        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            logger.error(f"Proxy error: {str(e)}")
            return {
                "status_code": 502,
                "headers": {},
                "body": {"error": {"message": "Bad gateway", "type": "proxy_error"}},
                "latency_ms": latency_ms,
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
                "error": str(e)[:500],
            }

    @staticmethod
    async def forward_streaming_request(
        session: AsyncSession,
        provider: Provider,
        actual_model: Optional[str],
        endpoint_path: str,
        *,
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        method: str = "POST",
    ) -> AsyncGenerator[bytes, None]:
        """Forward a streaming request to the provider and yield SSE chunks.

        Args:
            session: Database session (unused, kept for interface consistency).
            provider: The provider configuration.
            actual_model: The actual model name to send. If None, model is not replaced.
            endpoint_path: The API endpoint path.
            body: The already-read JSON request body as a dict.
            headers: The original request headers to forward.
            method: The HTTP method to use.
        """
        # Clone the body so we don't mutate the caller's dict
        if body is None:
            body = {}

        # Replace the model with the actual provider model
        if actual_model is not None:
            body["model"] = actual_model

        # Build target URL
        target_url = f"{provider.base_url}{endpoint_path}"

        # Build forwarding headers
        forward_headers = dict(headers) if headers else {}
        forward_headers.pop("host", None)
        forward_headers.pop("content-length", None)
        forward_headers.pop("authorization", None)
        forward_headers["Authorization"] = f"Bearer {provider.api_key}"
        forward_headers["Content-Type"] = "application/json"

        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(provider.timeout, read=None),
                verify=provider.verify_ssl,
            ) as client:
                async with client.stream(
                    method=method,
                    url=target_url,
                    headers=forward_headers,
                    json=body,
                ) as response:
                    if response.status_code >= 400:
                        # Read error and yield as a single chunk
                        error_body = await response.aread()
                        yield error_body
                        return

                    async for chunk in response.aiter_bytes():
                        yield chunk

        except Exception as e:
            logger.error(f"Streaming proxy error: {str(e)}")
            error_response = json.dumps({
                "error": {
                    "message": "Streaming connection error",
                    "type": "proxy_error",
                    "code": "proxy_error",
                }
            })
            yield error_response.encode("utf-8")

    @staticmethod
    def extract_tokens_from_streaming_chunks(
        chunks: list[bytes],
    ) -> tuple[int, int, int]:
        """Extract token usage from streaming response chunks.
        
        Handles chunk splitting by joining all raw bytes first,
        then parsing complete SSE lines with a buffer.
        """
        prompt_tokens = 0
        completion_tokens = 0
        total_tokens = 0

        # Join all chunks into one big text buffer to handle splits
        try:
            full_text = b"".join(chunks).decode("utf-8")
        except Exception:
            # Try replacing invalid bytes
            try:
                full_text = b"".join(chunks).decode("utf-8", errors="replace")
            except Exception:
                return 0, 0, 0

        # Parse line-by-line (SSE: "data: {...}\n\n")
        buffer = ""
        for line in full_text.split("\n"):
            line = line.strip()
            if not line:
                continue
            if line.startswith("data: "):
                data_str = line[6:]
                if data_str == "[DONE]":
                    continue
                try:
                    data = json.loads(data_str)
                    usage = data.get("usage") or {}
                    if usage:
                        prompt_tokens = usage.get("prompt_tokens", prompt_tokens)
                        completion_tokens = usage.get("completion_tokens", completion_tokens)
                        total_tokens = usage.get("total_tokens", total_tokens)
                except (json.JSONDecodeError, AttributeError):
                    continue

        return prompt_tokens, completion_tokens, total_tokens

    @staticmethod
    async def proxy_openai_endpoint(
        session: AsyncSession,
        request: Request,
        endpoint_path: str,
        *,
        api_key_model=None,
        api_key_name: Optional[str] = None,
        ip_address: Optional[str] = None,
        external_model: Optional[str] = None,
    ) -> JSONResponse | StreamingResponse:
        """Main proxy handler for all OpenAI-compatible endpoints.

        Reads the request body ONCE, extracts model and stream flag,
        then passes the body dict downstream so stream isn't consumed twice.
        """
        from app.services.log_service import LogService
        from app.services.apikey_service import APIKeyService

        start_time = time.time()

        # ── Read the request body ONCE ──────────────────────────────────
        body: Dict[str, Any] = {}
        try:
            raw_body = await request.body()
            if raw_body:
                body = json.loads(raw_body)
        except (json.JSONDecodeError, Exception):
            body = {}

        # Determine model from body or override
        model_name = external_model or body.get("model", "unknown")

        # Determine streaming flag
        is_streaming = body.get("stream", False) and isinstance(body.get("stream"), bool)

        # ── Find provider and map model ─────────────────────────────────
        provider_result = await ProxyService.find_provider_for_model(
            session, model_name
        )

        if provider_result is None:
            # Log the failed request
            await LogService.create_log(
                session,
                ip_address=ip_address,
                api_key_id=api_key_model.id if api_key_model else None,
                api_key_name=api_key_name,
                endpoint=endpoint_path,
                method=request.method,
                external_model=model_name,
                actual_model=None,
                provider_name=None,
                latency_ms=None,
                status_code=503,
                error_message="No active provider available",
            )
            return JSONResponse(
                status_code=503,
                content={
                    "error": {
                        "message": "No active AI provider configured. Please contact the administrator.",
                        "type": "service_unavailable",
                        "code": "no_provider",
                    }
                },
            )

        provider, actual_model = provider_result

        # Request headers snapshot (before stream is consumed)
        request_headers = dict(request.headers)
        request_method = request.method

        # ── Handle Streaming ────────────────────────────────────────────
        if is_streaming and provider.supports_streaming:
            # Check credits before streaming
            estimated_tokens = 1000
            if body.get("messages"):
                all_content = ""
                for msg in body["messages"]:
                    if isinstance(msg.get("content"), str):
                        all_content += msg["content"]
                    elif isinstance(msg.get("content"), list):
                        for part in msg["content"]:
                            all_content += part.get("text", "")
                estimated_tokens = max(500, len(all_content) // 3 + 500)

            if api_key_model:
                has_credits = await APIKeyService.check_and_deduct_credits(
                    session, api_key_model, estimated_tokens=estimated_tokens
                )
                if not has_credits:
                    await LogService.create_log(
                        session,
                        ip_address=ip_address,
                        api_key_id=api_key_model.id,
                        api_key_name=api_key_name,
                        endpoint=endpoint_path,
                        method=request_method,
                        external_model=model_name,
                        actual_model=actual_model,
                        provider_name=provider.name,
                        latency_ms=None,
                        status_code=402,
                        error_message="Insufficient credits",
                    )
                    return JSONResponse(
                        status_code=402,
                        content={
                            "error": {
                                "message": "Insufficient credits. Please top up your account.",
                                "type": "insufficient_quota",
                                "code": "insufficient_credits",
                            }
                        },
                    )

            collected_chunks: list[bytes] = []

            async def stream_wrapper():
                async for chunk in ProxyService.forward_streaming_request(
                    session=session,
                    provider=provider,
                    actual_model=actual_model,
                    endpoint_path=endpoint_path,
                    body=body,
                    headers=request_headers,
                    method=request_method,
                ):
                    collected_chunks.append(chunk)
                    yield chunk

                # After stream completes: extract tokens, update usage, deduct credits
                # IMPORTANT: Create a NEW session because the original session from
                # dependency injection may already be closed when streaming completes.
                prompt_tokens_s, completion_tokens_s, total_tokens_s = ProxyService.extract_tokens_from_streaming_chunks(collected_chunks)

                credits_remaining = None

                if api_key_model and total_tokens_s > 0:
                    from app.database.session import async_session_factory
                    from sqlalchemy import select
                    from app.models.models import APIKey
                    
                    new_session = async_session_factory()
                    try:
                        # Re-attach the api_key_model to new session
                        fresh_key = (await new_session.execute(
                            select(APIKey).where(APIKey.id == api_key_model.id)
                        )).scalar_one_or_none()
                        
                        if fresh_key:
                            await APIKeyService.update_usage(
                                new_session, fresh_key,
                                prompt_tokens=prompt_tokens_s,
                                completion_tokens=completion_tokens_s,
                                ip_address=ip_address,
                            )
                            await APIKeyService.deduct_credits(
                                new_session,
                                fresh_key,
                                total_tokens=total_tokens_s,
                                description=f"Stream: {model_name}",
                            )
                            await LogService.create_log(
                                new_session,
                                ip_address=ip_address,
                                api_key_id=fresh_key.id,
                                api_key_name=api_key_name,
                                endpoint=endpoint_path,
                                method=request_method,
                                external_model=model_name,
                                actual_model=actual_model,
                                provider_name=provider.name,
                                latency_ms=None,
                                status_code=200,
                                prompt_tokens=prompt_tokens_s,
                                completion_tokens=completion_tokens_s,
                                total_tokens=total_tokens_s,
                                is_streaming=True,
                            )
                            # Get remaining credits from users table
                            if fresh_key.user_id:
                                from app.models.models import User as UserModel
                                user = (await new_session.execute(
                                    select(UserModel).where(UserModel.id == fresh_key.user_id)
                                )).scalar_one_or_none()
                                if user:
                                    credits_remaining = user.credits or 0
                        await new_session.commit()
                    except Exception:
                        await new_session.rollback()
                    finally:
                        await new_session.close()

                # Send final SSE event with credits_remaining
                done_event = {"done": True}
                if credits_remaining is not None:
                    done_event["credits_remaining"] = credits_remaining
                yield f"data: {json.dumps(done_event)}\n\n".encode("utf-8")

            # Log initial streaming request (placeholder)
            await LogService.create_log(
                session,
                ip_address=ip_address,
                api_key_id=api_key_model.id if api_key_model else None,
                api_key_name=api_key_name,
                endpoint=endpoint_path,
                method=request_method,
                external_model=model_name,
                actual_model=actual_model,
                provider_name=provider.name,
                latency_ms=None,
                status_code=200,
                prompt_tokens=0,
                completion_tokens=0,
                total_tokens=0,
                is_streaming=True,
            )

            return StreamingResponse(
                stream_wrapper(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        # ── Check credits before calling AI ─────────────────────────────
        estimated_tokens = 1000  # default estimate
        if body.get("messages"):
            all_content = ""
            for msg in body["messages"]:
                if isinstance(msg.get("content"), str):
                    all_content += msg["content"]
                elif isinstance(msg.get("content"), list):
                    for part in msg["content"]:
                        all_content += part.get("text", "")
            estimated_tokens = max(500, len(all_content) // 3 + 500)

        if api_key_model:
            has_credits = await APIKeyService.check_and_deduct_credits(
                session, api_key_model, estimated_tokens=estimated_tokens
            )
            if not has_credits:
                await LogService.create_log(
                    session,
                    ip_address=ip_address,
                    api_key_id=api_key_model.id,
                    api_key_name=api_key_name,
                    endpoint=endpoint_path,
                    method=request_method,
                    external_model=model_name,
                    actual_model=actual_model,
                    provider_name=provider.name,
                    latency_ms=None,
                    status_code=402,
                    error_message="Insufficient credits",
                )
                return JSONResponse(
                    status_code=402,
                    content={
                        "error": {
                            "message": "Insufficient credits. Please top up your account.",
                            "type": "insufficient_quota",
                            "code": "insufficient_credits",
                        }
                    },
                )

        # ── Handle Non-Streaming ────────────────────────────────────────
        result = await ProxyService.forward_request(
            session=session,
            provider=provider,
            actual_model=actual_model,
            endpoint_path=endpoint_path,
            body=body,
            headers=request_headers,
            method=request_method,
        )

        # Log the request
        await LogService.create_log(
            session,
            ip_address=ip_address,
            api_key_id=api_key_model.id if api_key_model else None,
            api_key_name=api_key_name,
            endpoint=endpoint_path,
            method=request_method,
            external_model=model_name,
            actual_model=actual_model,
            provider_name=provider.name,
            latency_ms=result["latency_ms"],
            status_code=result["status_code"],
            prompt_tokens=result["prompt_tokens"],
            completion_tokens=result["completion_tokens"],
            total_tokens=result["total_tokens"],
            error_message=result.get("error"),
        )

        # Update API key usage & deduct credits
        if api_key_model and result["status_code"] < 400:
            await APIKeyService.update_usage(
                session,
                api_key_model,
                prompt_tokens=result["prompt_tokens"],
                completion_tokens=result["completion_tokens"],
                ip_address=ip_address,
            )
            # Deduct credits based on actual token usage
            total_tokens = result.get("total_tokens", 0)
            if total_tokens > 0 and api_key_model.user_id:
                await APIKeyService.deduct_credits(
                    session,
                    api_key_model,
                    total_tokens=total_tokens,
                    description=f"Chat: {model_name}",
                )

        # Build the response headers, stripping provider-specific headers
        response_headers = {}
        skip_headers = {
            "content-length", "transfer-encoding", "content-encoding",
            "server", "x-powered-by", "x-request-id",
            "x-ratelimit-limit", "x-ratelimit-remaining", "x-ratelimit-reset",
            "cf-ray", "cf-cache-status",
        }
        for key, value in result["headers"].items():
            if key.lower() not in skip_headers:
                response_headers[key] = value

        # Never expose the real API key or base URL
        response_headers.pop("authorization", None)
        response_headers.pop("x-api-key", None)

        return JSONResponse(
            status_code=result["status_code"],
            content=result["body"],
            headers=response_headers,
        )