#!/bin/bash
# =============================================================================
# AI Gateway - Fix & Rebuild Script
# Run this on Ubuntu server to fix all issues and rebuild containers
# =============================================================================
set -e

echo "========================================"
echo " AI Gateway - Fix & Rebuild"
echo "========================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Step 1: Stop existing containers AND remove volumes (WARNING: deletes all data!)
echo -e "${YELLOW}[1/6] Stopping existing containers and removing volumes...${NC}"
docker compose down -v || true
echo -e "${GREEN}Done.${NC}"

# Step 2: Clean old images
echo -e "${YELLOW}[2/6] Cleaning old images...${NC}"
docker compose rm -f || true
# Remove old volumes to ensure fresh database
docker volume rm ai-gateway_mysql_data 2>/dev/null || true
echo -e "${GREEN}Done.${NC}"

# Step 3: Build new images
echo -e "${YELLOW}[3/6] Building new images...${NC}"
docker compose build --no-cache
echo -e "${GREEN}Done.${NC}"

# Step 4: Start containers
echo -e "${YELLOW}[4/6] Starting containers...${NC}"
docker compose up -d
echo -e "${GREEN}Done.${NC}"

# Step 5: Wait for MySQL to be fully ready (database.sql import takes time)
echo -e "${YELLOW}[5/6] Waiting for MySQL init + seed data...${NC}"
sleep 20

# Step 6: Wait for services and verify
echo -e "${YELLOW}[6/6] Waiting for services to be ready...${NC}"
sleep 10

echo ""
echo "========================================"
echo " VERIFICATION"
echo "========================================"

# Check containers
echo ""
echo "Container status:"
docker compose ps

echo ""
echo "MySQL logs (last 5 lines):"
docker compose logs mysql --tail 5

echo ""
echo "PHP-Apache logs (last 5 lines):"
docker compose logs php-apache --tail 5

echo ""
echo "Python AI Gateway logs (last 10 lines):"
docker compose logs ai-gateway --tail 10

echo ""
echo "========================================"
echo " DEBUG ENDPOINTS"
echo "========================================"

# Test Python gateway
echo ""
echo "Testing Python gateway health..."
HEALTH=$(curl -s http://localhost:8000/health 2>/dev/null || echo "FAILED")
echo "  Health: $HEALTH"

echo ""
echo "Testing password hash compatibility..."
HASH=$(curl -s "http://localhost:8000/debug/hash?password=Loc12345s@" 2>/dev/null || echo "FAILED")
echo "  Hash debug: $HASH"

echo ""
echo "Checking admin account..."
ADMIN=$(curl -s http://localhost:8000/debug/check-admin 2>/dev/null || echo "FAILED")
echo "  Admin check: $ADMIN"

echo ""
echo "========================================"
echo -e "${GREEN} REBUILD COMPLETE!${NC}"
echo "========================================"
echo ""
echo "  PHP Frontend:   http://localhost:8080"
echo "  AI Gateway:     http://localhost:8000"
echo "  Login:          locnguyen / Loc12345s@"
echo ""
echo "  If login still fails, check:"
echo "    1. curl http://localhost:8000/debug/hash"
echo "    2. curl http://localhost:8000/debug/check-admin"
echo "    3. docker compose logs ai-gateway"
echo ""