"""AI Gateway - Main Application Entry Point.

Production-ready AI Gateway that proxies requests to configured AI providers.
Users never see real API keys, base URLs, or model names.
"""

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database.base import create_tables
from app.database.session import get_session_context
from app.auth.security import seed_default_admin
from app.api.auth_routes import router as auth_router
from app.api.dashboard_routes import router as dashboard_router
from app.api.management_routes import router as management_router
from app.api.proxy_routes import router as proxy_router
from app.middleware.middleware import (
    SecurityHeadersMiddleware,
    ExceptionHandlerMiddleware,
    RequestLoggingMiddleware,
)

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown events."""
    # Startup
    logger.info("Starting AI Gateway...")
    logger.info(f"Environment: {settings.environment}")

    # Create database tables
    await create_tables()
    logger.info("Database tables verified.")

    # Seed default admin user
    async with get_session_context() as session:
        await seed_default_admin(session)

    logger.info("AI Gateway started successfully.")

    yield

    # Shutdown
    logger.info("Shutting down AI Gateway...")


def create_application() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Production AI Gateway - OpenAI Compatible Proxy",
        docs_url=None,  # Disable default Swagger (security)
        redoc_url=None,  # Disable default ReDoc (security)
        openapi_url=None,  # Disable OpenAPI schema (security)
        lifespan=lifespan,
    )

    # Add CORS middleware (must be added first for preflight requests)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Add custom middleware (order matters - last added runs first)
    app.add_middleware(ExceptionHandlerMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestLoggingMiddleware)

    # Mount static files
    static_dir = settings.BASE_DIR / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Simple ping endpoint (before routers, for debugging)
    @app.get("/debug/ping", include_in_schema=False)
    async def debug_ping():
        return {"ping": "pong", "status": "ok"}

    # Include routers
    app.include_router(auth_router)
    app.include_router(dashboard_router)
    app.include_router(management_router)
    app.include_router(proxy_router)

    # Health check endpoint
    @app.get("/health", include_in_schema=False)
    async def health_check():
        """Health check for load balancers."""
        return {
            "status": "healthy",
            "app": settings.app_name,
            "version": settings.app_version,
            "environment": settings.environment,
        }

    # Debug endpoint: test password hash & admin (remove in production)
    @app.get("/debug/hash", include_in_schema=False)
    async def debug_hash(password: str = "Loc12345s@"):
        """Test password hashing & verify with known PHP hash."""
        from app.auth.security import hash_password, verify_password
        php_hash = "$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi"
        py_hash = hash_password(password)
        verify_php = verify_password(password, php_hash)
        verify_py = verify_password(password, py_hash)
        return {
            "password": password,
            "python_hash": py_hash,
            "php_hash": php_hash,
            "verify_php_hash": verify_php,
            "verify_py_hash": verify_py,
        }

    @app.get("/debug/check-admin", include_in_schema=False)
    async def debug_check_admin():
        """Check if admin user exists in DB."""
        from app.database.session import get_session_context
        from app.models.models import AdminUser
        from sqlalchemy import select
        async with get_session_context() as session:
            result = await session.execute(
                select(AdminUser).where(AdminUser.username == "locnguyen")
            )
            admin = result.scalar_one_or_none()
            if admin:
                return {
                    "exists": True,
                    "username": admin.username,
                    "is_active": admin.is_active,
                    "role": admin.role,
                    "password_hash_preview": admin.password[:30] + "...",
                }
            return {"exists": False, "message": "Admin 'locnguyen' not found"}

    return app


# Create the application instance with startup error logging
try:
    app = create_application()
except Exception as e:
    import traceback
    import sys
    print(f"FATAL: Failed to create application: {e}", file=sys.stderr)
    traceback.print_exc(file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    import uvicorn
    import signal
    import sys
    
    # Don't use reload in production - causes restart loop on every file change
    use_reload = settings.debug and settings.environment == "development"
    
    if use_reload:
        logger.warning("⚠️  AUTO-RELOAD ENABLED — server will restart on file changes!")
    else:
        logger.info("✅ Auto-reload DISABLED — production mode, stable")
    
    # Graceful shutdown handler
    def handle_shutdown(sig, frame):
        logger.info(f"Received signal {sig}, shutting down gracefully...")
        sys.exit(0)
    
    signal.signal(signal.SIGTERM, handle_shutdown)
    signal.signal(signal.SIGINT, handle_shutdown)
    
    logger.info(f"Starting uvicorn on {settings.host}:{settings.port} (reload={use_reload})")
    
    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=use_reload,
        log_level=settings.log_level,
        timeout_keep_alive=65,
    )
