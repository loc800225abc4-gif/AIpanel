<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();

// Go to install if DB not ready
if (!$db) {
    header('Location: ../install.php');
    exit;
}

// Helper: safe query single value
function safeSingle($db, $sql, $default = 0) {
    $result = $db->query($sql);
    if ($result && $row = $result->fetch_assoc()) {
        return $row['c'] ?? $default;
    }
    return $default;
}

// Helper: safe query all rows
function safeAll($db, $sql, $default = []) {
    $result = $db->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    return $default;
}

// Stats
$totalUsers = safeSingle($db, "SELECT COUNT(*) as c FROM users");
$totalRequests = safeSingle($db, "SELECT COUNT(*) as c FROM chat_history");
$totalTokens = safeSingle($db, "SELECT COALESCE(SUM(tokens_total),0) as c FROM chat_history");
$totalApiKeys = safeSingle($db, "SELECT COUNT(*) as c FROM user_api_keys");
$activeModels = safeSingle($db, "SELECT COUNT(*) as c FROM ai_models WHERE is_active = 1");

// Recent requests
$recentRequests = safeAll($db, "SELECT ch.*, u.username, m.name as model_name FROM chat_history ch LEFT JOIN users u ON ch.user_id = u.id LEFT JOIN ai_models m ON ch.model_id = m.id ORDER BY ch.id DESC LIMIT 20");

// Daily stats last 7 days
$dailyStats = safeAll($db, "SELECT DATE(created_at) as date, COALESCE(SUM(tokens_total),0) as tokens, COUNT(*) as requests FROM chat_history WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AI Provider</title>
    <style>
        :root { --bg: #0a0f1a; --card: #111827; --border: #1e293b; --text: #e2e8f0; --primary: #6366f1; --green: #22c55e; --red: #ef4444; --yellow: #eab308; --purple: #a855f7; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; display: flex; }
        .sidebar { width: 240px; background: var(--card); border-right: 1px solid var(--border); padding: 20px 0; min-height: 100vh; }
        .sidebar h2 { padding: 0 20px 16px; font-size: 1.1rem; color: var(--primary); }
        .sidebar a { display: block; padding: 10px 20px; color: #94a3b8; text-decoration: none; font-size: 0.9rem; }
        .sidebar a:hover, .sidebar a.active { background: rgba(99,102,241,0.1); color: white; }
        .main { flex: 1; padding: 24px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; }
        .stat-card .icon { font-size: 1.5rem; margin-bottom: 8px; }
        .stat-card .label { font-size: 0.85rem; color: #94a3b8; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
        .card h3 { margin-bottom: 14px; font-size: 1.1rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
        th { color: #94a3b8; font-weight: 500; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }
        .badge-user { background: rgba(99,102,241,0.2); color: var(--primary); }
        .badge-assistant { background: rgba(34,197,94,0.2); color: var(--green); }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php" class="active">📊 Dashboard</a>
        <a href="models.php">🤖 AI Models</a>
        <a href="settings.php">⚡ Settings</a>
        <a href="history.php">📜 Chat History</a>
        <a href="usage.php">📈 Usage Stats</a>
        <a href="../index.php">🌐 View Site</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
    <div class="main">
        <h1 style="margin-bottom:20px">📊 Dashboard</h1>
        <div class="grid">
            <div class="stat-card">
                <div class="icon">👥</div>
                <div class="label">Total Users</div>
                <div class="value" style="color:var(--primary)"><?php echo number_format($totalUsers); ?></div>
            </div>
            <div class="stat-card">
                <div class="icon">📤</div>
                <div class="label">Total Requests</div>
                <div class="value" style="color:var(--green)"><?php echo number_format($totalRequests); ?></div>
            </div>
            <div class="stat-card">
                <div class="icon">🪙</div>
                <div class="label">Total Tokens</div>
                <div class="value" style="color:var(--yellow)"><?php echo number_format($totalTokens); ?></div>
            </div>
            <div class="stat-card">
                <div class="icon">🔑</div>
                <div class="label">API Keys</div>
                <div class="value" style="color:var(--red)"><?php echo number_format($totalApiKeys); ?></div>
            </div>
            <div class="stat-card">
                <div class="icon">🤖</div>
                <div class="label">Active Models</div>
                <div class="value" style="color:var(--purple)"><?php echo number_format($activeModels); ?></div>
            </div>
        </div>
        
        <div class="card">
            <h3>📈 Daily Token Usage (Last 7 Days)</h3>
            <table>
                <thead><tr><th>Date</th><th>Tokens</th><th>Requests</th></tr></thead>
                <tbody>
                <?php foreach ($dailyStats as $d): ?>
                    <tr>
                        <td><?php echo $d['date']; ?></td>
                        <td><?php echo number_format($d['tokens']); ?></td>
                        <td><?php echo number_format($d['requests']); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($dailyStats)): ?><tr><td colspan="3" style="text-align:center;color:#64748b">No data yet</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="card">
            <h3>📜 Recent Requests</h3>
            <table>
                <thead><tr><th>ID</th><th>User</th><th>Model</th><th>Role</th><th>Content</th><th>Tokens</th><th>Time</th></tr></thead>
                <tbody>
                <?php foreach ($recentRequests as $r): ?>
                    <tr>
                        <td><?php echo $r['id']; ?></td>
                        <td><?php echo sanitize($r['username'] ?? 'N/A'); ?></td>
                        <td><?php echo sanitize($r['model_name'] ?? 'N/A'); ?></td>
                        <td><span class="badge <?php echo $r['role'] === 'user' ? 'badge-user' : 'badge-assistant'; ?>"><?php echo $r['role']; ?></span></td>
                        <td style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo sanitize($r['content']); ?></td>
                        <td><?php echo number_format($r['tokens_total']); ?></td>
                        <td><?php echo $r['created_at']; ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recentRequests)): ?><tr><td colspan="7" style="text-align:center;color:#64748b">No requests yet</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>