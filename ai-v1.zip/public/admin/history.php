<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();

// Filter
$userId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

$where = [];
if ($userId > 0) $where[] = "ch.user_id = $userId";
if ($search) $where[] = "(ch.content LIKE '%" . $db->real_escape_string($search) . "%' OR u.username LIKE '%" . $db->real_escape_string($search) . "%')";
$whereSQL = !empty($where) ? 'AND ' . implode(' AND ', $where) : '';

$totalResult = $db->query("SELECT COUNT(*) as c FROM chat_history ch LEFT JOIN users u ON ch.user_id = u.id WHERE 1 $whereSQL");
$total = ($totalResult && $row = $totalResult->fetch_assoc()) ? ($row['c'] ?? 0) : 0;
$totalPages = ceil($total / $perPage);

$historyResult = $db->query("SELECT ch.*, u.username, m.name as model_name FROM chat_history ch LEFT JOIN users u ON ch.user_id = u.id LEFT JOIN ai_models m ON ch.model_id = m.id WHERE 1 $whereSQL ORDER BY ch.id DESC LIMIT $perPage OFFSET $offset");
$history = ($historyResult && $historyResult->num_rows > 0) ? $historyResult->fetch_all(MYSQLI_ASSOC) : [];

$usersResult = $db->query("SELECT id, username FROM users ORDER BY username ASC");
$users = ($usersResult && $usersResult->num_rows > 0) ? $usersResult->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat History - Admin</title>
    <style>
        :root { --bg: #0a0f1a; --card: #111827; --border: #1e293b; --text: #e2e8f0; --primary: #6366f1; --green: #22c55e; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; display: flex; }
        .sidebar { width: 240px; background: var(--card); border-right: 1px solid var(--border); padding: 20px 0; min-height: 100vh; }
        .sidebar h2 { padding: 0 20px 16px; font-size: 1.1rem; color: var(--primary); }
        .sidebar a { display: block; padding: 10px 20px; color: #94a3b8; text-decoration: none; font-size: 0.9rem; }
        .sidebar a:hover, .sidebar a.active { background: rgba(99,102,241,0.1); color: white; }
        .main { flex: 1; padding: 24px; }
        h1 { margin-bottom: 20px; }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
        .filters { display: flex; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; align-items: flex-end; }
        .filters select, .filters input { padding: 7px 10px; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; color: var(--text); font-size: 0.85rem; }
        .btn { padding: 6px 14px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.85rem; font-weight: 500; background: var(--primary); color: white; }
        .btn:hover { opacity: 0.85; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
        th { color: #94a3b8; font-weight: 500; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }
        .badge-user { background: rgba(99,102,241,0.2); color: var(--primary); }
        .badge-assistant { background: rgba(34,197,94,0.2); color: var(--green); }
        .pagination { margin-top: 16px; display: flex; gap: 8px; justify-content: center; }
        .pagination a { padding: 6px 12px; background: var(--card); border: 1px solid var(--border); border-radius: 6px; color: var(--text); text-decoration: none; font-size: 0.85rem; }
        .pagination a:hover, .pagination a.active { background: var(--primary); border-color: var(--primary); }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="models.php">🤖 AI Models</a>
        <a href="settings.php">⚡ Settings</a>
        <a href="history.php" class="active">📜 Chat History</a>
        <a href="usage.php">📈 Usage Stats</a>
        <a href="../index.php">🌐 View Site</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
    <div class="main">
        <h1>📜 Chat History (<?php echo number_format($total); ?> records)</h1>
        
        <div class="card">
            <form method="GET" class="filters">
                <select name="user_id">
                    <option value="">All Users</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?php echo $u['id']; ?>" <?php echo $userId == $u['id'] ? 'selected' : ''; ?>><?php echo sanitize($u['username']); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="search" placeholder="Search content..." value="<?php echo sanitize($search); ?>">
                <button type="submit" class="btn">🔍 Filter</button>
                <?php if ($userId || $search): ?><a href="history.php" class="btn" style="background:transparent;border:1px solid var(--border)">Clear</a><?php endif; ?>
            </form>
            
            <table>
                <thead><tr><th>ID</th><th>User</th><th>Session</th><th>Model</th><th>Role</th><th>Content</th><th>Tokens</th><th>Time</th></tr></thead>
                <tbody>
                <?php foreach ($history as $h): ?>
                    <tr>
                        <td><?php echo $h['id']; ?></td>
                        <td><?php echo sanitize($h['username'] ?? 'N/A'); ?></td>
                        <td style="font-family:monospace;font-size:0.75rem"><?php echo substr($h['session_id'], 0, 8); ?></td>
                        <td><?php echo sanitize($h['model_name'] ?? 'N/A'); ?></td>
                        <td><span class="badge <?php echo $h['role'] === 'user' ? 'badge-user' : 'badge-assistant'; ?>"><?php echo $h['role']; ?></span></td>
                        <td style="max-width:350px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo sanitize($h['content']); ?></td>
                        <td><?php echo number_format($h['tokens_total']); ?></td>
                        <td><?php echo $h['created_at']; ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($history)): ?><tr><td colspan="8" style="text-align:center;color:#64748b;padding:30px">No history found.</td></tr><?php endif; ?>
                </tbody>
            </table>
            
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&user_id=<?php echo $userId; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>