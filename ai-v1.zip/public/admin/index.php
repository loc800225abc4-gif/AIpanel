<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

// If already logged in as admin, redirect to dashboard
if (isLoggedIn() && isAdmin()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter username and password.';
    } else {
        try {
            $db = getDB();
$stmt = $db->prepare("SELECT id, username, password, role, is_active FROM users WHERE (username = ? OR email = ?) AND role = 'admin'");
            $stmt->bind_param("ss", $username, $username);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            
            if ($user && password_verify($password, $user['password'])) {
if (!$user['is_active']) {
                    $error = 'Account is disabled.';
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $db->query("UPDATE users SET last_login = NOW() WHERE id = " . intval($user['id']));
                    header('Location: dashboard.php');
                    exit;
                }
            } else {
                $error = 'Invalid admin credentials.';
            }
        } catch (Exception $e) {
            $error = 'Database connection failed. Please run <a href="../install.php">install</a> first.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - LocNguyen AI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #030712;
            --card: #0f172a;
            --card2: #1e293b;
            --border: #1e293b;
            --border-light: #334155;
            --text: #f1f5f9;
            --text2: #94a3b8;
            --text3: #64748b;
            --accent: #f59e0b;
            --accent-light: #fbbf24;
            --accent-glow: rgba(245,158,11,0.3);
            --red: #ef4444;
            --radius: 12px;
            --radius-lg: 16px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        .bg-grid {
            position: fixed; inset: 0;
            background-image: linear-gradient(rgba(245,158,11,0.04) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(245,158,11,0.04) 1px, transparent 1px);
            background-size: 80px 80px;
            pointer-events: none; z-index: 0;
        }
        .bg-orb {
            position: fixed; border-radius: 50%;
            filter: blur(150px); pointer-events: none; z-index: 0;
        }
        .bg-orb-1 { width: 600px; height: 600px; background: rgba(245,158,11,0.1); top: -250px; left: -200px; }
        .bg-orb-2 { width: 450px; height: 450px; background: rgba(251,191,36,0.08); bottom: -150px; right: -150px; }

        .login-wrapper {
            position: relative; z-index: 1;
            width: 100%; max-width: 440px;
            padding: 20px;
        }

        .brand {
            text-align: center; margin-bottom: 32px;
        }
        .brand-icon {
            width: 68px; height: 68px;
            background: linear-gradient(135deg, var(--accent), #d97706);
            border-radius: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 12px;
            box-shadow: 0 8px 32px var(--accent-glow);
        }
        .brand h1 {
            font-size: 1.4rem; font-weight: 700;
            background: linear-gradient(135deg, #fff, #fcd34d);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .brand p { color: var(--text3); font-size: 0.85rem; margin-top: 4px; }

        .login-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 36px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5);
            position: relative;
            overflow: hidden;
        }
        .login-card::before {
            content: '';
            position: absolute; top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--accent), var(--accent-light), #d97706);
        }

        .alert {
            padding: 14px 18px; border-radius: 10px;
            margin-bottom: 20px; font-size: 0.9rem;
            display: flex; align-items: center; gap: 10px;
        }
        .alert-error {
            background: rgba(239,68,68,0.1);
            border: 1px solid rgba(239,68,68,0.3);
            color: var(--red);
        }
        .alert-error a { color: #fca5a5; }

        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-size: 0.85rem; font-weight: 500; color: var(--text2);
        }
        .input-wrapper { position: relative; }
        .input-wrapper i {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%);
            color: var(--text3); font-size: 1rem;
            pointer-events: none;
        }
        .input-wrapper input {
            width: 100%; padding: 12px 14px 12px 42px;
            background: var(--card2); border: 1px solid var(--border-light);
            border-radius: var(--radius); color: var(--text);
            font-size: 0.95rem; font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        .input-wrapper input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-glow);
        }

        .btn-login {
            width: 100%; padding: 13px;
            background: linear-gradient(135deg, var(--accent), #d97706);
            color: #000; border: none; border-radius: var(--radius);
            font-size: 1rem; font-weight: 700; cursor: pointer;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 28px var(--accent-glow);
        }

        .back-link {
            text-align: center; margin-top: 20px;
            font-size: 0.9rem; color: var(--text3);
        }
        .back-link a {
            color: var(--text2); text-decoration: none;
            transition: color 0.2s;
        }
        .back-link a:hover { color: var(--text); }
    </style>
</head>
<body>
    <div class="bg-grid"></div>
    <div class="bg-orb bg-orb-1"></div>
    <div class="bg-orb bg-orb-2"></div>

    <div class="login-wrapper">
        <div class="brand">
            <div class="brand-icon">⚙️</div>
            <h1>Admin Panel</h1>
            <p>LocNguyen AI Management System</p>
        </div>

        <div class="login-card">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-shield-halting"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" autocomplete="off">
                <div class="form-group">
                    <label>Admin Username</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user-shield"></i>
                        <input type="text" name="username" required autofocus
                               placeholder="Enter admin username">
                    </div>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-key"></i>
                        <input type="password" name="password" required
                               placeholder="Enter password">
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-lock-open"></i> Authenticate
                </button>
            </form>
        </div>

        <div class="back-link">
            <a href="../index.php"><i class="fas fa-arrow-left"></i> Back to Website</a>
        </div>
    </div>
</body>
</html>