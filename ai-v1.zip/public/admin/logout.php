<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
session_destroy();
header('Location: ../index.php');
exit;
