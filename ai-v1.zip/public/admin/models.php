<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$message = '';

// Auto-migrate: add missing columns (MariaDB compatible - suppress "duplicate column" error)
@$db->query("ALTER TABLE ai_models ADD COLUMN base_url VARCHAR(500) DEFAULT NULL AFTER description");
@$db->query("ALTER TABLE ai_models ADD COLUMN api_key VARCHAR(255) DEFAULT NULL AFTER base_url");
@$db->query("ALTER TABLE ai_models ADD COLUMN cost_per_1k_tokens FLOAT DEFAULT 0.001 AFTER max_tokens");
@$db->query("ALTER TABLE ai_models ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER sort_order");
@$db->query("ALTER TABLE users ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER role");

// Handle CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add model
    if (isset($_POST['add_model'])) {
        $modelId = trim($_POST['model_id']);
        $name = trim($_POST['name']);
        $provider = trim($_POST['provider']);
        $desc = trim($_POST['description'] ?? '');
        $baseUrl = trim($_POST['base_url'] ?? '');
        $apiKey = trim($_POST['api_key'] ?? '');
        $maxTokens = (int)($_POST['max_tokens'] ?? 4096);
        $costPer1k = (float)($_POST['cost_per_1k'] ?? 0.001);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $sortOrder = (int)($_POST['sort_order'] ?? 0);

        if (!empty($modelId) && !empty($name)) {
            $stmt = $db->prepare("INSERT INTO ai_models (model_id, name, provider, description, base_url, api_key, max_tokens, cost_per_1k_tokens, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssidii", $modelId, $name, $provider, $desc, $baseUrl, $apiKey, $maxTokens, $costPer1k, $isActive, $sortOrder);
            if ($stmt->execute()) $message = 'Model added successfully!';
        }
    }

    // Update model
    if (isset($_POST['update_model'])) {
        $id = (int)$_POST['id'];
        $modelId = trim($_POST['model_id']);
        $name = trim($_POST['name']);
        $provider = trim($_POST['provider']);
        $desc = trim($_POST['description'] ?? '');
        $baseUrl = trim($_POST['base_url'] ?? '');
        $apiKey = trim($_POST['api_key'] ?? '');
        $maxTokens = (int)($_POST['max_tokens'] ?? 4096);
        $costPer1k = (float)($_POST['cost_per_1k'] ?? 0.001);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $sortOrder = (int)($_POST['sort_order'] ?? 0);

        $stmt = $db->prepare("UPDATE ai_models SET model_id=?, name=?, provider=?, description=?, base_url=?, api_key=?, max_tokens=?, cost_per_1k_tokens=?, is_active=?, sort_order=? WHERE id=?");
        $stmt->bind_param("ssssssidiii", $modelId, $name, $provider, $desc, $baseUrl, $apiKey, $maxTokens, $costPer1k, $isActive, $sortOrder, $id);
        if ($stmt->execute()) $message = 'Model updated!';
    }
}

// Delete model
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->query("DELETE FROM ai_models WHERE id = $id");
    header('Location: models.php?deleted=1');
    exit;
}

$modelsResult = $db->query("SELECT * FROM ai_models ORDER BY sort_order ASC");
$models = ($modelsResult && $modelsResult->num_rows > 0) ? $modelsResult->fetch_all(MYSQLI_ASSOC) : [];

// Get model for editing
$editModel = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $editResult = $db->query("SELECT * FROM ai_models WHERE id = $editId");
    $editModel = ($editResult && $editResult->num_rows > 0) ? $editResult->fetch_assoc() : null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Models - Admin</title>
    <style>
        :root { --bg: #0a0f1a; --card: #111827; --border: #1e293b; --text: #e2e8f0; --primary: #6366f1; --green: #22c55e; --red: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; display: flex; }
        .sidebar { width: 240px; background: var(--card); border-right: 1px solid var(--border); padding: 20px 0; min-height: 100vh; }
        .sidebar h2 { padding: 0 20px 16px; font-size: 1.1rem; color: var(--primary); }
        .sidebar a { display: block; padding: 10px 20px; color: #94a3b8; text-decoration: none; font-size: 0.9rem; }
        .sidebar a:hover, .sidebar a.active { background: rgba(99,102,241,0.1); color: white; }
        .main { flex: 1; padding: 24px; max-width: 1200px; }
        h1 { margin-bottom: 20px; }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
        .card h3 { margin-bottom: 14px; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .form-group { margin-bottom: 12px; }
        .form-group.full { grid-column: 1 / -1; }
        label { display: block; margin-bottom: 4px; font-size: 0.85rem; color: #94a3b8; }
        input, textarea, select { width: 100%; padding: 8px 12px; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; color: var(--text); font-size: 0.9rem; }
        input:focus, textarea:focus { outline: none; border-color: var(--primary); }
        textarea { resize: vertical; min-height: 60px; }
        .btn { padding: 8px 16px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.9rem; font-weight: 500; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-danger { background: var(--red); color: white; }
        .btn:hover { opacity: 0.85; }
        .message { padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); color: var(--green); }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
        th { color: #94a3b8; font-weight: 500; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }
        .badge-on { background: rgba(34,197,94,0.2); color: var(--green); }
        .badge-off { background: rgba(239,68,68,0.2); color: var(--red); }
        .checkbox-label { display: flex; align-items: center; gap: 8px; cursor: pointer; }
        .checkbox-label input { width: auto; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="models.php" class="active">🤖 AI Models</a>
        <a href="settings.php">⚡ Settings</a>
        <a href="history.php">📜 Chat History</a>
        <a href="usage.php">📈 Usage Stats</a>
        <a href="../index.php">🌐 View Site</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
    <div class="main">
        <h1>🤖 AI Models Management</h1>
        <?php if ($message): ?><div class="message"><?php echo $message; ?></div><?php endif; ?>
        <?php if (isset($_GET['deleted'])): ?><div class="message">Model deleted.</div><?php endif; ?>

        <div class="card">
            <h3><?php echo $editModel ? 'Edit Model' : 'Add New Model'; ?></h3>
            <form method="POST">
                <?php if ($editModel): ?><input type="hidden" name="id" value="<?php echo $editModel['id']; ?>"><?php endif; ?>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Model ID * (e.g., gpt-4o)</label>
                        <input type="text" name="model_id" required value="<?php echo sanitize($editModel['model_id'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Display Name *</label>
                        <input type="text" name="name" required value="<?php echo sanitize($editModel['name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Provider</label>
                        <input type="text" name="provider" value="<?php echo sanitize($editModel['provider'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Max Tokens</label>
                        <input type="number" name="max_tokens" value="<?php echo $editModel['max_tokens'] ?? 4096; ?>">
                    </div>
                    <div class="form-group">
                        <label>Base URL (per-model override)</label>
                        <input type="text" name="base_url" value="<?php echo sanitize($editModel['base_url'] ?? ''); ?>" placeholder="Leave empty to use global setting">
                    </div>
                    <div class="form-group">
                        <label>API Key (per-model override)</label>
                        <input type="text" name="api_key" value="<?php echo sanitize($editModel['api_key'] ?? ''); ?>" placeholder="Leave empty to use global setting">
                    </div>
                    <div class="form-group">
                        <label>Cost per 1K tokens</label>
                        <input type="number" step="0.0001" name="cost_per_1k" value="<?php echo $editModel['cost_per_1k_tokens'] ?? 0.001; ?>">
                    </div>
                    <div class="form-group">
                        <label>Sort Order</label>
                        <input type="number" name="sort_order" value="<?php echo $editModel['sort_order'] ?? 0; ?>">
                    </div>
                    <div class="form-group full">
                        <label>Description</label>
                        <textarea name="description"><?php echo sanitize($editModel['description'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_active" <?php echo isset($editModel) ? (($editModel['is_active'] ?? 0) ? 'checked' : '') : 'checked'; ?>>
                            Active
                        </label>
                    </div>
                    <div class="form-group" style="display:flex;align-items:flex-end">
                        <?php if ($editModel): ?>
                            <button type="submit" name="update_model" class="btn btn-primary">Update Model</button>
                            <a href="models.php" class="btn" style="background:transparent;border:1px solid var(--border);margin-left:8px;">Cancel</a>
                        <?php else: ?>
                            <button type="submit" name="add_model" class="btn btn-primary">Add Model</button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="card">
            <h3>Model List (<?php echo count($models); ?>)</h3>
            <table>
                <thead><tr><th>ID</th><th>Model ID</th><th>Name</th><th>Provider</th><th>Max Tokens</th><th>Status</th><th>Order</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($models as $m): ?>
                    <tr>
                        <td><?php echo $m['id']; ?></td>
                        <td><code><?php echo sanitize($m['model_id']); ?></code></td>
                        <td><?php echo sanitize($m['name']); ?></td>
                        <td><?php echo sanitize($m['provider']); ?></td>
                        <td><?php echo number_format($m['max_tokens'] ?? 0); ?></td>
                        <td><span class="badge <?php echo ($m['is_active'] ?? 0) ? 'badge-on' : 'badge-off'; ?>"><?php echo ($m['is_active'] ?? 0) ? 'Active' : 'Inactive'; ?></span></td>
                        <td><?php echo $m['sort_order'] ?? 0; ?></td>
                        <td>
                            <a href="?edit=<?php echo $m['id']; ?>" class="btn btn-primary" style="font-size:0.8rem;padding:4px 10px;">Edit</a>
                            <a href="?delete=<?php echo $m['id']; ?>" class="btn btn-danger" style="font-size:0.8rem;padding:4px 10px;" onclick="return confirm('Delete this model?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($models)): ?><tr><td colspan="8" style="text-align:center;color:#64748b">No models configured.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>