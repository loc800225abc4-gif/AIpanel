<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if this is a settings save (has setting fields) or credit topup
    if (isset($_POST['save_settings'])) {
        foreach ($_POST as $key => $value) {
            if ($key !== 'save_settings') {
                updateSetting($key, trim($value));
            }
        }
        $message = 'Settings saved successfully!';
    } elseif (isset($_POST['add_credits'])) {
        $uid = (int)$_POST['user_id'];
        $amount = (int)$_POST['amount'];
        $db->query("UPDATE users SET credits = credits + $amount WHERE id = $uid");
        $desc = "Admin credit top-up";
        @$db->query("ALTER TABLE credit_logs ADD COLUMN description VARCHAR(255) DEFAULT NULL AFTER type");
        $stmt = $db->prepare("INSERT INTO credit_logs (user_id, amount, type, description) VALUES (?, ?, 'bonus', ?)");
        if ($stmt) {
            $stmt->bind_param("iis", $uid, $amount, $desc);
            $stmt->execute();
        }
        header('Location: settings.php?msg=credits_added');
        exit;
    }
}

$settings = [];
$res = $db->query("SELECT setting_key, setting_value FROM admin_settings");
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
}

// Also show users
$usersResult = $db->query("SELECT id, username, email, full_name, credits, role, is_active, created_at, last_login FROM users ORDER BY created_at DESC");
$users = ($usersResult && $usersResult->num_rows > 0) ? $usersResult->fetch_all(MYSQLI_ASSOC) : [];

// Handle user toggle
if (isset($_GET['toggle_user'])) {
    $uid = (int)$_GET['toggle_user'];
    $uResult = $db->query("SELECT is_active FROM users WHERE id = $uid");
    $u = ($uResult && $uResult->num_rows > 0) ? $uResult->fetch_assoc() : null;
    if (!$u) { header('Location: settings.php'); exit; }
    $new = $u['is_active'] ? 0 : 1;
    $db->query("UPDATE users SET is_active = $new WHERE id = $uid");
    header('Location: settings.php?msg=user_toggled');
    exit;
}

// Handle delete API key (admin can delete any key)
if (isset($_GET['delete_key'])) {
    $keyId = (int)$_GET['delete_key'];
    $db->query("DELETE FROM user_api_keys WHERE id = $keyId");
    header('Location: settings.php?msg=key_deleted#api-keys');
    exit;
}

// Load all API keys with user info
$allKeys = [];
@$db->query("CREATE TABLE IF NOT EXISTS user_api_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) DEFAULT NULL,
    api_key VARCHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$keysResult = $db->query("SELECT uk.*, u.username, u.email FROM user_api_keys uk LEFT JOIN users u ON uk.user_id = u.id ORDER BY uk.created_at DESC");
if ($keysResult && $keysResult->num_rows > 0) {
    while ($row = $keysResult->fetch_assoc()) { $allKeys[] = $row; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings & Users - Admin</title>
    <style>
        :root { --bg: #0a0f1a; --card: #111827; --border: #1e293b; --text: #e2e8f0; --primary: #6366f1; --green: #22c55e; --red: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; display: flex; }
        .sidebar { width: 240px; background: var(--card); border-right: 1px solid var(--border); padding: 20px 0; min-height: 100vh; }
        .sidebar h2 { padding: 0 20px 16px; font-size: 1.1rem; color: var(--primary); }
        .sidebar a { display: block; padding: 10px 20px; color: #94a3b8; text-decoration: none; font-size: 0.9rem; }
        .sidebar a:hover, .sidebar a.active { background: rgba(99,102,241,0.1); color: white; }
        .main { flex: 1; padding: 24px; max-width: 1200px; }
        h1 { margin-bottom: 20px; }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
        .card h3 { margin-bottom: 14px; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .form-group { margin-bottom: 12px; }
        .form-group.full { grid-column: 1 / -1; }
        label { display: block; margin-bottom: 4px; font-size: 0.85rem; color: #94a3b8; }
        input, textarea, select { width: 100%; padding: 8px 12px; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; color: var(--text); font-size: 0.9rem; }
        input:focus, textarea:focus { outline: none; border-color: var(--primary); }
        textarea { resize: vertical; min-height: 60px; }
        .btn { padding: 6px 14px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.85rem; font-weight: 500; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-danger { background: var(--red); color: white; }
        .btn-green { background: var(--green); color: white; }
        .btn:hover { opacity: 0.85; }
        .message { padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); color: var(--green); }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
        th { color: #94a3b8; font-weight: 500; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }
        .badge-on { background: rgba(34,197,94,0.2); color: var(--green); }
        .badge-off { background: rgba(239,68,68,0.2); color: var(--red); }
        .inline-form { display: flex; gap: 8px; align-items: center; }
        .inline-form input { width: 80px; }
        .badge-admin { background: rgba(168,85,247,0.2); color: #a855f7; }
        .badge-user { background: rgba(59,130,246,0.2); color: #3b82f6; }
        .key-row { display: flex; align-items: center; gap: 12px; padding: 10px 12px; background: var(--bg); border-radius: 8px; margin-bottom: 6px; }
        .key-row code { flex: 1; font-size: 0.8rem; color: #818cf8; word-break: break-all; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="models.php">🤖 AI Models</a>
        <a href="settings.php" class="active">⚡ Settings</a>
        <a href="history.php">📜 Chat History</a>
        <a href="usage.php">📈 Usage Stats</a>
        <a href="../index.php">🌐 View Site</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
    <div class="main">
        <h1>⚡ Settings & Users</h1>
        <?php if ($message): ?><div class="message"><?php echo $message; ?></div><?php endif; ?>
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'credits_added'): ?><div class="message">Credits added successfully.</div><?php endif; ?>
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'user_toggled'): ?><div class="message">User status toggled.</div><?php endif; ?>
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'key_deleted'): ?><div class="message">API key deleted.</div><?php endif; ?>

        <div class="card">
            <h3>🔌 API Configuration</h3>
            <form method="POST">
                <div class="form-grid">
                    <div class="form-group full">
                        <label>Base URL (OpenAI-compatible API endpoint)</label>
                        <input type="text" name="base_url" value="<?php echo sanitize($settings['base_url'] ?? ''); ?>" placeholder="https://api.openai.com">
                    </div>
                    <div class="form-group full">
                        <label>API Key</label>
                        <input type="text" name="api_key" value="<?php echo sanitize($settings['api_key'] ?? ''); ?>" placeholder="sk-...">
                    </div>
                    <div class="form-group">
                        <label>Site Name</label>
                        <input type="text" name="site_name" value="<?php echo sanitize($settings['site_name'] ?? 'AI Provider'); ?>">
                    </div>
                    <div class="form-group">
                        <label>Site Description</label>
                        <input type="text" name="site_description" value="<?php echo sanitize($settings['site_description'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Zalo Group Link</label>
                        <input type="url" name="zalo_group_link" value="<?php echo sanitize($settings['zalo_group_link'] ?? 'https://zalo.me/g/yourgroup'); ?>" placeholder="https://zalo.me/g/...">
                    </div>
                    <div class="form-group">
                        <label>Credits per Token</label>
                        <input type="number" step="0.0001" name="credits_per_token" value="<?php echo $settings['credits_per_token'] ?? '0.001'; ?>">
                    </div>
                    <div class="form-group">
                        <label>Register Credits (new users)</label>
                        <input type="number" name="register_credits" value="<?php echo $settings['register_credits'] ?? '10000'; ?>">
                    </div>
                    <div class="form-group">
                        <label>Default Model ID</label>
                        <select name="default_model">
                            <?php foreach (getActiveModels() as $m): ?>
                                <option value="<?php echo $m['id']; ?>" <?php echo ($settings['default_model'] ?? '') == $m['id'] ? 'selected' : ''; ?>><?php echo sanitize($m['name']); ?> (<?php echo sanitize($m['model_id']); ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Max Requests per Minute</label>
                        <input type="number" name="max_requests_per_minute" value="<?php echo $settings['max_requests_per_minute'] ?? '60'; ?>">
                    </div>
                    <div class="form-group full">
                        <button type="submit" name="save_settings" class="btn btn-primary" style="padding:10px 24px;">💾 Save Settings</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- All API Keys Management -->
        <div class="card" id="api-keys">
            <h3>🔑 All API Keys (<?php echo count($allKeys); ?>)</h3>
            <?php if (empty($allKeys)): ?>
                <p style="color:#94a3b8;text-align:center;padding:20px;">No API keys created yet.</p>
            <?php else: ?>
                <?php foreach ($allKeys as $k): ?>
                <div class="key-row">
                    <span style="min-width:100px;font-size:0.8rem;color:#94a3b8;"><?php echo sanitize($k['username'] ?? 'N/A'); ?></span>
                    <span style="min-width:60px;font-size:0.75rem;color:var(--text3);"><?php echo sanitize($k['name'] ?? ''); ?></span>
                    <code><?php echo $k['api_key'] ?? ''; ?></code>
                    <span style="font-size:0.7rem;color:var(--text3);white-space:nowrap;"><?php echo date('d/m/Y', strtotime($k['created_at'] ?? '')); ?></span>
                    <a href="?delete_key=<?php echo $k['id']; ?>" onclick="return confirm('Delete this API key?')" class="btn btn-danger btn-sm" style="padding:4px 10px;font-size:0.75rem;">🗑</a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>👥 Users (<?php echo count($users); ?>)</h3>
            <table>
                <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Full Name</th><th>Credits</th><th>Role</th><th>Status</th><th>Last Login</th><th>Credit Top-up</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?php echo $u['id']; ?></td>
                        <td><?php echo sanitize($u['username']); ?></td>
                        <td><?php echo sanitize($u['email']); ?></td>
                        <td><?php echo sanitize($u['full_name']); ?></td>
                        <td><?php echo number_format($u['credits']); ?></td>
                        <td><span class="badge <?php echo $u['role'] === 'admin' ? 'badge-admin' : 'badge-user'; ?>"><?php echo $u['role']; ?></span></td>
                        <td><span class="badge <?php echo ($u['is_active'] ?? 0) ? 'badge-on' : 'badge-off'; ?>"><?php echo ($u['is_active'] ?? 0) ? 'Active' : 'Banned'; ?></span></td>
                        <td><?php echo $u['last_login'] ?? 'Never'; ?></td>
                        <td>
                            <form method="POST" class="inline-form">
                                <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                <input type="number" name="amount" value="1000" style="width:70px">
                                <button type="submit" name="add_credits" class="btn btn-green">+ Add</button>
                            </form>
                        </td>
                        <td>
                            <a href="?toggle_user=<?php echo $u['id']; ?>" class="btn <?php echo $u['is_active'] ? 'btn-danger' : 'btn-primary'; ?>">
                                <?php echo $u['is_active'] ? 'Ban' : 'Unban'; ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>