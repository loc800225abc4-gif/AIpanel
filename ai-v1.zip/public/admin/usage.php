<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();

// Date range
$from = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
$to = $_GET['to'] ?? date('Y-m-d');

// Safe helpers
function safeRows($db, $sql, $default = []) {
    $result = $db->query($sql);
    return ($result && $result->num_rows > 0) ? $result->fetch_all(MYSQLI_ASSOC) : $default;
}
function safeVal($db, $sql, $default = 0) {
    $result = $db->query($sql);
    return ($result && $row = $result->fetch_assoc()) ? ($row['c'] ?? $default) : $default;
}

// Daily usage
$daily = safeRows($db, "SELECT DATE(created_at) as date, COALESCE(SUM(tokens_total),0) as tokens, COUNT(*) as requests FROM chat_history WHERE created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59' GROUP BY DATE(created_at) ORDER BY date ASC");

// Per model
$modelStats = safeRows($db, "SELECT m.name, m.model_id, COUNT(ch.id) as req_count, COALESCE(SUM(ch.tokens_total),0) as tokens FROM ai_models m LEFT JOIN chat_history ch ON m.id = ch.model_id GROUP BY m.id ORDER BY req_count DESC");

// Per user
$userStats = safeRows($db, "SELECT u.username, u.email, COUNT(ch.id) as req_count, COALESCE(SUM(ch.tokens_total),0) as tokens, u.credits FROM users u LEFT JOIN chat_history ch ON u.id = ch.user_id GROUP BY u.id ORDER BY tokens DESC LIMIT 20");

// Grand totals
$grandRequests = safeVal($db, "SELECT COUNT(*) as c FROM chat_history");
$grandTokens = safeVal($db, "SELECT COALESCE(SUM(tokens_total),0) as c FROM chat_history");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usage Stats - Admin</title>
    <style>
        :root { --bg: #0a0f1a; --card: #111827; --border: #1e293b; --text: #e2e8f0; --primary: #6366f1; --green: #22c55e; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; display: flex; }
        .sidebar { width: 240px; background: var(--card); border-right: 1px solid var(--border); padding: 20px 0; min-height: 100vh; }
        .sidebar h2 { padding: 0 20px 16px; font-size: 1.1rem; color: var(--primary); }
        .sidebar a { display: block; padding: 10px 20px; color: #94a3b8; text-decoration: none; font-size: 0.9rem; }
        .sidebar a:hover, .sidebar a.active { background: rgba(99,102,241,0.1); color: white; }
        .main { flex: 1; padding: 24px; }
        h1 { margin-bottom: 20px; }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 20px; }
        .card h3 { margin-bottom: 14px; }
        .filters { display: flex; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; align-items: flex-end; }
        .filters input { padding: 7px 10px; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; color: var(--text); font-size: 0.85rem; }
        .btn { padding: 6px 14px; border: none; border-radius: 8px; cursor: pointer; font-size: 0.85rem; font-weight: 500; background: var(--primary); color: white; }
        .btn:hover { opacity: 0.85; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
        th { color: #94a3b8; font-weight: 500; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .bar { height: 6px; background: var(--border); border-radius: 3px; margin-top: 4px; overflow: hidden; }
        .bar-fill { height: 100%; background: var(--primary); border-radius: 3px; }
        @media (max-width: 768px) { .grid-2 { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>⚙️ Admin Panel</h2>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="models.php">🤖 AI Models</a>
        <a href="settings.php">⚡ Settings</a>
        <a href="history.php">📜 Chat History</a>
        <a href="usage.php" class="active">📈 Usage Stats</a>
        <a href="../index.php">🌐 View Site</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
    <div class="main">
        <h1>📈 Usage Statistics</h1>
        
        <div class="card">
            <form method="GET" class="filters">
                <label>From:</label><input type="date" name="from" value="<?php echo $from; ?>">
                <label>To:</label><input type="date" name="to" value="<?php echo $to; ?>">
                <button type="submit" class="btn">🔍 View</button>
            </form>
            <p style="color:#94a3b8;font-size:0.85rem">Total: <?php echo number_format($grandRequests); ?> requests / <?php echo number_format($grandTokens); ?> tokens</p>
            <table>
                <thead><tr><th>Date</th><th>Tokens</th><th>Requests</th><th>Visual</th></tr></thead>
                <tbody>
                <?php $maxTokens = !empty($daily) ? max(array_column($daily, 'tokens')) : 1; ?>
                <?php foreach ($daily as $d): ?>
                    <tr>
                        <td><?php echo $d['date']; ?></td>
                        <td><?php echo number_format($d['tokens']); ?></td>
                        <td><?php echo number_format($d['requests']); ?></td>
                        <td>
                            <div class="bar"><div class="bar-fill" style="width:<?php echo round(($d['tokens']/$maxTokens)*100); ?>%"></div></div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($daily)): ?><tr><td colspan="4" style="text-align:center;color:#64748b;padding:30px">No data in this range.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="grid-2">
            <div class="card">
                <h3>🤖 Usage by Model</h3>
                <table>
                    <thead><tr><th>Model</th><th>Requests</th><th>Tokens</th></tr></thead>
                    <tbody>
                    <?php foreach ($modelStats as $m): ?>
                        <tr>
                            <td><?php echo sanitize($m['name']); ?></td>
                            <td><?php echo number_format($m['req_count']); ?></td>
                            <td><?php echo number_format($m['tokens']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="card">
                <h3>👥 Top Users by Token Usage</h3>
                <table>
                    <thead><tr><th>User</th><th>Requests</th><th>Tokens</th><th>Credits</th></tr></thead>
                    <tbody>
                    <?php foreach ($userStats as $u): ?>
                        <tr>
                            <td><?php echo sanitize($u['username']); ?></td>
                            <td><?php echo number_format($u['req_count']); ?></td>
                            <td><?php echo number_format($u['tokens']); ?></td>
                            <td><?php echo number_format($u['credits']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>