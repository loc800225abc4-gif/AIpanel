# 🚀 AI Gateway API Documentation

**Python Gateway port `8000` | PHP proxy port `8080`**

---

## 🔑 1. Lấy API key

Vào dashboard để tạo API key: **http://\<IP-server\>:8080/dashboard.php**

1. Đăng nhập (nếu chưa tạo tài khoản thì đăng ký ở `/register.php`)
2. Vào tab **"API Keys"** → bấm **"Tạo API Key mới"**
3. Copy key có định dạng `loc_sk_xxxx...xxxx`
4. Key chỉ hiển thị **MỘT LẦN DUY NHẤT** khi tạo, hãy lưu lại ngay!

![tao api key]

---

## 2️⃣ Chat Completion — Gọi AI

```
POST http://<IP>:8000/v1/chat/completions
POST http://<IP>:8080/api/v1/chat/completions
Content-Type: application/json
Authorization: Bearer loc_sk_xxxxxxxxxxxxxxxx
```

### 🐍 Dùng với Python (OpenAI SDK)

```python
# pip install openai
from openai import OpenAI

# Thay YOUR_IP = IP server của bạn (VD: 192.168.1.100)
# Thay loc_sk_xxx = API key bạn vừa tạo ở dashboard
client = OpenAI(
    api_key="loc_sk_xxxxxxxxxxxxxxxx",
    base_url="http://YOUR_IP:8080/api/v1"
)

# Chat bình thường
response = client.chat.completions.create(
    model="deepseek-ai/DeepSeek-V4-Pro",
    messages=[
        {"role": "system", "content": "Bạn là trợ lý AI hữu ích."},
        {"role": "user", "content": "Giải thích quantum computing cho tôi"}
    ]
)
print(response.choices[0].message.content)
print(f"Tokens dùng: {response.usage.total_tokens}")

# Streaming (in từng chữ)
stream = client.chat.completions.create(
    model="deepseek-ai/DeepSeek-V4-Pro",
    messages=[{"role": "user", "content": "Viết 1 bài thơ ngắn"}],
    stream=True
)
for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
```

### 🔧 Dùng với cURL

```bash
# Chat thường
curl -X POST http://YOUR_IP:8000/v1/chat/completions \
  -H "Authorization: Bearer loc_sk_xxxxxxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-ai/DeepSeek-V4-Pro",
    "messages": [{"role": "user", "content": "Chào bạn!"}]
  }'

# Streaming
curl -X POST http://YOUR_IP:8000/v1/chat/completions \
  -H "Authorization: Bearer loc_sk_xxxxxxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-ai/DeepSeek-V4-Pro",
    "messages": [{"role": "user", "content": "Kể 1 câu chuyện ngắn"}],
    "stream": true
  }'
```

### 🌐 Dùng với JavaScript/Node.js

```javascript
// npm install openai
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: "loc_sk_xxxxxxxxxxxxxxxx",
  baseURL: "http://YOUR_IP:8080/api/v1",
});

// Non-streaming
const response = await client.chat.completions.create({
  model: "deepseek-ai/DeepSeek-V4-Pro",
  messages: [{ role: "user", content: "Xin chào!" }],
});
console.log(response.choices[0].message.content);

// Streaming
const stream = await client.chat.completions.create({
  model: "deepseek-ai/DeepSeek-V4-Pro",
  messages: [{ role: "user", content: "Kể chuyện cười" }],
  stream: true,
});
for await (const chunk of stream) {
  process.stdout.write(chunk.choices[0]?.delta?.content || "");
}
```

### 🦀 Dùng với Rust

```rust
// Cargo.toml: openai = "1.0"
use openai::Client;

let client = Client::builder()
    .api_key("loc_sk_xxxxxxxxxxxxxxxx")
    .base_url("http://YOUR_IP:8080/api/v1")
    .build()?;

let response = client.chat().create()
    .model("deepseek-ai/DeepSeek-V4-Pro")
    .user_message("Hello world!")
    .send()
    .await?;

println!("{}", response.choices[0].message.content);
```

---

## 3️⃣ Danh sách Models

```bash
curl http://YOUR_IP:8080/api/v1/models
```

Trả về JSON danh sách các model đang active.

---

## 📋 10 Models có sẵn

| # | Model ID | Loại |
|---|---------|------|
| 1 | `deepseek-ai/DeepSeek-V4-Pro` | Chat |
| 2 | `deepseek-ai/Deepseek-V4-Flash` | Chat (nhanh) |
| 3 | `deepseek-ai/DeepSeek-V3-0324` | Chat |
| 4 | `google/gemma-4-31b-it` | Chat |
| 5 | `zai/GLM-5.1` | Chat |
| 6 | `zai/GLM-5.2` | Chat |
| 7 | `openai/gpt-oss-120b` | Chat |
| 8 | `moonshotai/Kimi-K2.6` | Chat |
| 9 | `nvidia/NVIDIA-Nemotron-3-Ultra-550B` | Chat |
| 10 | `Qwen/Qwen3-235B-A22B-Instruct-2507` | Chat |

Tất cả đều hỗ trợ chat completion + streaming.

---

## 💰 Credit & Giá

- Mỗi API key gắn với 1 user, user có số dư credit
- Khi gọi API → hệ thống tự động trừ credit dựa trên số token thực tế
- Giá mỗi model khác nhau (xem ở dashboard / pricing)
- Hết credit → API trả về lỗi 402 `insufficient_credits`

---

## ⚠️ Lỗi thường gặp

| HTTP Code | Lỗi | Nguyên nhân |
|-----------|-----|------------|
| 401 | `invalid_api_key` | API key sai hoặc đã bị khóa |
| 402 | `insufficient_credits` | Hết credit |
| 429 | `rate_limit_exceeded` | Gọi quá nhiều request/phút |
| 502 | `gateway_error` | Gateway Python port 8000 không chạy |

---

## 🏗️ Kiến trúc

```
Bạn (Client)
  │ POST /v1/chat/completions + Bearer loc_sk_xxx
  ▼
PHP Proxy (:8080) → xác thực user từ API key
  │ proxy tiếp
  ▼
Python AI Gateway (:8000)
  ├── Validate API key (SHA256 hash)
  ├── Check credit balance
  ├── Chọn provider phù hợp với model
  ├── Gửi request → DeepSeek / Google / OpenAI / NVIDIA / ...
  ├── Nhận response
  ├── Tự động trừ credit: total_tokens × giá model
  └── Trả response về client
```

---

## 🐳 Deploy server (Ubuntu)

```bash
cd ~/ai-gateway
docker compose up -d --build
docker compose ps                    # kiểm tra status
curl http://localhost:8000/health    # test gateway
```

- Dashboard: `http://<IP>:8080/dashboard.php`
- API Gateway: `http://<IP>:8000`
- Đăng nhập mặc định: `locnguyen` / `Loc12345s@`