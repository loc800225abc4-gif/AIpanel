<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

if (!isLoggedIn()) { http_response_code(401); echo json_encode(['error'=>'Unauthorized']); exit; }

$user = getUser();
$action = $_GET['list'] ?? ($_GET['session_id'] ? 'messages' : 'messages');
$sessionId = $_GET['session_id'] ?? '';

try {
    $db = getDB();
    if (!$db) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
    
    if ($action === 'sessions') {
        // Return list of distinct sessions with last message preview
        $stmt = $db->prepare("
            SELECT 
                session_id,
                MAX(created_at) as last_at,
                COUNT(*) as message_count,
                (SELECT content FROM chat_history c2 WHERE c2.user_id = ch.user_id AND c2.session_id = ch.session_id ORDER BY created_at DESC LIMIT 1) as last_message
            FROM chat_history ch
            WHERE user_id = ? AND session_id IS NOT NULL
            GROUP BY session_id
            ORDER BY last_at DESC
            LIMIT 50
        ");
        if (!$stmt) {
            // Table probably doesn't exist
            echo json_encode(['sessions' => []]);
            exit;
        }
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $sessions = [];
        while ($row = $result->fetch_assoc()) {
            $sessions[] = $row;
        }
        echo json_encode(['sessions' => $sessions]);
    } elseif ($sessionId) {
        $stmt = $db->prepare("SELECT * FROM chat_history WHERE user_id = ? AND session_id = ? ORDER BY created_at ASC LIMIT 200");
        if (!$stmt) {
            echo json_encode(['history' => []]);
            exit;
        }
        $stmt->bind_param("is", $user['id'], $sessionId);
        $stmt->execute();
        $result = $stmt->get_result();
        $history = [];
        while ($row = $result->fetch_assoc()) { $history[] = $row; }
        echo json_encode(['history' => $history]);
    } else {
        $stmt = $db->prepare("SELECT * FROM chat_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 200");
        if (!$stmt) {
            echo json_encode(['history' => []]);
            exit;
        }
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $history = [];
        while ($row = $result->fetch_assoc()) { $history[] = $row; }
        echo json_encode(['history' => $history]);
    }
} catch (\Throwable $e) {
    echo json_encode(['error' => $e->getMessage(), 'sessions' => [], 'history' => []]);
}
