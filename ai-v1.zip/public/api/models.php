<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';
$models = getActiveModels();
echo json_encode($models);