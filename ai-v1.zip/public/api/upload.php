<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

if (!isLoggedIn()) { http_response_code(401); echo json_encode(['error' => 'Unauthorized']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['error' => 'Method not allowed']); exit; }

// Support both 'image' and 'file' field names
$file = $_FILES['image'] ?? $_FILES['file'] ?? null;
if (!$file) { echo json_encode(['error' => 'No file uploaded']); exit; }

// Allowed types
$imageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
$fileTypes = [
    'text/plain', 'text/markdown', 'text/csv', 'text/html', 'text/css',
    'application/json', 'application/xml', 'text/xml',
    'application/pdf',
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/javascript', 'application/x-httpd-php',
    'application/x-python-code', 'text/x-python',
    'application/sql',
    'application/zip', 'application/x-rar-compressed',
];
$allowedTypes = array_merge($imageTypes, $fileTypes);

$maxSize = 20 * 1024 * 1024; // 20MB for files
$maxImageSize = 10 * 1024 * 1024; // 10MB for images

$isImage = in_array($file['type'], $imageTypes);
$isFile = in_array($file['type'], $fileTypes);

if (!$isImage && !$isFile) {
    echo json_encode(['error' => 'Invalid file type: ' . $file['type'] . '. Supported: images, PDF, TXT, CSV, JSON, DOC, XLS, code files']);
    exit;
}

$sizeLimit = $isImage ? $maxImageSize : $maxSize;
if ($file['size'] > $sizeLimit) {
    $limitMB = $sizeLimit / 1024 / 1024;
    echo json_encode(['error' => 'File too large. Max ' . $limitMB . 'MB']);
    exit;
}

if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['error' => 'Upload error code: ' . $file['error']]);
    exit;
}

// Create upload directory
$uploadDir = __DIR__ . '/../uploads/' . date('Y/m');
if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }

// Generate unique filename
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$prefix = $isImage ? 'img_' : 'file_';
$filename = $prefix . uniqid() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
$destPath = $uploadDir . '/' . $filename;

if (!move_uploaded_file($file['tmp_name'], $destPath)) {
    echo json_encode(['error' => 'Failed to save file']);
    exit;
}

$url = SITE_URL . '/uploads/' . date('Y/m') . '/' . $filename;

// For text-based files, extract content for AI processing
$extractedContent = '';
if ($isFile && !$isImage) {
    $extractedContent = extractFileContent($destPath, $ext);
}

echo json_encode([
    'success' => true,
    'url' => $url,
    'filename' => $filename,
    'original_name' => $file['name'],
    'size' => $file['size'],
    'type' => $file['type'],
    'is_image' => $isImage,
    'ext' => $ext,
    'content_preview' => $extractedContent ? substr($extractedContent, 0, 2000) : null,
    'content_length' => $extractedContent ? strlen($extractedContent) : 0
]);

/**
 * Extract text content from uploaded file
 */
function extractFileContent($path, $ext) {
    $textExts = ['txt', 'md', 'csv', 'json', 'xml', 'html', 'css', 'js', 'php', 'py', 'sql', 'yml', 'yaml', 'log', 'sh', 'bat', 'ini', 'cfg', 'conf'];
    
    if (in_array($ext, $textExts)) {
        $content = @file_get_contents($path);
        if ($content !== false && mb_check_encoding($content, 'UTF-8')) {
            return $content;
        }
        // Try converting from common encodings
        $content = @file_get_contents($path);
        if ($content !== false) {
            $detected = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'Shift_JIS'], true);
            if ($detected && $detected !== 'UTF-8') {
                return @mb_convert_encoding($content, 'UTF-8', $detected) ?: '';
            }
        }
    }
    
    // For PDF/DOCX, attempt to extract with available tools
    if ($ext === 'pdf') {
        return extractPdfContent($path);
    }
    if ($ext === 'docx') {
        return extractDocxContent($path);
    }
    
    return '';
}

function extractPdfContent($path) {
    // Try pdftotext if available
    $escapedPath = escapeshellarg($path);
    $output = shell_exec("pdftotext {$escapedPath} - 2>&1");
    if ($output !== null && strlen(trim($output)) > 0) {
        return $output;
    }
    // Try Python PyPDF2
    $pythonScript = "import sys; sys.path.insert(0, '.'); " .
        "try:" .
        " from PyPDF2 import PdfReader;" .
        " reader = PdfReader('{$escapedPath}');" .
        " text = ''.join(page.extract_text() or '' for page in reader.pages);" .
        " print(text[:5000]);" .
        "except Exception as e: print('');";
    $output2 = shell_exec("python -c " . escapeshellarg($pythonScript) . " 2>&1");
    if ($output2 && strlen(trim($output2)) > 0) {
        return $output2;
    }
    return '';
}

function extractDocxContent($path) {
    // Try Python python-docx
    $escapedPath = escapeshellarg($path);
    $pythonScript = "import sys; sys.path.insert(0, '.'); " .
        "try:" .
        " from docx import Document;" .
        " doc = Document('{$escapedPath}');" .
        " text = '\\n'.join(p.text for p in doc.paragraphs);" .
        " print(text[:5000]);" .
        "except Exception as e: print('');";
    $output = shell_exec("python -c " . escapeshellarg($pythonScript) . " 2>&1");
    if ($output && strlen(trim($output)) > 0) {
        return $output;
    }
    // Fallback: try extracting as zip (docx is a zip file)
    $zip = new ZipArchive();
    if ($zip->open($path) === true) {
        $content = $zip->getFromName('word/document.xml');
        $zip->close();
        if ($content) {
            // Strip XML tags, keep text
            $text = strip_tags($content);
            $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
            return substr($text, 0, 5000);
        }
    }
    return '';
}