<?php
/**
 * OpenAI-compatible Models List API
 * Endpoint: GET /api/v1/models
 */

error_reporting(0);
ini_set('display_errors', 0);
while (ob_get_level()) { ob_end_clean(); }

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/functions.php';

// Auth (optional: models can be listed without auth, or require API key)
$apiUser = authenticateApiKey();
if (!$apiUser) {
    // Allow listing models without auth for easier integration
    // But some deployments may want to require auth:
    // http_response_code(401);
    // echo json_encode(['error' => ['message' => 'Invalid API key', 'type' => 'authentication_error', 'code' => 'invalid_api_key']]);
    // exit;
}

$db = getDB();
if (!$db) {
    http_response_code(500);
    echo json_encode(['error' => ['message' => 'Database connection failed.', 'type' => 'server_error']]);
    exit;
}

$models = getActiveModels();

if (empty($models)) {
    echo json_encode([
        'object' => 'list',
        'data' => []
    ]);
    exit;
}

$data = [];
foreach ($models as $m) {
    $data[] = [
        'id' => $m['model_id'],
        'object' => 'model',
        'created' => strtotime($m['created_at'] ?? 'now'),
        'owned_by' => $m['provider'] ?? 'local',
        'name' => $m['name'],
        'description' => $m['description'] ?? '',
        'type' => $m['type'] ?? 'chat',
        'max_tokens' => intval($m['max_tokens'] ?? 4096),
        'pricing' => [
            'input_per_token' => floatval($m['input_price_per_token'] ?? 0),
            'output_per_token' => floatval($m['output_price_per_token'] ?? 0)
        ]
    ];
}

echo json_encode([
    'object' => 'list',
    'data' => $data
], JSON_UNESCAPED_UNICODE);