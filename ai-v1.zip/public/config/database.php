<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!defined('DB_HOST')) {
    // Docker environment variables take priority, fallback to XAMPP localhost
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
    define('DB_USER', getenv('DB_USER') ?: 'root');
    define('DB_PASS', getenv('DB_PASS') ?: '');
    define('DB_NAME', getenv('DB_NAME') ?: 'locnguyen_ai');
}
require_once __DIR__ . '/functions.php';
if (!defined('SITE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $sitePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    define('SITE_URL', $protocol . '://' . $_SERVER['HTTP_HOST'] . ($sitePath === '' ? '' : $sitePath));
}

// Functions moved to config/functions.php
// Include it directly in your files: require_once __DIR__ . '/config/functions.php';