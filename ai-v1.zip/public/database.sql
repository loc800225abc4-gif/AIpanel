-- =============================================
-- LocNguyen AI Platform - Database Schema
-- Version: 1.0
-- =============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

-- =============================================
-- CREATE DATABASE
-- =============================================
CREATE DATABASE IF NOT EXISTS `locnguyen_ai` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `locnguyen_ai`;

-- =============================================
-- 1. USERS TABLE
-- =============================================
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) DEFAULT NULL,
    `avatar` VARCHAR(255) DEFAULT NULL,
    `credits` DECIMAL(10,2) NOT NULL DEFAULT 100.00,
    `total_tokens_used` BIGINT NOT NULL DEFAULT 0,
    `role` ENUM('user','admin') NOT NULL DEFAULT 'user',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 2. ADMINS TABLE
-- =============================================
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `email` VARCHAR(100) DEFAULT NULL,
    `full_name` VARCHAR(100) DEFAULT NULL,
    `role` ENUM('super_admin','admin','moderator') NOT NULL DEFAULT 'admin',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 3. API KEYS TABLE (shared by PHP & AI Gateway)
-- =============================================
DROP TABLE IF EXISTS `api_keys`;
CREATE TABLE `api_keys` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `api_key` VARCHAR(64) NOT NULL UNIQUE,
    `name` VARCHAR(100) NOT NULL DEFAULT 'Default Key',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_used` DATETIME DEFAULT NULL,
    `total_requests` BIGINT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `expires_at` DATETIME DEFAULT NULL,
    -- AI Gateway columns (used by Python, compatible with PHP)
    `key_hash` VARCHAR(255) DEFAULT NULL,
    `key_prefix` VARCHAR(20) DEFAULT NULL,
    `key_suffix` VARCHAR(10) DEFAULT NULL,
    `full_key_hash` VARCHAR(255) DEFAULT NULL UNIQUE,
    `is_locked` TINYINT(1) NOT NULL DEFAULT 0,
    `quota_type` VARCHAR(20) NOT NULL DEFAULT 'unlimited',
    `quota_value` INT NOT NULL DEFAULT 0,
    `quota_used` INT NOT NULL DEFAULT 0,
    `quota_reset_at` DATETIME NULL DEFAULT NULL,
    `rpm_limit` INT NOT NULL DEFAULT 0,
    `tpm_limit` INT NOT NULL DEFAULT 0,
    `last_used_ip` VARCHAR(50) DEFAULT NULL,
    `total_prompt_tokens` BIGINT NOT NULL DEFAULT 0,
    `total_completion_tokens` BIGINT NOT NULL DEFAULT 0,
    `total_tokens` BIGINT NOT NULL DEFAULT 0,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 4. AI MODELS TABLE
-- =============================================
DROP TABLE IF EXISTS `ai_models`;
CREATE TABLE `ai_models` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `provider` VARCHAR(50) NOT NULL,
    `model_id` VARCHAR(100) NOT NULL,
    `type` ENUM('chat','completion','image','embedding','audio') NOT NULL DEFAULT 'chat',
    `description` TEXT DEFAULT NULL,
    `max_tokens` INT NOT NULL DEFAULT 4096,
    `input_price` DECIMAL(10,6) NOT NULL DEFAULT 0.000000 COMMENT 'Price per 1K input tokens',
    `output_price` DECIMAL(10,6) NOT NULL DEFAULT 0.000000 COMMENT 'Price per 1K output tokens',
    `context_window` INT NOT NULL DEFAULT 8192,
    `status` ENUM('active','inactive','deprecated') NOT NULL DEFAULT 'active',
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 5. ADMIN SETTINGS TABLE
-- =============================================
DROP TABLE IF EXISTS `admin_settings`;
CREATE TABLE `admin_settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(100) NOT NULL UNIQUE,
    `setting_value` TEXT DEFAULT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 5b. PROVIDERS TABLE (AI Gateway Python)
-- =============================================
DROP TABLE IF EXISTS `providers`;
CREATE TABLE `providers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `base_url` VARCHAR(500) NOT NULL,
    `api_key` TEXT NOT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `timeout` INT NOT NULL DEFAULT 120,
    `verify_ssl` TINYINT(1) NOT NULL DEFAULT 1,
    `supports_streaming` TINYINT(1) NOT NULL DEFAULT 1,
    `health_status` VARCHAR(50) NOT NULL DEFAULT 'unknown',
    `last_checked` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 5c. MODEL MAPPINGS TABLE (AI Gateway Python)
-- =============================================
DROP TABLE IF EXISTS `model_mappings`;
CREATE TABLE `model_mappings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `provider_id` INT NOT NULL,
    `external_model` VARCHAR(200) NOT NULL COMMENT 'Model name exposed to clients (e.g., gpt-4)',
    `actual_model` VARCHAR(200) NOT NULL COMMENT 'Actual model name on the provider',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`provider_id`) REFERENCES `providers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 6. CHAT HISTORY TABLE
-- =============================================
DROP TABLE IF EXISTS `chat_history`;
CREATE TABLE `chat_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `api_key_id` INT DEFAULT NULL,
    `model` VARCHAR(100) NOT NULL,
    `provider` VARCHAR(50) DEFAULT NULL,
    `role` ENUM('user','assistant','system') NOT NULL,
    `content` LONGTEXT NOT NULL,
    `tokens_input` INT NOT NULL DEFAULT 0,
    `tokens_output` INT NOT NULL DEFAULT 0,
    `tokens_total` INT NOT NULL DEFAULT 0,
    `cost` DECIMAL(10,6) NOT NULL DEFAULT 0.000000,
    `conversation_id` VARCHAR(64) DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(500) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`api_key_id`) REFERENCES `api_keys`(`id`) ON DELETE SET NULL,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_conversation_id` (`conversation_id`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_model` (`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 7. USAGE LOGS TABLE
-- =============================================
DROP TABLE IF EXISTS `usage_logs`;
CREATE TABLE `usage_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `api_key_id` INT DEFAULT NULL,
    `model` VARCHAR(100) NOT NULL,
    `provider` VARCHAR(50) DEFAULT NULL,
    `request_type` ENUM('chat','completion','image','embedding','audio') NOT NULL DEFAULT 'chat',
    `input_tokens` INT NOT NULL DEFAULT 0,
    `output_tokens` INT NOT NULL DEFAULT 0,
    `tokens_total` INT NOT NULL DEFAULT 0,
    `estimated_cost` DECIMAL(10,6) NOT NULL DEFAULT 0.000000,
    `actual_cost` DECIMAL(10,6) NOT NULL DEFAULT 0.000000,
    `cost` DECIMAL(10,6) NOT NULL DEFAULT 0.000000,
    `credits_used` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `status` ENUM('success','error','rate_limited') NOT NULL DEFAULT 'success',
    `error_message` TEXT DEFAULT NULL,
    `response_time_ms` INT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`api_key_id`) REFERENCES `api_keys`(`id`) ON DELETE SET NULL,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_model` (`model`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- 8. PRICING PLANS TABLE (Optional)
-- =============================================
DROP TABLE IF EXISTS `pricing_plans`;
CREATE TABLE `pricing_plans` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(50) NOT NULL UNIQUE,
    `description` TEXT DEFAULT NULL,
    `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `credits` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `features` TEXT DEFAULT NULL COMMENT 'JSON array of features',
    `is_popular` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- SEED DATA: DEFAULT ADMIN
-- Password: Loc12345s@ (bcrypt hash)
-- =============================================
INSERT INTO `admins` (`username`, `password`, `email`, `full_name`, `role`, `is_active`) VALUES
('locnguyen', '$2y$12$haZoGqMUX2VYmiJqvHsEou5O7neGpaxY9XWjSKOEBnOWg6w4YBY2u', 'admin@locnguyen.ai', 'Loc Nguyen', 'super_admin', 1);

-- =============================================
-- SEED DATA: AI MODELS (12 models from top providers)
-- =============================================
INSERT INTO `ai_models` (`name`, `provider`, `model_id`, `type`, `description`, `max_tokens`, `input_price`, `output_price`, `context_window`, `status`, `sort_order`) VALUES
('GPT-4o', 'OpenAI', 'gpt-4o', 'chat', 'Most advanced multimodal model from OpenAI. Fast, intelligent, and capable of understanding text, images, and audio.', 16384, 0.002500, 0.010000, 128000, 'active', 1),
('GPT-4o-mini', 'OpenAI', 'gpt-4o-mini', 'chat', 'Smaller, faster, and more affordable version of GPT-4o. Great for everyday tasks.', 16384, 0.000150, 0.000600, 128000, 'active', 2),
('o1-mini', 'OpenAI', 'o1-mini', 'chat', 'Fast and affordable reasoning model. Excels at complex problem-solving, coding, and math.', 65536, 0.001100, 0.004400, 128000, 'active', 3),
('Claude 3.5 Sonnet', 'Anthropic', 'claude-3-5-sonnet-20241022', 'chat', 'Anthropic''s most intelligent model. Excellent for complex tasks, writing, analysis, and coding.', 8192, 0.003000, 0.015000, 200000, 'active', 4),
('Claude 3 Opus', 'Anthropic', 'claude-3-opus-20240229', 'chat', 'Powerful model for highly complex tasks. Best for nuanced analysis and sophisticated reasoning.', 4096, 0.015000, 0.075000, 200000, 'active', 5),
('Claude 3 Haiku', 'Anthropic', 'claude-3-haiku-20240307', 'chat', 'Fastest and most compact Claude model. Ideal for quick responses and simple tasks.', 4096, 0.000250, 0.001250, 200000, 'active', 6),
('Gemini 2.0 Flash', 'Google', 'gemini-2.0-flash-exp', 'chat', 'Next-gen Gemini with significantly improved speed and multimodal capabilities.', 8192, 0.000000, 0.000000, 1048576, 'active', 7),
('Gemini 1.5 Pro', 'Google', 'gemini-1.5-pro', 'chat', 'Mid-size multimodal model with very long context window. Great for document analysis.', 8192, 0.001250, 0.005000, 2097152, 'active', 8),
('DeepSeek V3', 'DeepSeek', 'deepseek-chat', 'chat', 'Latest DeepSeek model with 671B MoE parameters. Strong performance at affordable pricing.', 8192, 0.000270, 0.001100, 65536, 'active', 9),
('DeepSeek R1', 'DeepSeek', 'deepseek-reasoner', 'chat', 'DeepSeek reasoning model. Best for math, coding, and logical reasoning tasks.', 8192, 0.000550, 0.002190, 65536, 'active', 10),
('Llama 3.1 70B', 'Meta', 'llama-3.1-70b-versatile', 'chat', 'Meta''s open-source 70B parameter model. Strong all-around performance.', 8192, 0.000590, 0.000790, 128000, 'active', 11),
('Mixtral 8x7B', 'Mistral', 'mixtral-8x7b-32768', 'chat', 'Mistral''s mixture-of-experts model. High quality with excellent speed and 32K context.', 32768, 0.000240, 0.000240, 32768, 'active', 12);

-- =============================================
-- SEED DATA: DEFAULT SETTINGS
-- =============================================
INSERT INTO `admin_settings` (`setting_key`, `setting_value`, `description`) VALUES
('site_name', 'LocNguyen AI', 'Site name displayed everywhere'),
('site_description', 'AI Platform - Truy cập mọi AI model từ một nơi duy nhất', 'Site meta description'),
('default_credits', '100', 'Default credits for new users'),
('credit_cost_per_dollar', '1000', 'How many credits per 1 USD'),
('openai_base_url', 'https://api.openai.com/v1', 'OpenAI API Base URL'),
('openai_api_key', '', 'OpenAI API Key'),
('anthropic_base_url', 'https://api.anthropic.com/v1', 'Anthropic API Base URL'),
('anthropic_api_key', '', 'Anthropic API Key'),
('google_base_url', 'https://generativelanguage.googleapis.com/v1beta', 'Google Gemini API Base URL'),
('google_api_key', '', 'Google Gemini API Key'),
('deepseek_base_url', 'https://api.deepseek.com/v1', 'DeepSeek API Base URL'),
('deepseek_api_key', '', 'DeepSeek API Key'),
('meta_base_url', 'https://api.groq.com/openai/v1', 'Meta Llama API Base URL (via Groq)'),
('meta_api_key', '', 'Groq API Key for Llama models'),
('mistral_base_url', 'https://api.mistral.ai/v1', 'Mistral API Base URL'),
('mistral_api_key', '', 'Mistral API Key');

-- =============================================
-- SEED DATA: PRICING PLANS
-- =============================================
INSERT INTO `pricing_plans` (`name`, `slug`, `description`, `price`, `credits`, `features`, `is_popular`, `status`, `sort_order`) VALUES
('Miễn Phí', 'free', 'Dùng thử với credits miễn phí', 0.00, 100.00, '["100 credits miễn phí","Truy cập tất cả models","Hỗ trợ cơ bản","Giới hạn 50 requests/ngày"]', 0, 'active', 1),
('Cơ Bản', 'basic', 'Dành cho cá nhân sử dụng thường xuyên', 9.99, 5000.00, '["5,000 credits/tháng","Truy cập tất cả models","Streaming support","Hỗ trợ email","Không giới hạn requests"]', 0, 'active', 2),
('Pro', 'pro', 'Dành cho chuyên gia và developer', 29.99, 20000.00, '["20,000 credits/tháng","Truy cập tất cả models","Ưu tiên tốc độ xử lý","API access","Hỗ trợ ưu tiên 24/7","Custom models"]', 1, 'active', 3),
('Enterprise', 'enterprise', 'Dành cho doanh nghiệp và tổ chức', 99.99, 100000.00, '["100,000+ credits/tháng","Tất cả models + custom","Dedicated server","SLA 99.99%","Hỗ trợ dedicated","Tích hợp tùy chỉnh","Quản lý team"]', 0, 'active', 4);

COMMIT;

-- =============================================
-- VERIFICATION QUERIES
-- =============================================
-- Check tables created:
-- SHOW TABLES;

-- Check admin account:
-- SELECT username, role, is_active, created_at FROM admins;

-- Check AI models:
-- SELECT id, name, provider, status FROM ai_models ORDER BY sort_order;

-- Check settings:
-- SELECT setting_key, setting_value FROM admin_settings;

-- Check pricing plans:
-- SELECT name, price, credits, status FROM pricing_plans ORDER BY sort_order;