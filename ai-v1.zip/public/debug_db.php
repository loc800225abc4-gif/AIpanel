<?php
/**
 * Debug script - check database connection and required tables
 * Delete this file after debugging!
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';

echo "<h2>Debug Database Connection</h2>";

// Test connection
$db = getDB();
if (!$db) {
    echo "<p style='color:red;'>❌ getDB() returned null - Database connection failed!</p>";
    echo "<p>Check DB_HOST, DB_USER, DB_PASS, DB_NAME in config/database.php</p>";
    echo "<p>Current values:</p>";
    echo "<ul>";
    echo "<li>DB_HOST: " . DB_HOST . "</li>";
    echo "<li>DB_USER: " . DB_USER . "</li>";
    echo "<li>DB_NAME: " . DB_NAME . "</li>";
    echo "</ul>";
    exit;
}

echo "<p style='color:green;'>✅ Database connected successfully!</p>";

// Check required tables
$requiredTables = ['users', 'api_keys', 'user_api_keys', 'admin_settings', 'ai_models', 'chat_history', 'usage_logs', 'credit_logs'];
echo "<h3>Required Tables:</h3>";
echo "<ul>";
foreach ($requiredTables as $table) {
    $result = $db->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "<li style='color:green;'>✅ $table - exists</li>";
    } else {
        echo "<li style='color:red;'>❌ $table - MISSING!</li>";
    }
}
echo "</ul>";

// Check columns in users table
echo "<h3>Users table columns:</h3>";
$result = $db->query("SHOW COLUMNS FROM users");
if ($result) {
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>" . $row['Field'] . " (" . $row['Type'] . ")</li>";
    }
    echo "</ul>";
}

// Check if admin user exists
$adminCheck = $db->query("SELECT id, username, role FROM users WHERE role = 'admin' LIMIT 1");
if ($adminCheck && $adminCheck->num_rows > 0) {
    $admin = $adminCheck->fetch_assoc();
    echo "<p style='color:green;'>✅ Admin user exists: " . sanitize($admin['username']) . "</p>";
} else {
    echo "<p style='color:orange;'>⚠️ No admin user found. Run install.php first.</p>";
}

// Test session
echo "<h3>Session Test:</h3>";
var_dump($_SESSION);

echo "<p><strong>Delete this file after debugging!</strong></p>";
</final_file_content>
<task_progress>
- [x] Fix API key creation and API implementation
- [x] Test Python SDK
- [x] Create stunning landing page (home.php) with pricing, community section, model showcase
- [x] Update routing to redirect non-logged-in users to home.php
- [x] Add Zalo group link setting to admin settings
- [ ] Debug HTTP 500 on production host for login/register
</task_progress>
</write_to_file>