<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

$siteName = getSetting('site_name', 'LocNguyen AI');
$zaloGroup = getSetting('zalo_group_link', 'https://zalo.me/g/yourgroup');
$models = [];
try { $models = getActiveModels(); } catch (Exception $e) {}
$modelCount = count($models);
$isLoggedIn = isLoggedIn();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo sanitize($siteName); ?> - Nền tảng AI Toàn Diện Cho Người Việt</title>
    <meta name="description" content="Truy cập các mô hình AI mạnh nhất: DeepSeek, GPT-4, GLM, Kimi... với giá siêu rẻ. Hỗ trợ OpenAI SDK.">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 100 100%27><text y=%27.9em%27 font-size=%2790%27>🧠</text></svg>">
    <style>
        :root {
            --bg: #030712; --bg2: #0a0f1e; --card: #0f172a; --card2: #1e293b;
            --border: #1e293b; --border-light: #334155;
            --text: #f1f5f9; --text2: #94a3b8; --text3: #64748b;
            --accent: #6366f1; --accent-light: #818cf8; --accent-dark: #4f46e5;
            --accent-glow: rgba(99,102,241,0.35);
            --green: #22c55e; --green-glow: rgba(34,197,94,0.3);
            --red: #ef4444; --orange: #f59e0b;
            --radius: 12px; --radius-lg: 20px; --radius-xl: 24px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg); color: var(--text);
            min-height: 100vh; line-height: 1.6;
            overflow-x: hidden;
        }
        a { text-decoration: none; color: inherit; }

        /* ===== AMBIENT BACKGROUND ===== */
        body::before {
            content: ''; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background:
                radial-gradient(ellipse 80% 50% at 50% -20%, rgba(99,102,241,0.12), transparent),
                radial-gradient(ellipse 50% 80% at 20% 60%, rgba(34,197,94,0.06), transparent),
                radial-gradient(ellipse 50% 60% at 80% 30%, rgba(236,72,153,0.04), transparent);
            pointer-events: none; z-index: 0;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
            padding: 16px 32px; background: rgba(3,7,18,0.85);
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,255,255,0.06);
            display: flex; align-items: center; justify-content: space-between;
            transition: all 0.3s;
        }
        .navbar.scrolled { padding: 10px 32px; background: rgba(3,7,18,0.95); }
        .nav-logo { display: flex; align-items: center; gap: 10px; font-weight: 800; font-size: 1.2rem; }
        .nav-logo .icon {
            width: 38px; height: 38px;
            background: linear-gradient(135deg, var(--accent), #7c3aed);
            border-radius: 10px; display: flex;
            align-items: center; justify-content: center; font-size: 1.2rem;
            box-shadow: 0 4px 20px var(--accent-glow);
        }
        .nav-links { display: flex; gap: 28px; align-items: center; }
        .nav-links a { color: var(--text2); font-weight: 500; font-size: 0.9rem; transition: color 0.2s; }
        .nav-links a:hover { color: var(--text); }
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; border-radius: 10px; font-weight: 600; font-size: 0.9rem; cursor: pointer; transition: all 0.3s; border: none; font-family: 'Inter', sans-serif; }
        .btn-primary { background: linear-gradient(135deg, var(--accent), #7c3aed); color: #fff; box-shadow: 0 4px 20px rgba(99,102,241,0.3); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(99,102,241,0.5); }
        .btn-outline { background: transparent; border: 1.5px solid var(--border-light); color: var(--text); }
        .btn-outline:hover { border-color: var(--accent-light); background: rgba(99,102,241,0.05); }
        .btn-lg { padding: 16px 32px; font-size: 1rem; border-radius: 12px; }
        .btn-sm { padding: 8px 16px; font-size: 0.8rem; }

        /* ===== HERO ===== */
        .hero {
            position: relative; z-index: 1;
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            padding: 140px 24px 80px; text-align: center;
        }
        .hero-content { max-width: 850px; }
        .hero-badge {
            display: inline-flex; align-items: center; gap: 8px;
            background: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.25);
            padding: 8px 20px; border-radius: 50px; font-size: 0.85rem; color: var(--accent-light);
            margin-bottom: 28px; font-weight: 500; animation: fadeInUp 0.6s ease-out;
        }
        .hero-badge .dot { width: 8px; height: 8px; background: var(--green); border-radius: 50%; animation: pulse 2s infinite; }
        @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(34,197,94,0.4); } 50% { box-shadow: 0 0 0 10px rgba(34,197,94,0); } }
        .hero h1 {
            font-size: clamp(2.4rem, 6vw, 4rem); font-weight: 900; line-height: 1.15;
            margin-bottom: 20px; letter-spacing: -0.02em;
            animation: fadeInUp 0.6s ease-out 0.1s both;
        }
        .hero h1 .gradient-text {
            background: linear-gradient(135deg, #a5b4fc, #7c3aed, #6366f1);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .hero p {
            font-size: 1.2rem; color: var(--text2); max-width: 600px; margin: 0 auto 36px;
            line-height: 1.7; animation: fadeInUp 0.6s ease-out 0.2s both;
        }
        .hero-buttons { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; animation: fadeInUp 0.6s ease-out 0.3s both; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }

        /* ===== STATS ===== */
        .stats-strip {
            position: relative; z-index: 1;
            display: flex; justify-content: center; gap: 48px;
            padding: 0 24px 60px; flex-wrap: wrap;
        }
        .stat-item { text-align: center; }
        .stat-num { font-size: 2.4rem; font-weight: 800; background: linear-gradient(135deg, #fff, #a5b4fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .stat-label { font-size: 0.85rem; color: var(--text3); margin-top: 4px; }

        /* ===== SECTION STYLES ===== */
        section { position: relative; z-index: 1; padding: 80px 24px; }
        .section-header { text-align: center; margin-bottom: 60px; }
        .section-tag { display: inline-block; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; letter-spacing: 2px; color: var(--accent-light); margin-bottom: 12px; }
        .section-header h2 { font-size: clamp(1.8rem, 3.5vw, 2.5rem); font-weight: 800; margin-bottom: 12px; }
        .section-header p { color: var(--text2); max-width: 550px; margin: 0 auto; font-size: 1.05rem; }

        /* ===== FEATURES ===== */
        .features-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px; max-width: 1100px; margin: 0 auto;
        }
        .feature-card {
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius-lg); padding: 32px 28px;
            transition: all 0.3s; position: relative; overflow: hidden;
        }
        .feature-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
            opacity: 0; transition: opacity 0.3s;
        }
        .feature-card:hover { transform: translateY(-4px); border-color: rgba(99,102,241,0.3); box-shadow: 0 12px 40px rgba(99,102,241,0.08); }
        .feature-card:hover::before { opacity: 1; }
        .feature-icon {
            width: 52px; height: 52px; border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; margin-bottom: 20px;
        }
        .feature-card h3 { font-size: 1.1rem; font-weight: 700; margin-bottom: 8px; }
        .feature-card p { color: var(--text3); font-size: 0.9rem; line-height: 1.6; }

        /* ===== MODELS SHOWCASE ===== */
        .models-showcase { background: var(--bg2); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); }
        .model-scroll {
            display: flex; gap: 16px; overflow-x: auto; padding: 20px 0;
            max-width: 1100px; margin: 0 auto;
            scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch;
        }
        .model-scroll::-webkit-scrollbar { height: 4px; }
        .model-scroll::-webkit-scrollbar-thumb { background: var(--border-light); border-radius: 4px; }
        .model-chip {
            flex-shrink: 0; scroll-snap-align: start;
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius-lg); padding: 20px 24px;
            display: flex; align-items: center; gap: 14px;
            min-width: 260px; transition: all 0.3s;
        }
        .model-chip:hover { border-color: var(--accent-light); box-shadow: 0 8px 30px rgba(99,102,241,0.1); }
        .model-chip-avatar {
            width: 48px; height: 48px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem; flex-shrink: 0;
        }
        .model-chip-info .mname { font-weight: 600; font-size: 0.95rem; }
        .model-chip-info .mprov { font-size: 0.8rem; color: var(--text3); }

        /* ===== PRICING ===== */
        .pricing-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px; max-width: 1100px; margin: 0 auto;
        }
        .pricing-card {
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius-xl); padding: 36px 28px;
            text-align: center; position: relative; transition: all 0.3s;
        }
        .pricing-card.featured {
            border-color: rgba(99,102,241,0.5);
            background: linear-gradient(180deg, rgba(99,102,241,0.06) 0%, var(--card) 40%);
            box-shadow: 0 8px 40px rgba(99,102,241,0.12);
        }
        .pricing-card.featured::before {
            content: 'PHỔ BIẾN NHẤT'; position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
            background: linear-gradient(135deg, var(--accent), #7c3aed);
            color: #fff; font-size: 0.75rem; font-weight: 700; padding: 6px 20px;
            border-radius: 50px; letter-spacing: 0.5px;
        }
        .pricing-card:hover { transform: translateY(-4px); border-color: rgba(99,102,241,0.3); }
        .pricing-name { font-size: 1.1rem; font-weight: 700; margin-bottom: 8px; }
        .pricing-price { margin: 16px 0 8px; display: flex; align-items: baseline; justify-content: center; gap: 4px; }
        .pricing-price .amount { font-size: 2.8rem; font-weight: 900; }
        .pricing-price .currency { font-size: 1.1rem; color: var(--text2); font-weight: 600; }
        .pricing-duration { color: var(--text3); font-size: 0.9rem; margin-bottom: 24px; }
        .pricing-features { text-align: left; margin-bottom: 28px; list-style: none; }
        .pricing-features li { padding: 8px 0; color: var(--text2); font-size: 0.9rem; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid rgba(255,255,255,0.03); }
        .pricing-features li i { color: var(--green); font-size: 0.85rem; flex-shrink: 0; width: 18px; text-align: center; }
        .pricing-note { margin-top: 16px; font-size: 0.78rem; color: var(--text3); }

        /* ===== COMMUNITY ===== */
        .community-section {
            background: linear-gradient(180deg, transparent, rgba(99,102,241,0.04), transparent);
            border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
        }
        .community-content { max-width: 700px; margin: 0 auto; text-align: center; }
        .zalo-card {
            background: linear-gradient(135deg, rgba(0,132,255,0.1), rgba(0,102,204,0.05));
            border: 1.5px solid rgba(0,132,255,0.3); border-radius: var(--radius-xl);
            padding: 36px 28px; display: inline-flex; flex-direction: column; align-items: center; gap: 16px;
            transition: all 0.3s;
        }
        .zalo-card:hover { border-color: rgba(0,132,255,0.6); box-shadow: 0 8px 40px rgba(0,132,255,0.1); transform: translateY(-2px); }
        .zalo-icon {
            width: 72px; height: 72px; border-radius: 20px;
            background: linear-gradient(135deg, #0084ff, #0066cc);
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; color: #fff; box-shadow: 0 8px 30px rgba(0,132,255,0.3);
        }
        .zalo-card h3 { font-size: 1.3rem; font-weight: 700; }
        .zalo-card p { color: var(--text2); font-size: 0.95rem; max-width: 450px; }

        /* ===== CTA ===== */
        .cta-section { text-align: center; }
        .cta-card {
            background: linear-gradient(135deg, rgba(99,102,241,0.08), rgba(124,58,237,0.06));
            border: 1px solid rgba(99,102,241,0.2); border-radius: var(--radius-xl);
            padding: 56px 28px; max-width: 700px; margin: 0 auto;
        }
        .cta-card h2 { font-size: clamp(1.6rem, 3.5vw, 2.2rem); font-weight: 800; margin-bottom: 12px; }
        .cta-card p { color: var(--text2); margin-bottom: 28px; font-size: 1.05rem; }

        /* ===== FOOTER ===== */
        footer {
            border-top: 1px solid var(--border); padding: 32px 24px;
            text-align: center; font-size: 0.85rem; color: var(--text3); position: relative; z-index: 1;
        }
        footer a { color: var(--accent-light); }
        footer a:hover { text-decoration: underline; }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .navbar { padding: 12px 20px; }
            .nav-links { display: none; }
            .hero { padding: 120px 20px 60px; }
            .hero h1 { font-size: 2rem; }
            .hero p { font-size: 1rem; }
            .stats-strip { gap: 28px; }
            .stat-num { font-size: 1.8rem; }
            section { padding: 50px 20px; }
            .pricing-grid { grid-template-columns: 1fr; max-width: 400px; }
            .model-scroll { padding: 10px 0; }
            .model-chip { min-width: 220px; padding: 16px 18px; }
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar" id="navbar">
    <a href="home.php" class="nav-logo">
        <div class="icon">🧠</div>
        <span style="background:linear-gradient(135deg,#fff,#a5b4fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;"><?php echo sanitize($siteName); ?></span>
    </a>
    <div class="nav-links">
        <a href="#features">Tính năng</a>
        <a href="#models">Mô hình</a>
        <a href="#pricing">Bảng giá</a>
        <a href="#community">Cộng đồng</a>
        <?php if ($isLoggedIn): ?>
            <a href="index.php" class="btn btn-primary btn-sm">Chat ngay →</a>
        <?php else: ?>
            <a href="login.php" class="btn btn-outline btn-sm">Đăng nhập</a>
            <a href="register.php" class="btn btn-primary btn-sm">Dùng thử miễn phí</a>
        <?php endif; ?>
    </div>
</nav>

<!-- HERO -->
<section class="hero">
    <div class="hero-content">
        <div class="hero-badge">
            <span class="dot"></span> <?php echo $modelCount > 0 ? $modelCount . '+ mô hình AI' : 'Nhiều mô hình AI'; ?> sẵn sàng phục vụ
        </div>
        <h1>
            Trợ Lý AI <span class="gradient-text">Thông Minh</span><br>Cho Người Việt
        </h1>
        <p>
            Truy cập các mô hình AI mạnh nhất thế giới: DeepSeek, GPT-4, GLM, Kimi, Qwen...
            Tất cả trong một nền tảng duy nhất. Tương thích OpenAI SDK. Giá siêu rẻ.
        </p>
        <div class="hero-buttons">
            <?php if ($isLoggedIn): ?>
                <a href="index.php" class="btn btn-primary btn-lg">🚀 Bắt đầu chat ngay</a>
                <a href="dashboard.php" class="btn btn-outline btn-lg">📊 Dashboard</a>
            <?php else: ?>
                <a href="register.php" class="btn btn-primary btn-lg">🚀 Dùng thử miễn phí</a>
                <a href="#pricing" class="btn btn-outline btn-lg">📋 Xem bảng giá</a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- STATS STRIP -->
<div class="stats-strip">
    <div class="stat-item"><div class="stat-num"><?php echo $modelCount; ?>+</div><div class="stat-label">Mô hình AI</div></div>
    <div class="stat-item"><div class="stat-num">24/7</div><div class="stat-label">Hoạt động</div></div>
    <div class="stat-item"><div class="stat-num">OpenAI</div><div class="stat-label">SDK Compatible</div></div>
    <div class="stat-item"><div class="stat-num">VNĐ</div><div class="stat-label">Thanh toán nội địa</div></div>
</div>

<!-- FEATURES -->
<section id="features">
    <div class="section-header">
        <div class="section-tag">TÍNH NĂNG</div>
        <h2>Mọi thứ bạn cần trong một nền tảng</h2>
        <p>Được thiết kế để mang lại trải nghiệm AI tốt nhất cho người dùng Việt Nam</p>
    </div>
    <div class="features-grid">
        <div class="feature-card">
            <div class="feature-icon" style="background:rgba(99,102,241,0.12);">🤖</div>
            <h3><?php echo $modelCount; ?>+ Mô Hình AI</h3>
            <p>Từ DeepSeek, GPT-4, GLM, Kimi, Qwen đến Llama, Gemma... Tất cả đều có sẵn, sẵn sàng phục vụ mọi nhu cầu.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon" style="background:rgba(34,197,94,0.12);">🔌</div>
            <h3>Tương Thích OpenAI SDK</h3>
            <p>Sử dụng <code style="background:rgba(99,102,241,0.1);padding:2px 6px;border-radius:4px;">from openai import OpenAI</code> để gọi API. Không cần học cú pháp mới.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon" style="background:rgba(245,158,11,0.12);">💰</div>
            <h3>Giá Siêu Rẻ - VNĐ</h3>
            <p>Không giới hạn token theo gói. Thanh toán bằng VNĐ qua chuyển khoản. Giá chỉ từ 200K/tuần.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon" style="background:rgba(236,72,153,0.12);">⚡</div>
            <h3>Tốc Độ Cao</h3>
            <p>Máy chủ tối ưu, phản hồi nhanh. Hỗ trợ streaming real-time để bạn thấy câu trả lời từng chữ một.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon" style="background:rgba(14,165,233,0.12);">🔒</div>
            <h3>Bảo Mật & Riêng Tư</h3>
            <p>Dữ liệu của bạn được mã hóa và bảo vệ. API key riêng cho mỗi người dùng, dễ dàng quản lý.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon" style="background:rgba(168,85,247,0.12);">📱</div>
            <h3>Giao Diện Thân Thiện</h3>
            <p>Dark mode mặc định, responsive trên mọi thiết bị. Chat như ChatGPT nhưng với nhiều model hơn.</p>
        </div>
    </div>
</section>

<!-- MODELS SHOWCASE -->
<section id="models" class="models-showcase">
    <div class="section-header">
        <div class="section-tag">MÔ HÌNH</div>
        <h2>Các mô hình AI hàng đầu</h2>
        <p>Luôn cập nhật những model mới nhất và mạnh nhất</p>
    </div>
    <div class="model-scroll">
        <?php
        $providerColors = [
            'deepseek' => ['#3b82f6', 'rgba(59,130,246,0.15)'],
            'zhipu' => ['#22c55e', 'rgba(34,197,94,0.15)'],
            'moonshot' => ['#ec4899', 'rgba(236,72,153,0.15)'],
            'alibaba' => ['#f59e0b', 'rgba(245,158,11,0.15)'],
            'nvidia' => ['#22c55e', 'rgba(34,197,94,0.15)'],
            'openai' => ['#6366f1', 'rgba(99,102,241,0.15)'],
            'meta' => ['#a855f7', 'rgba(168,85,247,0.15)'],
            'google' => ['#ef4444', 'rgba(239,68,68,0.15)'],
            'mistral' => ['#0ea5e9', 'rgba(14,165,233,0.15)'],
        ];
        if (empty($models)): ?>
            <div class="model-chip"><span style="color:var(--text3)">Chưa có mô hình nào. Vui lòng cài đặt.</span></div>
        <?php else:
            foreach ($models as $m):
                $provider = strtolower($m['provider'] ?? '');
                $colors = $providerColors[$provider] ?? ['#6366f1', 'rgba(99,102,241,0.15)'];
                $icon = match($provider) {
                    'deepseek' => '🐋', 'zhipu' => '🌐', 'moonshot' => '🌙',
                    'alibaba' => '☁️', 'nvidia' => '🖥️', 'openai' => '🧠',
                    'meta' => '🦙', 'google' => '🔍', 'mistral' => '💨',
                    default => '🤖'
                };
        ?>
        <div class="model-chip">
            <div class="model-chip-avatar" style="background:<?php echo $colors[1]; ?>;"><?php echo $icon; ?></div>
            <div class="model-chip-info">
                <div class="mname"><?php echo sanitize($m['name']); ?></div>
                <div class="mprov"><?php echo sanitize($m['provider'] ?? 'Unknown'); ?></div>
            </div>
        </div>
        <?php endforeach; endif; ?>
    </div>
</section>

<!-- PRICING -->
<section id="pricing">
    <div class="section-header">
        <div class="section-tag">BẢNG GIÁ</div>
        <h2>Gói dịch vụ - Không giới hạn token</h2>
        <p>Chọn gói phù hợp với nhu cầu của bạn. Tất cả đều không giới hạn số lượng token sử dụng.</p>
    </div>
    <div class="pricing-grid">
        <!-- GÓI 7 NGÀY -->
        <div class="pricing-card">
            <div class="pricing-name">⚡ Gói 7 Ngày</div>
            <div class="pricing-price"><span class="amount">200</span><span class="currency">.000đ</span></div>
            <div class="pricing-duration">/ 7 ngày</div>
            <ul class="pricing-features">
                <li><i class="fas fa-check-circle"></i> Không giới hạn token</li>
                <li><i class="fas fa-check-circle"></i> Tất cả mô hình AI</li>
                <li><i class="fas fa-check-circle"></i> Streaming real-time</li>
                <li><i class="fas fa-check-circle"></i> Hỗ trợ OpenAI SDK</li>
                <li><i class="fas fa-check-circle"></i> Upload file (PDF, DOCX...)</li>
                <li><i class="fas fa-check-circle"></i> Hỗ trợ qua nhóm Zalo</li>
            </ul>
            <a href="#community" class="btn btn-outline" style="width:100%;justify-content:center;">Liên hệ mua →</a>
            <div class="pricing-note">~28.600đ/ngày</div>
        </div>

        <!-- GÓI 14 NGÀY (FEATURED) -->
        <div class="pricing-card featured">
            <div class="pricing-name">🔥 Gói 14 Ngày</div>
            <div class="pricing-price"><span class="amount">380</span><span class="currency">.000đ</span></div>
            <div class="pricing-duration">/ 14 ngày</div>
            <ul class="pricing-features">
                <li><i class="fas fa-check-circle"></i> Không giới hạn token</li>
                <li><i class="fas fa-check-circle"></i> Tất cả mô hình AI</li>
                <li><i class="fas fa-check-circle"></i> Streaming real-time</li>
                <li><i class="fas fa-check-circle"></i> Hỗ trợ OpenAI SDK</li>
                <li><i class="fas fa-check-circle"></i> Upload file (PDF, DOCX...)</li>
                <li><i class="fas fa-check-circle"></i> Hỗ trợ qua nhóm Zalo</li>
                <li><i class="fas fa-check-circle"></i> Tiết kiệm 20.000đ</li>
            </ul>
            <a href="#community" class="btn btn-primary" style="width:100%;justify-content:center;">Liên hệ mua →</a>
            <div class="pricing-note">~27.100đ/ngày · Tiết kiệm nhất</div>
        </div>

        <!-- GÓI 1 THÁNG -->
        <div class="pricing-card">
            <div class="pricing-name">💎 Gói 1 Tháng</div>
            <div class="pricing-price"><span class="amount">650</span><span class="currency">.000đ</span></div>
            <div class="pricing-duration">/ 30 ngày</div>
            <ul class="pricing-features">
                <li><i class="fas fa-check-circle"></i> Không giới hạn token</li>
                <li><i class="fas fa-check-circle"></i> Tất cả mô hình AI</li>
                <li><i class="fas fa-check-circle"></i> Streaming real-time</li>
                <li><i class="fas fa-check-circle"></i> Hỗ trợ OpenAI SDK</li>
                <li><i class="fas fa-check-circle"></i> Upload file (PDF, DOCX...)</li>
                <li><i class="fas fa-check-circle"></i> Hỗ trợ qua nhóm Zalo</li>
                <li><i class="fas fa-check-circle"></i> Ưu tiên hỗ trợ</li>
            </ul>
            <a href="#community" class="btn btn-outline" style="width:100%;justify-content:center;">Liên hệ mua →</a>
            <div class="pricing-note">~21.700đ/ngày · Giá trị nhất</div>
        </div>
    </div>

    <div style="text-align:center;margin-top:30px;">
        <p style="color:var(--text3);font-size:0.9rem;">
            💡 Cần mua thêm credit riêng? Liên hệ qua nhóm Zalo bên dưới để được tư vấn.
        </p>
    </div>
</section>

<!-- COMMUNITY -->
<section id="community" class="community-section">
    <div class="section-header">
        <div class="section-tag">CỘNG ĐỒNG</div>
        <h2>Tham gia cùng chúng tôi</h2>
        <p>Kết nối với cộng đồng người dùng, nhận hỗ trợ nhanh chóng và cập nhật tính năng mới nhất</p>
    </div>
    <div class="community-content">
        <div class="zalo-card">
            <div class="zalo-icon">
                <svg viewBox="0 0 24 24" width="36" height="36" fill="white"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-1 14h-2v-2h2v2zm4 0h-2v-2h2v2zm0-4h-2V8h2v4z"/></svg>
            </div>
            <h3>Nhóm Zalo Chính Thức</h3>
            <p>Tham gia nhóm Zalo để nhận hỗ trợ nhanh nhất, cập nhật model mới, báo lỗi, và trao đổi với cộng đồng người dùng <?php echo sanitize($siteName); ?>.</p>
            <p style="color:var(--text3);font-size:0.85rem;">
                📌 Mọi giao dịch mua gói, nạp credit đều thực hiện qua nhóm Zalo.<br>
                Admin sẽ trực tiếp hỗ trợ bạn trong thời gian sớm nhất.
            </p>
            <a href="<?php echo $zaloGroup; ?>" target="_blank" rel="noopener" class="btn btn-primary btn-lg" style="background:#0084ff;">
                🔗 Tham gia nhóm Zalo ngay
            </a>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta-section">
    <div class="cta-card">
        <h2>Sẵn sàng trải nghiệm AI đỉnh cao?</h2>
        <p>Đăng ký ngay hôm nay để nhận credit miễn phí và khám phá sức mạnh của <?php echo $modelCount; ?>+ mô hình AI hàng đầu.</p>
        <?php if ($isLoggedIn): ?>
            <a href="index.php" class="btn btn-primary btn-lg">🚀 Vào chat ngay</a>
        <?php else: ?>
            <a href="register.php" class="btn btn-primary btn-lg">🎉 Đăng ký miễn phí</a>
        <?php endif; ?>
    </div>
</section>

<!-- FOOTER -->
<footer>
    <p>© <?php echo date('Y'); ?> <a href="home.php"><?php echo sanitize($siteName); ?></a>. All rights reserved.</p>
    <p style="margin-top:6px;">
        <?php if (!$isLoggedIn): ?>
            <a href="login.php">Đăng nhập</a> · <a href="register.php">Đăng ký</a> ·
        <?php endif; ?>
        <a href="#features">Tính năng</a> · <a href="#pricing">Bảng giá</a> · <a href="#community">Cộng đồng</a>
        <?php if ($isLoggedIn): ?> · <a href="dashboard.php">Dashboard</a><?php endif; ?>
    </p>
</footer>

<script>
// Navbar scroll effect
window.addEventListener('scroll', function() {
    document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});
</script>
</body>
</html>