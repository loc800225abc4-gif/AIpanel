<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

// Redirect non-logged-in users to landing page
if (!isLoggedIn()) {
    header('Location: home.php');
    exit;
}

$user = getUser();
$models = [];
$isLoggedIn = true;

try {
    $models = getActiveModels();
} catch (Exception $e) {
    $models = [];
}

$siteName = getSetting('site_name', 'LocNguyen AI');
$siteDesc = getSetting('site_description', 'Nền tảng AI thông minh - Đa dạng mô hình, Mạnh mẽ, Tin cậy');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo sanitize($siteName); ?> - Nền tảng AI Thông minh</title>
    <meta name="description" content="<?php echo sanitize($siteDesc); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🧠</text></svg>">
    <style>
        :root {
            --bg: #030712; --card: #0f172a; --card2: #1e293b;
            --border: #1e293b; --border-light: #334155;
            --text: #f1f5f9; --text2: #94a3b8; --text3: #64748b;
            --accent: #6366f1; --accent-light: #818cf8;
            --accent-glow: rgba(99,102,241,0.3);
            --green: #22c55e; --radius: 12px; --radius-lg: 16px;
            --sidebar-w: 280px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg); color: var(--text);
            min-height: 100vh; display: flex;
            position: relative; overflow: hidden;
        }
        a { text-decoration: none; color: inherit; }

        .sidebar {
            width: var(--sidebar-w); min-width: var(--sidebar-w);
            background: var(--card); border-right: 1px solid var(--border);
            display: flex; flex-direction: column; height: 100vh;
            position: relative; z-index: 10; transition: all 0.3s;
        }
        .sidebar-logo {
            padding: 20px; border-bottom: 1px solid var(--border);
            display: flex; align-items: center; gap: 12px;
        }
        .sidebar-logo .logo-icon {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            border-radius: 12px; display: flex;
            align-items: center; justify-content: center;
            font-size: 1.3rem; flex-shrink: 0;
            box-shadow: 0 4px 16px var(--accent-glow);
        }
        .sidebar-logo h2 {
            font-size: 1rem; font-weight: 700;
            background: linear-gradient(135deg, #fff, #a5b4fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .sidebar-models { flex: 1; overflow-y: auto; padding: 12px; }
        .sidebar-section { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text3); padding: 8px 8px 8px; }
        .model-item {
            display: flex; align-items: center; gap: 10px;
            padding: 10px 12px; border-radius: var(--radius);
            cursor: pointer; transition: all 0.2s;
            border: 1px solid transparent; margin-bottom: 2px; font-size: 0.9rem;
        }
        .model-item:hover { background: var(--card2); border-color: var(--border-light); }
        .model-item.active { background: rgba(99,102,241,0.1); border-color: rgba(99,102,241,0.3); }
        .model-icon { width: 34px; height: 34px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; flex-shrink: 0; }
        .model-icon.ds { background: rgba(59,130,246,0.2); } .model-icon.glm { background: rgba(34,197,94,0.2); }
        .model-icon.kimi { background: rgba(236,72,153,0.2); } .model-icon.qwen { background: rgba(245,158,11,0.2); }
        .model-icon.nem { background: rgba(34,197,94,0.2); } .model-icon.gpt { background: rgba(99,102,241,0.2); }
        .model-icon.llama { background: rgba(168,85,247,0.2); } .model-icon.gemma { background: rgba(239,68,68,0.2); }
        .model-icon.navi { background: rgba(14,165,233,0.2); }
        .model-info { flex: 1; min-width: 0; }
        .model-info .mn { font-size: 0.85rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .model-info .mp { font-size: 0.7rem; color: var(--text3); }

        .sidebar-footer { padding: 12px 16px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; }
        .sidebar-footer a { color: var(--text2); padding: 8px 12px; border-radius: 8px; transition: all 0.2s; display: flex; align-items: center; gap: 6px; }
        .sidebar-footer a:hover { background: var(--card2); color: var(--text); }
        .sidebar-footer .btn-login { background: linear-gradient(135deg, var(--accent), #7c3aed); color: #fff; padding: 8px 16px; border-radius: 8px; font-weight: 600; font-size: 0.85rem; }

        .main-area { flex: 1; display: flex; flex-direction: column; height: 100vh; position: relative; }
        .chat-header { padding: 14px 24px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; background: var(--card); flex-shrink: 0; }
        .chat-header .current-model { display: flex; align-items: center; gap: 10px; font-weight: 600; font-size: 1rem; }
        .chat-header .actions { display: flex; gap: 8px; }
        .chat-header .actions button { padding: 8px 12px; background: var(--card2); border: 1px solid var(--border-light); border-radius: 8px; color: var(--text2); cursor: pointer; font-size: 0.9rem; transition: all 0.2s; }
        .chat-header .actions button:hover { color: var(--text); border-color: var(--accent); }

        .chat-messages { flex: 1; overflow-y: auto; padding: 24px; display: flex; flex-direction: column; gap: 20px; }
        .message { display: flex; gap: 14px; animation: fadeIn 0.3s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        .msg-avatar { width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1rem; flex-shrink: 0; }
        .msg-avatar.user { background: linear-gradient(135deg, var(--accent), #7c3aed); }
        .msg-avatar.assistant { background: linear-gradient(135deg, #22c55e, #16a34a); }
        .msg-content { flex: 1; min-width: 0; }
        .msg-role { font-size: 0.75rem; font-weight: 600; color: var(--text2); margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
        .msg-text { font-size: 0.95rem; line-height: 1.7; word-break: break-word; white-space: pre-wrap; }

        /* Inline code */
        .msg-text code.inline-code {
            background: var(--card2); padding: 2px 6px; border-radius: 4px;
            font-size: 0.85rem; font-family: 'JetBrains Mono', 'Consolas', 'Monaco', monospace;
            border: 1px solid var(--border-light); white-space: normal; word-break: break-all;
        }
        /* Code Block Wrapper (ChatGPT-style) */
        .code-block-wrapper {
            margin: 12px 0; border-radius: 10px; overflow: hidden;
            background: #0d1117; border: 1px solid #30363d;
        }
        .code-block-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 8px 14px; background: #161b22; border-bottom: 1px solid #30363d;
            font-size: 0.75rem;
        }
        .code-block-header .lang-label {
            color: #8b949e; font-weight: 500; text-transform: lowercase;
        }
        .code-block-header .copy-btn {
            background: #21262d; border: 1px solid #30363d; color: #c9d1d9;
            padding: 4px 12px; border-radius: 6px; cursor: pointer; font-size: 0.72rem;
            font-family: 'Inter', sans-serif; transition: all 0.15s;
            display: flex; align-items: center; gap: 4px; user-select: none;
        }
        .code-block-header .copy-btn:hover { background: #30363d; color: #fff; }
        .code-block-header .copy-btn.copied { background: #1a3a2a; border-color: #2ea043; color: #2ea043; }
        .code-block-body { padding: 14px 16px; overflow-x: auto; }
        .code-block-body pre {
            margin: 0; padding: 0; background: none; border: none; border-radius: 0;
            font-size: 0.82rem; line-height: 1.65;
            font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', 'Monaco', monospace;
        }
        .code-block-body pre code {
            background: none; border: none; padding: 0; font-size: inherit; color: #c9d1d9;
        }

        /* Syntax Highlighting (GitHub Dark theme colors) */
        .syn-kw { color: #ff7b72; }       /* keywords: if, else, for, while, def, function, etc. */
        .syn-str { color: #a5d6ff; }      /* strings */
        .syn-com { color: #8b949e; font-style: italic; } /* comments */
        .syn-num { color: #79c0ff; }      /* numbers */
        .syn-fn { color: #d2a8ff; }       /* function names */
        .syn-op { color: #ff7b72; }       /* operators */
        .syn-type { color: #ffa657; }     /* types */
        .syn-builtin { color: #d2a8ff; }  /* builtins */

        .welcome-screen { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 40px; }
        .welcome-screen h2 { font-size: 2rem; font-weight: 800; background: linear-gradient(135deg, #fff, #a5b4fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-bottom: 8px; }
        .welcome-screen p { color: var(--text3); font-size: 1rem; max-width: 500px; line-height: 1.6; }
        .welcome-features { display: flex; gap: 16px; margin-top: 32px; flex-wrap: wrap; justify-content: center; }
        .welcome-features .feat { background: var(--card); border: 1px solid var(--border); padding: 16px 20px; border-radius: var(--radius); font-size: 0.85rem; color: var(--text2); display: flex; align-items: center; gap: 8px; }
        .welcome-features .feat i { color: var(--accent-light); }

        .chat-input-area { padding: 16px 24px 20px; border-top: 1px solid var(--border); background: var(--card); flex-shrink: 0; }
        .input-wrapper { display: flex; align-items: flex-end; gap: 10px; background: var(--card2); border: 1px solid var(--border-light); border-radius: var(--radius-lg); padding: 8px 10px; transition: all 0.3s; }
        .input-wrapper:focus-within { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(99,102,241,0.1); }
        .input-wrapper textarea { flex: 1; background: none; border: none; color: var(--text); font-family: 'Inter', sans-serif; font-size: 0.95rem; resize: none; padding: 8px; max-height: 160px; line-height: 1.5; }
        .input-wrapper textarea::placeholder { color: var(--text3); }
        .input-wrapper textarea:focus { outline: none; }
        .send-btn { width: 42px; height: 42px; border-radius: var(--radius); background: linear-gradient(135deg, var(--accent), #7c3aed); border: none; color: #fff; cursor: pointer; font-size: 1rem; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: all 0.2s; box-shadow: 0 4px 12px var(--accent-glow); }
        .send-btn:hover { transform: scale(1.05); }
        .send-btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }
        .info-bar { display: flex; justify-content: space-between; padding: 6px 4px 0; font-size: 0.75rem; color: var(--text3); }

        .landing-page { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; padding: 40px; text-align: center; position: relative; }
        .bg-grid { position: fixed; inset: 0; background-image: linear-gradient(rgba(99,102,241,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.04) 1px, transparent 1px); background-size: 80px 80px; pointer-events: none; z-index: 0; }
        .bg-orb { position: fixed; border-radius: 50%; filter: blur(150px); pointer-events: none; z-index: 0; }
        .bg-orb-1 { width: 600px; height: 600px; background: rgba(99,102,241,0.1); top: -200px; right: -200px; }
        .bg-orb-2 { width: 500px; height: 500px; background: rgba(129,140,248,0.06); bottom: -200px; left: -150px; }
        .landing-content { position: relative; z-index: 1; max-width: 650px; }
        .landing-badge { display: inline-flex; align-items: center; gap: 6px; background: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.3); padding: 6px 16px; border-radius: 50px; font-size: 0.8rem; color: var(--accent-light); margin-bottom: 24px; }
        .landing-content h1 { font-size: 3.2rem; font-weight: 900; line-height: 1.15; margin-bottom: 16px; background: linear-gradient(135deg, #fff 0%, #a5b4fc 50%, #818cf8 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .landing-content .subtitle { font-size: 1.1rem; color: var(--text2); line-height: 1.6; margin-bottom: 36px; max-width: 500px; margin-left: auto; margin-right: auto; }
        .landing-btns { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }
        .btn { padding: 14px 28px; border-radius: var(--radius); font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s; display: inline-flex; align-items: center; gap: 8px; font-family: 'Inter', sans-serif; }
        .btn-primary { background: linear-gradient(135deg, var(--accent), #7c3aed); color: #fff; border: none; box-shadow: 0 4px 24px var(--accent-glow); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 32px var(--accent-glow); }
        .btn-outline { background: transparent; border: 1px solid var(--border-light); color: var(--text); text-decoration: none; }
        .btn-outline:hover { border-color: var(--accent); background: rgba(99,102,241,0.05); }
        .landing-stats { display: flex; gap: 40px; margin-top: 48px; justify-content: center; }
        .stat { text-align: center; }
        .stat-num { font-size: 2rem; font-weight: 800; background: linear-gradient(135deg, #fff, #a5b4fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .stat-label { font-size: 0.8rem; color: var(--text3); margin-top: 4px; }

        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border-light); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--text3); }

        @media (max-width: 768px) {
            .sidebar { width: 100%; min-width: 100%; height: auto; max-height: 45vh; border-right: none; border-bottom: 1px solid var(--border); }
            body { flex-direction: column; overflow: auto; }
            .main-area { height: auto; min-height: 55vh; }
            .chat-messages { padding: 12px; gap: 12px; }
            .chat-header { padding: 10px 14px; }
            .chat-input-area { padding: 10px 14px 14px; }
            .sidebar-logo { padding: 12px 16px; }
            .sidebar-logo h2 { font-size: 0.9rem; }
            .sidebar-models { max-height: 180px; }
            .model-item { padding: 8px 10px; font-size: 0.8rem; }
            .model-icon { width: 28px; height: 28px; font-size: 0.7rem; border-radius: 8px; }
            .msg-avatar { width: 30px; height: 30px; font-size: 0.85rem; }
            .msg-text { font-size: 0.85rem; }
            .welcome-screen h2 { font-size: 1.3rem; }
            .landing-content h1 { font-size: 2rem; }
            .landing-content .subtitle { font-size: 0.9rem; }
            .landing-stats { gap: 20px; }
            .stat-num { font-size: 1.4rem; }
        }
        @media (max-width: 480px) {
            .sidebar-footer { font-size: 0.75rem; padding: 8px 12px; }
            .sidebar-footer .btn-login { padding: 6px 12px; font-size: 0.75rem; }
            .chat-header .current-model { font-size: 0.85rem; }
            .input-wrapper { padding: 6px 8px; }
            .input-wrapper textarea { font-size: 0.85rem; }
            .send-btn { width: 36px; height: 36px; }
            .model-info .mn { font-size: 0.75rem; }
            .landing-content h1 { font-size: 1.6rem; }
            .btn { padding: 10px 20px; font-size: 0.9rem; }
        }

        .typing-indicator { display: flex; gap: 4px; padding: 8px 0; }
        .typing-indicator span { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); animation: bounce 1.4s infinite; }
        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes bounce { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-8px); } }
    </style>
</head>
<body>
<?php
// Get user's API key for frontend to talk directly to AI Gateway (port 8000)
$userApiKey = '';
$gatewayUrl = 'http://localhost:8000';
if ($isLoggedIn && $user) {
    $db = getDB();
    if ($db) {
        $keyRes = $db->query("SELECT api_key FROM api_keys WHERE user_id = {$user['id']} AND is_locked = 0 ORDER BY id DESC LIMIT 1");
        if ($keyRes && $row = $keyRes->fetch_assoc()) {
            $userApiKey = $row['api_key'];
        }
    }
}
// Load gateway URL from .env
if (file_exists(__DIR__ . '/../.env')) {
    foreach (file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, 'GATEWAY_URL=') === 0) {
            $gatewayUrl = rtrim(trim(explode('=', $line, 2)[1]), '/');
            break;
        }
    }
}
// Fallback: auto-detect from SITE_URL (replace port 8080 → 8000)
if ($gatewayUrl === 'http://localhost:8000' && defined('SITE_URL') && SITE_URL) {
    $parsed = parse_url(SITE_URL);
    if ($parsed && isset($parsed['host'])) {
        $scheme = $parsed['scheme'] ?? 'http';
        $host = $parsed['host'];
        $port = isset($parsed['port']) && $parsed['port'] != '8080' ? $parsed['port'] : '8000';
        $gatewayUrl = "{$scheme}://{$host}:{$port}";
    }
}
?>
    <script>
    window.APP = {
        isLoggedIn: <?php echo $isLoggedIn ? 'true' : 'false'; ?>,
        siteName: <?php echo json_encode($siteName); ?>,
        models: <?php echo json_encode($models); ?>,
        apiBase: <?php echo json_encode(SITE_URL . '/api'); ?>,
        gatewayUrl: <?php echo json_encode($gatewayUrl); ?>,
        apiKey: <?php echo json_encode($userApiKey); ?>,
        sessionId: '<?php echo generateUUID(); ?>',
        activeModel: null
    };
    if (window.APP.models.length > 0) { window.APP.activeModel = window.APP.models[0]; }
    </script>

    <?php if (!$isLoggedIn): ?>
    <div class="bg-grid"></div>
    <div class="bg-orb bg-orb-1"></div>
    <div class="bg-orb bg-orb-2"></div>
    <div class="landing-page" id="landingPage">
        <div class="landing-content">
            <div class="landing-badge"><span>✨</span> <?php echo sanitize($siteDesc); ?></div>
            <h1><?php echo sanitize($siteName); ?></h1>
            <p class="subtitle">Trải nghiệm sức mạnh AI với nhiều mô hình hàng đầu - Chat thông minh, phân tích, và sáng tạo không giới hạn.</p>
            <div class="landing-btns">
                <a href="register.php" class="btn btn-primary"><i class="fas fa-rocket"></i> Bắt đầu miễn phí</a>
                <a href="login.php" class="btn btn-outline"><i class="fas fa-sign-in-alt"></i> Đăng nhập</a>
            </div>
            <div class="landing-stats">
                <?php $modelCount = count($models); ?>
                <div class="stat"><div class="stat-num"><?php echo $modelCount ?: 21; ?>+</div><div class="stat-label">Mô hình AI</div></div>
                <div class="stat"><div class="stat-num">10K</div><div class="stat-label">Credits miễn phí</div></div>
                <div class="stat"><div class="stat-num">1ms</div><div class="stat-label">Phản hồi nhanh</div></div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-logo"><div class="logo-icon">🧠</div><h2><?php echo sanitize($siteName); ?></h2></div>
        <div class="sidebar-models" id="sidebarModels">
            <div class="sidebar-section">🗨️ Chat History</div>
            <div id="sessionsList" style="max-height:200px;overflow-y:auto;padding:0 4px;">
                <div style="padding:8px;color:var(--text3);font-size:0.8rem;text-align:center;">Loading...</div>
            </div>
            <div class="sidebar-section" style="margin-top:12px;">🤖 Models</div>
        </div>
        <div class="sidebar-footer">
            <span style="color:var(--text3);" id="creditsDisplay">💎 <?php echo formatNumber($user['credits'] ?? 0); ?> credits</span>
            <a href="dashboard.php" title="Dashboard"><i class="fas fa-user"></i></a>
        </div>
    </div>

    <!-- MAIN CHAT -->
    <div class="main-area">
        <div class="chat-header">
            <div class="current-model" id="currentModelDisplay"><span>🤖</span><span id="modelName">Chọn model</span></div>
            <div class="actions"><button onclick="clearChat()" title="New chat"><i class="fas fa-plus"></i> Mới</button></div>
        </div>
        <div class="chat-messages" id="chatMessages">
            <div class="welcome-screen" id="welcomeScreen">
                <h2>Chào mừng, <?php echo sanitize($user['full_name'] ?: $user['username']); ?>!</h2>
                <p>Chọn một model AI bên trái và bắt đầu chat</p>
                <div class="welcome-features">
                    <div class="feat"><i class="fas fa-bolt"></i> Phản hồi nhanh</div>
                    <div class="feat"><i class="fas fa-brain"></i> Multi-model</div>
                    <div class="feat"><i class="fas fa-shield-halting"></i> Bảo mật</div>
                </div>
            </div>
        </div>

        <div class="chat-input-area" id="chatInputArea"
             ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event)">
            <div class="input-wrapper">
                <button id="imageBtn" onclick="document.getElementById('imageInput').click()" style="width:40px;height:40px;background:var(--card);border:1px solid var(--border-light);border-radius:10px;color:var(--text2);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;" title="Đính kèm ảnh / Upload file">📎</button>
                <input type="file" id="imageInput" accept="image/*,application/pdf,text/*,application/json,application/xml,text/xml,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,.py,.js,.php,.sql,.sh,.bat,.yml,.yaml,.log,.md,.ini,.cfg,.conf" style="display:none;" onchange="handleFileSelect(event)" multiple>
                <textarea id="chatInput" rows="1" placeholder="Nhập tin nhắn hoặc kéo thả file vào đây..." onkeydown="handleKeyDown(event)"></textarea>
                <button class="send-btn" id="sendBtn" onclick="sendMessage()" disabled><i class="fas fa-paper-plane"></i></button>
            </div>
            <div id="filePreview" style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap;"></div>
            <div class="info-bar">
                <span id="modelInfo">Chọn model để bắt đầu</span>
                <span>LocNguyen AI</span>
            </div>
        </div>
    </div>

    <script>
    const chatMessages = document.getElementById('chatMessages');
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const welcomeScreen = document.getElementById('welcomeScreen');
    const modelName = document.getElementById('modelName');
    const modelInfo = document.getElementById('modelInfo');
    const sidebarModels = document.getElementById('sidebarModels');
    let isProcessing = false;
    let pendingImages = [];
    let pendingFiles = []; // { id, url, uploading, name, type, content, original_name, is_image }

    // ============ MARKDOWN PARSER ============
    // Tokenizer-based syntax highlighting: walks code char-by-char, builds token array,
    // then generates HTML using DOM API. This completely avoids HTML injection/escaping issues.

    const KEYWORDS = new Set([
        'function','def','class','return','if','else','elif','for','while','do',
        'switch','case','break','continue','try','catch','finally','throw',
        'new','delete','typeof','instanceof','var','let','const','export',
        'import','from','async','await','yield','this','super','extends',
        'implements','interface','enum','public','private','protected','static',
        'final','abstract','void','true','false','null','undefined',
        'None','True','False','and','or','not','in','is','as','with','raise',
        'except','print','echo','self','namespace','use','include','require','global'
    ]);
    const BUILTINS = new Set([
        'console','document','window','Array','Object','String','Number','Math',
        'Date','JSON','Promise','fetch','setTimeout','setInterval','parseInt',
        'parseFloat','isNaN','map','filter','reduce','forEach','push','pop','shift',
        'unshift','splice','slice','split','join','replace','match','toLowerCase',
        'toUpperCase','trim','log','error','warn','info','abs','ceil','floor',
        'round','random','max','min','pow','sqrt','str','int','list','dict','set',
        'tuple','bool','len','range','enumerate','zip','type','open','read','write',
        'append','close','input','format','order_by','group_by','limit','where',
        'join','select','insert','update','delete','create','alter','drop','count',
        'sum','avg','like','between'
    ]);
    const TYPES = new Set([
        'int','float','double','long','short','byte','char','string','String',
        'bool','boolean','void','Object','Array','number','any','never','unknown',
        'Promise','Observable','HttpClient','Component','Injectable','Module',
        'interface','type','enum','class','struct','union'
    ]);
    const CS_LIKE = new Set(['js','javascript','ts','typescript','java','c','cpp','c++','csharp','c#','php','go','rust','swift','kotlin','scala','dart','css','scss','less']);
    const SCRIPT_LIKE = new Set(['sh','bash','shell','zsh','bat','cmd','powershell','ps1']);

    function highlightSyntax(code, lang) {
        const tokens = tokenize(code, (lang || '').toLowerCase());
        // Build HTML safely using DOM
        const div = document.createElement('div');
        for (const tok of tokens) {
            if (tok.cls) {
                const span = document.createElement('span');
                span.className = tok.cls;
                span.textContent = tok.text;
                div.appendChild(span);
            } else {
                div.appendChild(document.createTextNode(tok.text));
            }
        }
        return div.innerHTML;
    }

    function tokenize(code, lang) {
        const len = code.length;
        const tokens = [];
        let i = 0;

        function raw(s) { if (s.length > 0) tokens.push({ text: s }); }
        function hl(s, cls) { tokens.push({ text: s, cls: cls }); }

        while (i < len) {
            // --- Block comments /* ... */ (C-like languages)
            if (code[i] === '/' && code[i+1] === '*') {
                const end = code.indexOf('*/', i+2);
                if (end !== -1) {
                    hl(code.substring(i, end+2), 'syn-com');
                    i = end + 2;
                    continue;
                }
            }
            // --- Line comments // (C-like)
            if (code[i] === '/' && code[i+1] === '/') {
                let j = i+2;
                while (j < len && code[j] !== '\n') j++;
                hl(code.substring(i, j), 'syn-com');
                i = j;
                continue;
            }
            // --- # comments (Python, shell, ruby, yaml, etc.)
            if (code[i] === '#') {
                const isCommentLang = (lang === 'python' || lang === 'py' ||
                    lang === 'rb' || lang === 'ruby' || lang === 'pl' || lang === 'perl' ||
                    lang === 'yml' || lang === 'yaml' || lang === 'conf' || lang === 'ini' ||
                    lang === 'cfg' || SCRIPT_LIKE.has(lang));
                // For unknown langs, treat # as comment too
                if (isCommentLang || lang === '' ||
                    (!CS_LIKE.has(lang) && lang !== 'sql' && lang !== 'html' && lang !== 'xml' && lang !== 'svg' && lang !== 'json' && lang !== 'css')) {
                    let j = i+1;
                    while (j < len && code[j] !== '\n') j++;
                    hl(code.substring(i, j), 'syn-com');
                    i = j;
                    continue;
                }
            }
            // --- SQL comments --
            if (code[i] === '-' && code[i+1] === '-' && lang === 'sql') {
                let j = i+2;
                while (j < len && code[j] !== '\n') j++;
                hl(code.substring(i, j), 'syn-com');
                i = j;
                continue;
            }
            // --- HTML comments <!-- ... -->
            if (code.substr(i, 4) === '<!--') {
                const end = code.indexOf('-->', i+4);
                if (end !== -1) {
                    hl(code.substring(i, end+3), 'syn-com');
                    i = end + 3;
                    continue;
                }
            }

            // --- Python triple-quoted strings (can be docstrings, which are like comments)
            if (lang === 'python' || lang === 'py') {
                if (code.substr(i, 3) === '"""' || code.substr(i, 3) === "'''") {
                    const triple = code.substr(i, 3);
                    const end = code.indexOf(triple, i+3);
                    if (end !== -1) {
                        hl(code.substring(i, end+3), 'syn-str');
                        i = end + 3;
                        continue;
                    }
                }
            }

            // --- Regular strings
            if (code[i] === '"' || code[i] === "'" || code[i] === '`') {
                const quote = code[i];
                let j = i + 1;
                while (j < len) {
                    if (code[j] === '\\') { j += 2; continue; }
                    if (code[j] === quote) { j++; break; }
                    j++;
                }
                if (j <= len) {
                    hl(code.substring(i, j), 'syn-str');
                    i = j;
                    continue;
                }
            }

            // --- Numbers (standalone, not part of identifier)
            if (/[0-9]/.test(code[i]) && (i === 0 || !/[a-zA-Z0-9_$]/.test(code[i-1]))) {
                let j = i;
                if (code.substr(i, 2) === '0x' || code.substr(i, 2) === '0X') j += 2;
                while (j < len && /[0-9a-fA-F.xX]/.test(code[j])) j++;
                const num = code.substring(i, j);
                // Ensure it ends with a digit (not just a dot)
                if (j > i && /[0-9]/.test(code[j-1])) {
                    hl(num, 'syn-num');
                    i = j;
                    continue;
                }
            }

            // --- Identifiers / Keywords / Builtins / Types
            if (/[a-zA-Z_$]/.test(code[i])) {
                let j = i;
                while (j < len && /[a-zA-Z0-9_$]/.test(code[j])) j++;
                const word = code.substring(i, j);

                // Check if followed by (
                let k = j;
                while (k < len && (code[k] === ' ' || code[k] === '\t')) k++;
                const isFuncCall = (k < len && code[k] === '(');

                if (KEYWORDS.has(word)) {
                    hl(word, 'syn-kw');
                } else if (TYPES.has(word) && !isFuncCall) {
                    hl(word, 'syn-type');
                } else if (BUILTINS.has(word)) {
                    hl(word, 'syn-builtin');
                } else if (isFuncCall) {
                    hl(word, 'syn-fn');
                } else {
                    raw(word);
                }
                i = j;
                continue;
            }

            // --- Accumulate other characters until next interesting token
            let j = i;
            while (j < len && !/[a-zA-Z0-9_$"'`#\/<\-]/.test(code[j]) &&
                   !(code[j] === '-' && code[j+1] === '-')) {
                j++;
            }
            if (j > i) {
                raw(code.substring(i, j));
                i = j;
                continue;
            }

            // Fallback: single character
            raw(code[i]);
            i++;
        }
        return tokens;
    }

    function parseMarkdown(text) {
        if (!text) return '';
        // Use DOM for safe HTML escaping
        function esc(str) {
            const d = document.createElement('div');
            d.textContent = str;
            return d.innerHTML;
        }
        let result = '';
        let i = 0;
        const len = text.length;

        while (i < len) {
            // Code block ```
            if (text.substr(i, 3) === '```' && (i === 0 || text[i-1] === '\n' || text[i-1] === '\r')) {
                const blockStart = i + 3;
                let lang = '';
                let j = blockStart;
                while (j < len && text[j] !== '\n' && text[j] !== '\r') { lang += text[j]; j++; }
                if (text[j] === '\r') j++;
                if (text[j] === '\n') j++;
                const endIdx = text.indexOf('```', j);
                if (endIdx !== -1) {
                    const code = text.substring(j, endIdx);
                    const codeTrimmed = code.endsWith('\n') ? code.slice(0, -1) : code;
                    const highlighted = highlightSyntax(codeTrimmed, lang.trim());
                    const codeBase64 = btoa(unescape(encodeURIComponent(codeTrimmed)));
                    result += '<div class="code-block-wrapper">';
                    result += '<div class="code-block-header">';
                    result += '<span class="lang-label">' + esc(lang.trim() || 'code') + '</span>';
                    result += '<button class="copy-btn" onclick="copyCode(this)" data-code-b64="' + codeBase64 + '">📋 Copy</button>';
                    result += '</div>';
                    result += '<div class="code-block-body"><pre><code>' + highlighted + '</code></pre></div>';
                    result += '</div>';
                    i = endIdx + 3;
                    continue;
                }
            }
            // Inline code
            if (text[i] === '`') {
                const end = text.indexOf('`', i + 1);
                if (end !== -1) {
                    result += '<code class="inline-code">' + esc(text.substring(i + 1, end)) + '</code>';
                    i = end + 1;
                    continue;
                }
            }
            // Bold
            if (text.substr(i, 2) === '**') {
                const end = text.indexOf('**', i + 2);
                if (end !== -1) {
                    result += '<strong>' + parseMarkdown(text.substring(i + 2, end)) + '</strong>';
                    i = end + 2;
                    continue;
                }
            }
            // Italic
            if (text[i] === '*' && text[i+1] !== '*') {
                const end = text.indexOf('*', i + 1);
                if (end !== -1) {
                    result += '<em>' + parseMarkdown(text.substring(i + 1, end)) + '</em>';
                    i = end + 1;
                    continue;
                }
            }
            result += esc(text[i]);
            i++;
        }
        return result;
    }

    function escapeHtmlChar(ch) {
        if (ch === '&') return '&';
        if (ch === '<') return '<';
        if (ch === '>') return '>';
        return ch;
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function copyCode(btn) {
        const codeB64 = btn.getAttribute('data-code-b64');
        let code;
        try {
            code = decodeURIComponent(escape(atob(codeB64)));
        } catch(e) {
            code = btn.getAttribute('data-code') || '';
        }
        navigator.clipboard.writeText(code).then(() => {
            btn.classList.add('copied');
            btn.innerHTML = '✓ Copied!';
            setTimeout(() => {
                btn.classList.remove('copied');
                btn.innerHTML = '📋 Copy';
            }, 2000);
        }).catch(() => {
            // Fallback
            const textarea = document.createElement('textarea');
            textarea.value = code; textarea.style.position = 'fixed'; textarea.style.opacity = '0';
            document.body.appendChild(textarea); textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            btn.classList.add('copied');
            btn.innerHTML = '✓ Copied!';
            setTimeout(() => {
                btn.classList.remove('copied');
                btn.innerHTML = '📋 Copy';
            }, 2000);
        });
    }

    // ============ DRAG & DROP + FILE HANDLING ============
    function handleDragOver(e) {
        e.preventDefault(); e.stopPropagation();
        document.getElementById('chatInputArea').style.boxShadow = '0 0 0 2px var(--accent)';
    }
    function handleDragLeave(e) {
        document.getElementById('chatInputArea').style.boxShadow = '';
    }
    function handleDrop(e) {
        e.preventDefault(); e.stopPropagation();
        document.getElementById('chatInputArea').style.boxShadow = '';
        if (e.dataTransfer.files.length > 0) { uploadFiles(e.dataTransfer.files); }
    }
    function handleFileSelect(event) {
        const files = event.target.files;
        if (files.length === 0) return;
        uploadFiles(files);
        event.target.value = '';
    }

    async function uploadFiles(files) {
        for (const file of files) {
            const isImg = file.type.startsWith('image/');
            const validImage = isImg && ['image/jpeg','image/png','image/gif','image/webp'].includes(file.type);
            const maxSize = isImg ? 10 * 1024 * 1024 : 20 * 1024 * 1024;
            if (file.size > maxSize) { alert('File ' + file.name + ' quá lớn. Tối đa ' + (maxSize/1024/1024) + 'MB.'); continue; }
            const placeholderId = 'file-placeholder-' + Date.now() + '-' + Math.random().toString(36).substr(2,5);
            if (validImage) {
                pendingImages.push({ id: placeholderId, url: '', uploading: true });
            } else {
                pendingFiles.push({ id: placeholderId, url: '', uploading: true, name: file.name, type: file.type, content: '', is_image: false });
            }
            renderPreviews();

            const formData = new FormData();
            formData.append('file', file);
            try {
                const resp = await fetch(window.APP.apiBase + '/upload.php', { method: 'POST', body: formData });
                const data = await resp.json();
                if (data.success) {
                    if (data.is_image) {
                        const img = pendingImages.find(p => p.id === placeholderId);
                        if (img) { img.url = data.url; img.uploading = false; }
                    } else {
                        const f = pendingFiles.find(p => p.id === placeholderId);
                        if (f) { f.url = data.url; f.uploading = false; f.content = data.content_preview || ''; f.content_length = data.content_length || 0; f.original_name = data.original_name; }
                    }
                } else {
                    pendingImages = pendingImages.filter(p => p.id !== placeholderId);
                    pendingFiles = pendingFiles.filter(p => p.id !== placeholderId);
                    alert('Lỗi upload: ' + (data.error || 'Unknown'));
                }
            } catch (e) {
                pendingImages = pendingImages.filter(p => p.id !== placeholderId);
                pendingFiles = pendingFiles.filter(p => p.id !== placeholderId);
                alert('Lỗi kết nối khi upload');
            }
            renderPreviews();
        }
    }

    function renderPreviews() {
        const container = document.getElementById('filePreview');
        if (!container) return;
        let html = '';
        pendingImages.forEach(img => {
            html += `<div style="position:relative;display:inline-block;border-radius:8px;overflow:hidden;width:60px;height:60px;border:1px solid var(--border-light);">
                ${img.uploading ? '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--card2);"><div class="typing-indicator"><span></span><span></span><span></span></div></div>' : '<img src="' + img.url + '" style="width:100%;height:100%;object-fit:cover;">'}
                <button onclick="removeFileById(\'' + img.id + '\')" style="position:absolute;top:2px;right:2px;width:18px;height:18px;background:rgba(0,0,0,0.7);border:none;border-radius:50%;color:#fff;font-size:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;">✕</button>
            </div>`;
        });
        pendingFiles.forEach(f => {
            html += `<div style="position:relative;display:inline-flex;align-items:center;gap:6px;border-radius:8px;padding:8px 12px;background:var(--card2);border:1px solid var(--border-light);font-size:0.75rem;max-width:200px;">
                ${f.uploading ? '<div class="typing-indicator"><span></span><span></span><span></span></div>' : '<span style="font-size:1.2rem;">' + getFileIcon(f.type, f.name) + '</span>'}
                <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text2);">${escapeHtml(f.name)}</span>
                ${f.content_length ? '<span style="color:var(--text3);">' + formatFileSize(f.content_length) + '</span>' : ''}
                <button onclick="removeFileById(\'${f.id}\')" style="background:none;border:none;color:var(--red);cursor:pointer;font-size:12px;padding:0;">✕</button>
            </div>`;
        });
        container.innerHTML = html;
    }

    function getFileIcon(type, name) {
        if (type === 'application/pdf') return '📄';
        if (type.includes('word') || /\.docx?$/.test(name)) return '📝';
        if (type.includes('excel') || type.includes('spreadsheet') || /\.xlsx?$/.test(name)) return '📊';
        if (type === 'application/json') return '📋';
        if (type.includes('xml')) return '📰';
        if (/\.py$/.test(name)) return '🐍';
        if (/\.js$/.test(name)) return '📜';
        if (/\.php$/.test(name)) return '🐘';
        if (/\.sql$/.test(name)) return '🗄️';
        if (type === 'text/csv') return '📊';
        if (/\.md$/.test(name)) return '📖';
        return '📁';
    }

    function formatFileSize(bytes) {
        if (bytes < 1024) return bytes + 'B';
        if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + 'KB';
        return (bytes/(1024*1024)).toFixed(1) + 'MB';
    }

    function removeFileById(id) {
        pendingImages = pendingImages.filter(p => p.id !== id);
        pendingFiles = pendingFiles.filter(p => p.id !== id);
        renderPreviews();
    }

    // ============ SIDEBAR ============
    function buildSidebar() {
        const models = window.APP.models;
        if (models.length === 0) {
            sidebarModels.insertAdjacentHTML('beforeend', '<div style="padding:16px;color:var(--text3);font-size:0.85rem;">Chưa có models. Vào admin panel để thêm.</div>');
            return;
        }
        let html = '';
        models.forEach((m, i) => {
            const pClass = getProviderClass(m.provider);
            html += `<div class="model-item ${i === 0 ? 'active' : ''}" onclick="selectModel(${i})" data-idx="${i}">
                <div class="model-icon ${pClass}">${getProviderIcon(m.provider)}</div>
                <div class="model-info"><div class="mn">${escapeHtml(m.name)}</div><div class="mp">${m.max_tokens ? (m.max_tokens/1024).toFixed(0) + 'K tokens' : ''}</div></div>
            </div>`;
        });
        sidebarModels.insertAdjacentHTML('beforeend', html);
        if (models.length > 0) { selectModel(0); }
    }

    function getProviderClass(p) {
        const map = { deepseek:'ds', zhipu:'glm', moonshot:'kimi', alibaba:'qwen', nvidia:'nem', openai:'gpt', meta:'llama', google:'gemma', navigator:'navi' };
        return map[p] || 'ds';
    }
    function getProviderIcon(p) {
        const map = { deepseek:'🔷', zhipu:'🟢', moonshot:'🌙', alibaba:'🟠', nvidia:'🟩', openai:'🟣', meta:'🔮', google:'🔴', navigator:'🧭' };
        return map[p] || '🤖';
    }

    function selectModel(idx) {
        window.APP.activeModel = window.APP.models[idx];
        document.querySelectorAll('.model-item').forEach(el => el.classList.remove('active'));
        document.querySelector('.model-item[data-idx="' + idx + '"]')?.classList.add('active');
        modelName.textContent = window.APP.activeModel.name;
        modelInfo.textContent = window.APP.activeModel.model_id + ' | ' + window.APP.activeModel.provider;
        sendBtn.disabled = false;
        chatInput.focus();
    }

    function handleKeyDown(e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    }

    chatInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 160) + 'px';
    });

    function appendMessage(role, content, skipMarkdown) {
        const div = document.createElement('div');
        div.className = 'message';
        const parsedContent = skipMarkdown ? escapeHtml(content) : parseMarkdown(content);
        div.innerHTML = `<div class="msg-avatar ${role}">${role === 'user' ? '👤' : '🤖'}</div><div class="msg-content"><div class="msg-role">${role === 'user' ? 'Bạn' : 'AI'}</div><div class="msg-text">${parsedContent}</div></div>`;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function appendLoading() {
        const id = 'loading-' + Date.now();
        const div = document.createElement('div');
        div.id = id; div.className = 'message';
        div.innerHTML = `<div class="msg-avatar assistant">🤖</div><div class="msg-content"><div class="msg-role">AI</div><div class="typing-indicator"><span></span><span></span><span></span></div></div>`;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return id;
    }

    function removeLoading(id) { document.getElementById(id)?.remove(); }

    function appendStreamingMessage() {
        const id = 'stream-' + Date.now();
        const div = document.createElement('div');
        div.id = id; div.className = 'message';
        div.innerHTML = `<div class="msg-avatar assistant">🤖</div><div class="msg-content"><div class="msg-role">AI</div><div class="msg-text" id="${id}-text" data-raw=""></div></div>`;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return id;
    }

    function appendDelta(id, text) {
        const textEl = document.getElementById(id + '-text');
        if (textEl) {
            const currentRaw = textEl.getAttribute('data-raw') || '';
            const newRaw = currentRaw + text;
            textEl.setAttribute('data-raw', newRaw);
            // During streaming, show raw text (escaped) to avoid malformed HTML
            textEl.innerHTML = escapeHtml(newRaw);
        }
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function finishStreaming(id, isError, errorText, credits) {
        const msgEl = document.getElementById(id);
        if (msgEl) {
            const indicator = msgEl.querySelector('.typing-indicator');
            if (indicator) indicator.remove();
            const textEl = document.getElementById(id + '-text');
            if (textEl) {
                if (errorText) {
                    textEl.textContent = '❌ ' + errorText;
                    textEl.setAttribute('data-raw', '');
                } else {
                    // Parse markdown now that streaming is done
                    const raw = textEl.getAttribute('data-raw') || textEl.textContent || '';
                    textEl.innerHTML = parseMarkdown(raw);
                    textEl.setAttribute('data-raw', '');
                }
            }
        }
        if (credits !== undefined && credits !== null) { updateCredits(credits); }
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function clearChat() {
        chatMessages.innerHTML = '';
        const welcome = document.createElement('div');
        welcome.className = 'welcome-screen'; welcome.id = 'welcomeScreen';
        welcome.innerHTML = '<h2>Chào mừng!</h2><p>Bắt đầu chat với AI</p>';
        chatMessages.appendChild(welcome);
        window.APP.sessionId = '<?php echo generateUUID(); ?>';
        loadSessions();
    }

    // ============ HISTORY / SESSIONS ============
    async function loadSessions() {
        try {
            const resp = await fetch(window.APP.apiBase + '/history.php?list=sessions');
            const data = await resp.json();
            if (data.sessions) { renderSessions(data.sessions); }
        } catch (e) { console.error('Failed to load sessions:', e); }
    }

    function renderSessions(sessions) {
        const container = document.getElementById('sessionsList');
        if (!container) return;
        if (sessions.length === 0) {
            container.innerHTML = '<div style="padding:8px;color:var(--text3);font-size:0.8rem;text-align:center;">Chưa có chat nào</div>';
            return;
        }
        container.innerHTML = sessions.map(s => {
            const preview = (s.last_message || '').substring(0, 40);
            const date = new Date(s.last_at);
            const time = date.toLocaleDateString('vi-VN', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
            const isActive = s.session_id === window.APP.sessionId;
            return `<div class="session-item" onclick="openSession('${s.session_id}')" style="padding:8px 10px;cursor:pointer;border-radius:8px;margin-bottom:2px;font-size:0.8rem;transition:all 0.2s;border:1px solid transparent;${isActive ? 'background:rgba(99,102,241,0.1);border-color:rgba(99,102,241,0.3);' : ''}" onmouseover="this.style.background='var(--card2)'" onmouseout="this.style.background='${isActive ? 'rgba(99,102,241,0.1)' : 'transparent'}'">
                <div style="color:var(--text2);font-weight:500;line-height:1.3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(preview || 'Tin nhắn mới...')}</div>
                <div style="color:var(--text3);font-size:0.7rem;margin-top:2px;">${time} · ${s.message_count} tin</div>
            </div>`;
        }).join('');
    }

    async function openSession(sessionId) {
        if (sessionId === window.APP.sessionId) return;
        window.APP.sessionId = sessionId;
        chatMessages.innerHTML = '';
        welcomeScreen.style.display = 'none';
        try {
            const resp = await fetch(window.APP.apiBase + '/history.php?session_id=' + encodeURIComponent(sessionId));
            const data = await resp.json();
            if (data.history) { data.history.forEach(msg => appendMessage(msg.role, msg.content)); }
        } catch (e) { console.error('Failed to load history:', e); }
        chatMessages.scrollTop = chatMessages.scrollHeight;
        loadSessions();
    }

    // ============ SEND MESSAGE ============
    async function sendMessage() {
        if (isProcessing || !window.APP.activeModel) return;
        const content = chatInput.value.trim();
        const hasFiles = pendingFiles.filter(p => p.url && !p.uploading).length > 0;
        const hasImages = pendingImages.filter(p => p.url && !p.uploading).length > 0;
        if (!content && !hasImages && !hasFiles) return;

        if (pendingImages.some(p => p.uploading) || pendingFiles.some(p => p.uploading)) {
            appendMessage('assistant', '⏳ Đang upload file, vui lòng đợi...');
            return;
        }

        isProcessing = true; sendBtn.disabled = true; welcomeScreen.style.display = 'none';

        const imageUrls = pendingImages.filter(p => p.url).map(p => p.url);
        const filesData = pendingFiles.filter(p => p.url).map(f => ({ url: f.url, name: f.original_name || f.name, content: f.content, type: f.type }));
        const fileUrls = filesData.map(f => f.url);

        let userDisplay = content;
        if (imageUrls.length > 0) {
            userDisplay = (content || 'Mô tả hình ảnh ...') + '\n' + imageUrls.map(u => '![' + u + '](' + u + ')').join('\n');
        }
        if (fileUrls.length > 0) {
            const fileLabels = filesData.map(f => '📎 [' + f.name + '](' + f.url + ')').join('\n');
            userDisplay = (userDisplay || 'Xem file đính kèm') + '\n' + fileLabels;
        }
        appendMessage('user', userDisplay, true); // User messages: no markdown parsing needed

        pendingImages = []; pendingFiles = []; renderPreviews();
        chatInput.value = ''; chatInput.style.height = 'auto';

        // Fetch directly to AI Gateway (port 8000) - no PHP middleware needed
        // Gateway handles: auth, token counting, credit deduction, logging
        if (!window.APP.gatewayUrl || !window.APP.apiKey) {
            appendMessage('assistant', '❌ Lỗi: Chưa cấu hình API Gateway hoặc API Key. Vào Dashboard tạo API Key.');
            isProcessing = false; sendBtn.disabled = false;
            return;
        }

        const loadId = appendLoading();
        try {
            // Build OpenAI-compatible messages with optional images
            const messages = [];
            
            // Build user message content parts
            let userContent = content || 'Hãy xem và mô tả file đính kèm';
            
            if (imageUrls.length > 0) {
                // Vision format: content is array of parts
                const parts = [];
                if (content) {
                    parts.push({ type: 'text', text: content });
                }
                imageUrls.forEach(url => {
                    parts.push({ type: 'image_url', image_url: { url: url } });
                });
                // Add file content as text if any
                if (filesData.length > 0) {
                    const fileText = filesData.map(f => `[File: ${f.name}]\n${f.content}`).join('\n\n');
                    parts.push({ type: 'text', text: fileText });
                }
                userContent = parts;
            } else if (filesData.length > 0) {
                // Attach file content as text
                const fileText = filesData.map(f => `[File: ${f.name}]\n${f.content}`).join('\n\n');
                userContent = (content ? content + '\n\n' : '') + fileText;
            }
            
            messages.push({ role: 'user', content: userContent });

            const body = {
                model: window.APP.activeModel.model_id || window.APP.activeModel.name,
                messages: messages,
                stream: true
            };
            
            const resp = await fetch(window.APP.gatewayUrl + '/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + window.APP.apiKey
                },
                body: JSON.stringify(body)
            });

            if (!resp.ok) {
                const errData = await resp.json().catch(() => ({}));
                removeLoading(loadId);
                appendMessage('assistant', '❌ Lỗi: ' + (errData.error || errData.detail || 'HTTP ' + resp.status));
                isProcessing = false; sendBtn.disabled = false;
                return;
            }

            removeLoading(loadId);
            const streamId = appendStreamingMessage();
            const reader = resp.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.substring(6));
                            if (data.delta) { appendDelta(streamId, data.delta); }
                            else if (data.error) { finishStreaming(streamId, true, data.error); }
                            else if (data.done) { finishStreaming(streamId, false, null, data.credits_remaining); }
                        } catch (e) {}
                    }
                }
            }
        } catch (e) {
            removeLoading(loadId);
            appendMessage('assistant', '❌ Lỗi kết nối: ' + e.message);
        }
        isProcessing = false; sendBtn.disabled = false;
        loadSessions();
    }

    function updateCredits(credits) {
        const el = document.getElementById('creditsDisplay');
        if (el) { el.textContent = '💎 ' + Number(credits).toLocaleString() + ' credits'; }
    }

    buildSidebar();
    loadSessions();
    </script>
    <?php endif; ?>
</body>
</html>