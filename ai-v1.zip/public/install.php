<?php
/**
 * LocNguyen AI - Installation Script
 * Creates database, tables, admin account, and pre-seeded models
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$message = '';
$error = '';

if ($step === 1) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $db_host = $_POST['db_host'] ?? 'localhost';
        $db_user = $_POST['db_user'] ?? 'root';
        $db_pass = $_POST['db_pass'] ?? '';
        $db_name = $_POST['db_name'] ?? 'locnguyen_ai';
        
        try {
            $conn = new mysqli($db_host, $db_user, $db_pass);
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            
            $conn->query("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $conn->select_db($db_name);
            
            // ========================
            // USERS TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `users` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `username` VARCHAR(50) UNIQUE NOT NULL,
                `email` VARCHAR(100) UNIQUE NOT NULL,
                `password` VARCHAR(255) NOT NULL,
                `full_name` VARCHAR(100) DEFAULT '',
                `avatar` VARCHAR(500) DEFAULT '',
                `credits` BIGINT DEFAULT 10000,
                `total_tokens_used` BIGINT DEFAULT 0,
                `role` ENUM('user','admin') DEFAULT 'user',
                `is_active` TINYINT(1) DEFAULT 1,
                `last_login` DATETIME NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // API KEYS TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `api_keys` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NOT NULL,
                `name` VARCHAR(100) DEFAULT 'Default Key',
                `api_key` VARCHAR(64) UNIQUE NOT NULL,
                `is_active` TINYINT(1) DEFAULT 1,
                `requests_count` BIGINT DEFAULT 0,
                `tokens_used` BIGINT DEFAULT 0,
                `last_used` DATETIME NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // AI MODELS TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `ai_models` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `name` VARCHAR(100) NOT NULL,
                `model_id` VARCHAR(100) NOT NULL,
                `provider` VARCHAR(50) DEFAULT 'openai',
                `description` TEXT,
                `base_url` VARCHAR(500) DEFAULT '',
                `api_key` VARCHAR(255) DEFAULT '',
                `max_tokens` INT DEFAULT 4096,
                `cost_per_1k_tokens` FLOAT DEFAULT 0.001,
                `temperature` FLOAT DEFAULT 0.7,
                `is_active` TINYINT(1) DEFAULT 1,
                `is_default` TINYINT(1) DEFAULT 0,
                `sort_order` INT DEFAULT 0,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // CHAT HISTORY TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `chat_history` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NULL,
                `api_key_id` INT NULL,
                `session_id` VARCHAR(64) NOT NULL,
                `model_id` INT NULL,
                `role` ENUM('user','assistant','system') NOT NULL,
                `content` LONGTEXT NOT NULL,
                `tokens_prompt` INT DEFAULT 0,
                `tokens_completion` INT DEFAULT 0,
                `tokens_total` INT DEFAULT 0,
                `response_time_ms` INT DEFAULT 0,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX `idx_session` (`session_id`),
                INDEX `idx_user` (`user_id`),
                INDEX `idx_created` (`created_at`),
                FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // SETTINGS TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `settings` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `setting_key` VARCHAR(100) UNIQUE NOT NULL,
                `setting_value` TEXT,
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // CREDIT LOGS TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `credit_logs` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NOT NULL,
                `amount` BIGINT NOT NULL,
                `type` ENUM('usage','refill','bonus','refund') DEFAULT 'usage',
                `description` VARCHAR(255) DEFAULT '',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX `idx_user_credit` (`user_id`, `created_at`),
                FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // USAGE STATS TABLE
            // ========================
            $conn->query("CREATE TABLE IF NOT EXISTS `usage_stats` (
                `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NULL,
                `model_id` INT NULL,
                `tokens_prompt` BIGINT DEFAULT 0,
                `tokens_completion` BIGINT DEFAULT 0,
                `tokens_total` BIGINT DEFAULT 0,
                `requests_count` INT DEFAULT 1,
                `date` DATE NOT NULL,
                INDEX `idx_date` (`date`),
                INDEX `idx_user_date` (`user_id`, `date`),
                UNIQUE KEY `unique_daily` (`user_id`, `model_id`, `date`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // ========================
            // DEFAULT SETTINGS
            // ========================
            $conn->query("INSERT IGNORE INTO settings (setting_key, setting_value) VALUES 
                ('site_name', 'LocNguyen AI'),
                ('site_description', 'Nền tảng AI thông minh - Đa dạng mô hình, Mạnh mẽ, Tin cậy'),
                ('base_url', 'https://api.openai.com'),
                ('api_key', ''),
                ('default_model', '1'),
                ('credits_per_token', '0.001'),
                ('register_credits', '10000'),
                ('maintenance_mode', '0')
            ");
            
            // ========================
            // ADMIN ACCOUNT
            // ========================
            $admin_hash = password_hash('Loc12345s@', PASSWORD_BCRYPT);
            $conn->query("INSERT IGNORE INTO users (username, email, password, full_name, role, credits, is_active) VALUES 
                ('locnguyen', 'admin@locnguyen.ai', '$admin_hash', 'Loc Nguyen', 'admin', 99999999, 1)
            ");
            
            // ========================
            // PRE-SEEDED AI MODELS
            // ========================
            $models = [
                ['DeepSeek V4 Pro', 'deepseek-v4-pro', 'deepseek', 'DeepSeek V4 Pro - Mô hình mạnh nhất của DeepSeek', 32768, 0],
                ['GLM-5.2', 'glm-5.2', 'zhipu', 'GLM-5.2 - Mô hình từ Zhipu AI', 32768, 1],
                ['Kimi K2.6', 'kimi-k2.6', 'moonshot', 'Kimi K2.6 - Mô hình từ Moonshot AI', 32768, 2],
                ['Qwen3 235B A22B Instruct', 'qwen3-235b-a22b', 'alibaba', 'Qwen3 235B - Mô hình MoE 235B tham số', 32768, 3],
                ['DeepSeek V4 Flash', 'deepseek-v4-flash', 'deepseek', 'DeepSeek V4 Flash - Phiên bản nhanh, giá rẻ', 16384, 4],
                ['DeepSeek V3 0324', 'deepseek-v3-0324', 'deepseek', 'DeepSeek V3 - Phiên bản 0324', 32768, 5],
                ['Nemotron 3 Ultra 550B', 'nemotron-3-ultra-550b', 'nvidia', 'NVIDIA Nemotron 3 Ultra 550B', 32768, 6],
                ['GPT-OSS 120B', 'gpt-oss-120b', 'openai', 'GPT-OSS 120B - Mô hình mã nguồn mở', 32768, 7],
                ['Llama 3.3 70B Instruct', 'llama-3.3-70b', 'meta', 'Meta Llama 3.3 70B Instruct', 32768, 8],
                ['Nemotron 3 Super 120B', 'nemotron-3-super-120b', 'nvidia', 'NVIDIA Nemotron 3 Super 120B', 32768, 9],
                ['GLM-5.1', 'glm-5.1', 'zhipu', 'GLM-5.1 - Phiên bản trước của GLM-5.2', 32768, 10],
                ['Gemma 4 31B', 'gemma-4-31b', 'google', 'Google Gemma 4 31B', 16384, 11],
                ['Navigator n1.5', 'navigator-n1.5', 'navigator', 'Navigator n1.5', 16384, 12],
                ['Nemotron 3 Nano Omni', 'nemotron-3-nano-omni', 'nvidia', 'NVIDIA Nemotron 3 Nano Omni', 16384, 13],
                ['Nemotron 3 Nano 30B', 'nemotron-3-nano-30b', 'nvidia', 'NVIDIA Nemotron 3 Nano 30B', 16384, 14],
                ['Qwen3.6 35B A3B', 'qwen3.6-35b-a3b', 'alibaba', 'Qwen3.6 35B A3B - MoE hiệu quả', 16384, 15],
                ['GPT-OSS 20B', 'gpt-oss-20b', 'openai', 'GPT-OSS 20B', 16384, 16],
                ['Llama 3.1 8B Instruct', 'llama-3.1-8b', 'meta', 'Meta Llama 3.1 8B Instruct', 8192, 17],
                ['Qwen3 8B', 'qwen3-8b', 'alibaba', 'Qwen3 8B', 8192, 18],
                ['Qwen3.5 9B', 'qwen3.5-9b', 'alibaba', 'Qwen3.5 9B', 8192, 19],
                ['Qwen3.5 2B', 'qwen3.5-2b', 'alibaba', 'Qwen3.5 2B - Mô hình nhẹ nhất', 4096, 20],
            ];
            
            $stmt = $conn->prepare("INSERT IGNORE INTO ai_models (name, model_id, provider, description, max_tokens, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
            foreach ($models as $m) {
                $stmt->bind_param("ssssii", $m[0], $m[1], $m[2], $m[3], $m[4], $m[5]);
                $stmt->execute();
            }
            $stmt->close();
            
            // ========================
            // WRITE CONFIG FILE
            // ========================
            $configContent = "<?php
if (!defined('DB_HOST')) {
    define('DB_HOST', '" . addslashes($db_host) . "');
    define('DB_USER', '" . addslashes($db_user) . "');
    define('DB_PASS', '" . addslashes($db_pass) . "');
    define('DB_NAME', '" . addslashes($db_name) . "');
}
if (!defined('SITE_URL')) {
    \$protocol = (!empty(\$_SERVER['HTTPS']) && \$_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    \$sitePath = rtrim(dirname(\$_SERVER['SCRIPT_NAME']), '/\\\\');
    define('SITE_URL', \$protocol . '://' . \$_SERVER['HTTP_HOST'] . (\$sitePath === '' ? '' : \$sitePath));
}
";
            
            file_put_contents(__DIR__ . '/config/database.php', $configContent);
            
            $message = "Cài đặt thành công! Database '{$db_name}' và tất cả bảng đã được tạo.";
            $step = 2;
            
        } catch (Exception $e) {
            $error = "Lỗi: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt - LocNguyen AI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #030712; --card: #0f172a; --card2: #1e293b;
            --border: #1e293b; --border-light: #334155;
            --text: #f1f5f9; --text2: #94a3b8; --text3: #64748b;
            --accent: #6366f1; --accent-light: #818cf8;
            --accent-glow: rgba(99,102,241,0.3);
            --green: #22c55e; --green-bg: rgba(34,197,94,0.1);
            --red: #ef4444; --red-bg: rgba(239,68,68,0.1);
            --radius: 12px; --radius-lg: 16px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg); color: var(--text);
            min-height: 100vh; display: flex;
            align-items: center; justify-content: center;
            position: relative; overflow: hidden;
        }
        .bg-grid {
            position: fixed; inset: 0;
            background-image: linear-gradient(rgba(99,102,241,0.04) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(99,102,241,0.04) 1px, transparent 1px);
            background-size: 80px 80px; pointer-events: none; z-index: 0;
        }
        .bg-orb {
            position: fixed; border-radius: 50%;
            filter: blur(150px); pointer-events: none; z-index: 0;
        }
        .bg-orb-1 { width: 600px; height: 600px; background: rgba(99,102,241,0.1); top: -200px; right: -200px; }
        .bg-orb-2 { width: 500px; height: 500px; background: rgba(129,140,248,0.08); bottom: -200px; left: -150px; }

        .container { position: relative; z-index: 1; max-width: 560px; width: 100%; padding: 20px; }

        .brand { text-align: center; margin-bottom: 28px; }
        .brand-icon {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            border-radius: 18px; display: inline-flex;
            align-items: center; justify-content: center;
            font-size: 1.8rem; margin-bottom: 12px;
            box-shadow: 0 8px 32px var(--accent-glow);
        }
        .brand h1 {
            font-size: 1.5rem; font-weight: 700;
            background: linear-gradient(135deg, #fff, #a5b4fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .brand p { color: var(--text3); font-size: 0.9rem; margin-top: 4px; }

        .card {
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius-lg); padding: 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5);
        }

        .alert {
            padding: 16px 20px; border-radius: 10px;
            margin-bottom: 20px; font-size: 0.9rem;
            display: flex; align-items: flex-start; gap: 12px;
            line-height: 1.5;
        }
        .alert-success { background: var(--green-bg); border: 1px solid rgba(34,197,94,0.3); color: var(--green); }
        .alert-error { background: var(--red-bg); border: 1px solid rgba(239,68,68,0.3); color: var(--red); }

        .form-group { margin-bottom: 16px; }
        label { display: block; margin-bottom: 6px; font-size: 0.85rem; font-weight: 500; color: var(--text2); }
        input {
            width: 100%; padding: 11px 14px;
            background: var(--card2); border: 1px solid var(--border-light);
            border-radius: var(--radius); color: var(--text);
            font-size: 0.95rem; font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(99,102,241,0.15); }
        .info { font-size: 0.8rem; color: var(--text3); margin-top: 4px; }

        .btn {
            width: 100%; padding: 13px; border: none; border-radius: var(--radius);
            font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s;
            font-family: 'Inter', sans-serif; text-decoration: none; display: block; text-align: center;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), #7c3aed);
            color: #fff; box-shadow: 0 4px 16px var(--accent-glow);
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px var(--accent-glow); }
        .btn-success { background: var(--green); color: #fff; margin-top: 12px; }
        .btn-success:hover { opacity: 0.9; }
        .btn-outline {
            background: transparent; border: 1px solid var(--border-light);
            color: var(--text2); margin-top: 8px;
        }
        .btn-outline:hover { border-color: var(--accent); color: var(--text); }

        .creds-box {
            background: var(--card2); border: 1px solid var(--border-light);
            border-radius: var(--radius); padding: 16px; margin-top: 16px;
        }
        .creds-box code {
            display: block; padding: 6px 0;
            color: var(--accent-light); font-size: 0.95rem;
        }
    </style>
</head>
<body>
    <div class="bg-grid"></div>
    <div class="bg-orb bg-orb-1"></div>
    <div class="bg-orb bg-orb-2"></div>

    <div class="container">
        <div class="brand">
            <div class="brand-icon">🚀</div>
            <h1>LocNguyen AI</h1>
            <p>Cài đặt hệ thống</p>
        </div>

        <div class="card">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $message; ?></span>
                </div>
                <div class="creds-box">
                    <p style="color:var(--text2);font-size:0.85rem;margin-bottom:6px;">📋 Tài khoản quản trị:</p>
                    <code>👤 Username: locnguyen</code>
                    <code>🔑 Password: Loc12345s@</code>
                </div>
                <a href="admin/" class="btn btn-success">
                    <i class="fas fa-gear"></i> Vào Admin Panel
                </a>
                <a href="index.php" class="btn btn-outline">
                    <i class="fas fa-home"></i> Vào trang chủ
                </a>
            <?php elseif ($step === 1): ?>
                <form method="POST">
                    <div class="form-group">
                        <label>MySQL Host</label>
                        <input type="text" name="db_host" value="localhost">
                    </div>
                    <div class="form-group">
                        <label>MySQL Username</label>
                        <input type="text" name="db_user" value="root">
                    </div>
                    <div class="form-group">
                        <label>MySQL Password</label>
                        <input type="text" name="db_pass" placeholder="Để trống nếu không có mật khẩu">
                    </div>
                    <div class="form-group">
                        <label>Database Name</label>
                        <input type="text" name="db_name" value="locnguyen_ai">
                        <div class="info">Database sẽ được tự động tạo nếu chưa tồn tại</div>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-rocket"></i> Bắt đầu cài đặt
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>