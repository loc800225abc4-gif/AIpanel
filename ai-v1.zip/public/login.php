<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

if (isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Vui lòng nhập username và mật khẩu.';
    } else {
        try {
            $db = getDB();
            // Check users table first
            $stmt = $db->prepare("SELECT id, username, password, 'user' as user_type, role, is_active FROM users WHERE (username = ? OR email = ?)");
            $stmt->bind_param("ss", $username, $username);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();

            // If not found, check admins table
            if (!$user) {
                $stmt = $db->prepare("SELECT id, username, password, 'admin' as user_type, role, is_active FROM admins WHERE (username = ? OR email = ?)");
                $stmt->bind_param("ss", $username, $username);
                $stmt->execute();
                $user = $stmt->get_result()->fetch_assoc();
            }
            
            if ($user && password_verify($password, $user['password'])) {
                if (!$user['is_active']) {
                    $error = 'Tài khoản đã bị khóa hoặc chưa kích hoạt.';
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_type'] = $user['user_type'];
                    $table = $user['user_type'] === 'admin' ? 'admins' : 'users';
                    $db->query("UPDATE $table SET last_login = NOW() WHERE id = " . intval($user['id']));
                    
                    // Redirect admin to admin panel
                    if ($user['user_type'] === 'admin' || $user['role'] === 'admin' || $user['role'] === 'super_admin') {
                        header('Location: admin/dashboard.php');
                        exit;
                    }
                    
                    $redirect = $_GET['redirect'] ?? 'dashboard.php';
                    header('Location: ' . $redirect);
                    exit;
                }
            } else {
                $error = 'Username hoặc mật khẩu không đúng.';
            }
        } catch (Exception $e) {
            $error = 'Lỗi kết nối database. Vui lòng chạy <a href="install.php">cài đặt</a> trước.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - LocNguyen AI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #030712;
            --card: #0f172a;
            --card2: #1e293b;
            --border: #1e293b;
            --border-light: #334155;
            --text: #f1f5f9;
            --text2: #94a3b8;
            --text3: #64748b;
            --accent: #6366f1;
            --accent-light: #818cf8;
            --accent-glow: rgba(99,102,241,0.3);
            --red: #ef4444;
            --red-bg: rgba(239,68,68,0.1);
            --green: #22c55e;
            --radius: 12px;
            --radius-lg: 16px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        /* Background Effects */
        .bg-grid {
            position: fixed; inset: 0;
            background-image: linear-gradient(rgba(99,102,241,0.04) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(99,102,241,0.04) 1px, transparent 1px);
            background-size: 80px 80px;
            pointer-events: none;
            z-index: 0;
        }
        .bg-orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(150px);
            pointer-events: none;
            z-index: 0;
        }
        .bg-orb-1 { width: 600px; height: 600px; background: rgba(99,102,241,0.15); top: -200px; right: -200px; }
        .bg-orb-2 { width: 500px; height: 500px; background: rgba(129,140,248,0.1); bottom: -200px; left: -150px; }

        .login-wrapper {
            position: relative; z-index: 1;
            width: 100%; max-width: 440px;
            padding: 20px;
        }

        /* Brand */
        .brand {
            text-align: center; margin-bottom: 32px;
        }
        .brand-icon {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            border-radius: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 12px;
            box-shadow: 0 8px 32px var(--accent-glow);
        }
        .brand h1 {
            font-size: 1.5rem; font-weight: 700;
            background: linear-gradient(135deg, #fff, #a5b4fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .brand p { color: var(--text3); font-size: 0.9rem; margin-top: 4px; }

        /* Card */
        .login-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 36px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5);
        }

        /* Error */
        .alert {
            padding: 14px 18px; border-radius: 10px;
            margin-bottom: 20px; font-size: 0.9rem;
            display: flex; align-items: center; gap: 10px;
        }
        .alert-error {
            background: var(--red-bg);
            border: 1px solid rgba(239,68,68,0.3);
            color: var(--red);
        }
        .alert-error a { color: #fca5a5; }

        /* Form */
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block; margin-bottom: 6px;
            font-size: 0.85rem; font-weight: 500; color: var(--text2);
        }
        .input-wrapper {
            position: relative;
        }
        .input-wrapper i {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%);
            color: var(--text3); font-size: 1rem;
            pointer-events: none;
        }
        .input-wrapper input {
            width: 100%; padding: 12px 14px 12px 42px;
            background: var(--card2); border: 1px solid var(--border-light);
            border-radius: var(--radius); color: var(--text);
            font-size: 0.95rem; font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        .input-wrapper input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(99,102,241,0.15);
        }

        .btn-login {
            width: 100%; padding: 13px;
            background: linear-gradient(135deg, var(--accent), #7c3aed);
            color: #fff; border: none; border-radius: var(--radius);
            font-size: 1rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 16px var(--accent-glow);
            margin-top: 6px;
            font-family: 'Inter', sans-serif;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 28px var(--accent-glow);
        }

        .divider {
            display: flex; align-items: center; gap: 16px;
            margin: 24px 0; color: var(--text3); font-size: 0.8rem;
        }
        .divider::before, .divider::after {
            content: ''; flex: 1; height: 1px; background: var(--border-light);
        }

        .links {
            text-align: center; font-size: 0.9rem; color: var(--text3);
        }
        .links a {
            color: var(--accent-light); text-decoration: none;
            font-weight: 500; transition: color 0.2s;
        }
        .links a:hover { color: #c7d2fe; }
        .links span { margin: 0 6px; color: var(--border-light); }
    </style>
</head>
<body>
    <div class="bg-grid"></div>
    <div class="bg-orb bg-orb-1"></div>
    <div class="bg-orb bg-orb-2"></div>

    <div class="login-wrapper">
        <div class="brand">
            <div class="brand-icon">🧠</div>
            <h1>LocNguyen AI</h1>
            <p>Đăng nhập để tiếp tục</p>
        </div>

        <div class="login-card">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" autocomplete="off">
                <div class="form-group">
                    <label>Username hoặc Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" name="username" required autofocus
                               value="<?php echo sanitize($_POST['username'] ?? ''); ?>"
                               placeholder="Nhập username hoặc email">
                    </div>
                </div>

                <div class="form-group">
                    <label>Mật khẩu</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" required
                               placeholder="Nhập mật khẩu">
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Đăng nhập
                </button>
            </form>

            <div class="divider">HOẶC</div>

            <div class="links">
                <a href="register.php">Tạo tài khoản mới</a>
                <span>|</span>
                <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
            </div>
        </div>
    </div>
</body>
</html>