<?php
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/functions.php';

if (isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $fullname = trim($_POST['full_name'] ?? '');
    
    // Validation
    if (strlen($username) < 3) {
        $error = 'Username phải có ít nhất 3 ký tự.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Email không hợp lệ.';
    } elseif (strlen($password) < 6) {
        $error = 'Mật khẩu phải có ít nhất 6 ký tự.';
    } elseif ($password !== $confirm) {
        $error = 'Mật khẩu xác nhận không khớp.';
    } else {
        try {
            $db = getDB();
            
            // Check existing
            $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $error = 'Username hoặc email đã tồn tại.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $registerCredits = intval(getSetting('register_credits', '10000'));
                
$stmt = $db->prepare("INSERT INTO users (username, email, password, full_name, credits, is_active) VALUES (?, ?, ?, ?, ?, 1)");
                $stmt->bind_param("ssssi", $username, $email, $hash, $fullname, $registerCredits);
                
                if ($stmt->execute()) {
                    $userId = $stmt->insert_id;
                    
                    // Auto-create API key with AI Gateway-compatible hashes
                    $apiKey = generateApiKey();
                    $key_hash = hash('sha256', substr($apiKey, 0, 32));
                    $key_prefix = substr($apiKey, 0, 15);
                    $key_suffix = substr($apiKey, -4);
                    $full_key_hash = hash('sha256', $apiKey);
                    $stmt = $db->prepare("INSERT INTO api_keys (user_id, name, api_key, is_active, key_hash, key_prefix, key_suffix, full_key_hash, quota_type, quota_value) VALUES (?, 'Default Key', ?, 1, ?, ?, ?, ?, 'unlimited', 0)");
                    $stmt->bind_param("isssss", $userId, $apiKey, $key_hash, $key_prefix, $key_suffix, $full_key_hash);
                    $stmt->execute();
                    
                    // Auto-login
                    $_SESSION['user_id'] = $userId;
                    $success = 'Đăng ký thành công! Đang chuyển hướng...';
                    header('Refresh: 1; URL=dashboard.php');
                } else {
                    $error = 'Lỗi đăng ký. Vui lòng thử lại.';
                }
            }
        } catch (Exception $e) {
            $error = 'Lỗi database. Vui lòng cài đặt trước tại <a href="install.php">install.php</a>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký - LocNguyen AI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #030712; --card: #0f172a; --card2: #1e293b;
            --border: #1e293b; --border-light: #334155;
            --text: #f1f5f9; --text2: #94a3b8; --text3: #64748b;
            --accent: #6366f1; --accent-light: #818cf8;
            --accent-glow: rgba(99,102,241,0.3);
            --red: #ef4444; --red-bg: rgba(239,68,68,0.1);
            --green: #22c55e; --green-bg: rgba(34,197,94,0.1);
            --radius: 12px; --radius-lg: 16px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg); color: var(--text);
            min-height: 100vh; display: flex;
            align-items: center; justify-content: center;
            position: relative; overflow: hidden;
        }
        .bg-grid {
            position: fixed; inset: 0;
            background-image: linear-gradient(rgba(99,102,241,0.04) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(99,102,241,0.04) 1px, transparent 1px);
            background-size: 80px 80px; pointer-events: none; z-index: 0;
        }
        .bg-orb-1 { width: 600px; height: 600px; background: rgba(99,102,241,0.1); top: -200px; left: -200px; position: fixed; border-radius: 50%; filter: blur(150px); }
        .bg-orb-2 { width: 500px; height: 500px; background: rgba(129,140,248,0.06); bottom: -200px; right: -150px; position: fixed; border-radius: 50%; filter: blur(150px); }

        .wrapper { position: relative; z-index: 1; max-width: 460px; width: 100%; padding: 20px; }

        .brand { text-align: center; margin-bottom: 28px; }
        .brand-icon {
            width: 60px; height: 60px;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            border-radius: 16px; display: inline-flex;
            align-items: center; justify-content: center;
            font-size: 1.6rem; margin-bottom: 10px;
            box-shadow: 0 8px 32px var(--accent-glow);
        }
        .brand h1 {
            font-size: 1.4rem; font-weight: 700;
            background: linear-gradient(135deg, #fff, #a5b4fc);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .brand p { color: var(--text3); font-size: 0.85rem; margin-top: 4px; }

        .card {
            background: var(--card); border: 1px solid var(--border);
            border-radius: var(--radius-lg); padding: 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5);
        }

        .alert {
            padding: 14px 18px; border-radius: 10px;
            margin-bottom: 20px; font-size: 0.9rem;
            display: flex; align-items: center; gap: 10px;
        }
        .alert-error { background: var(--red-bg); border: 1px solid rgba(239,68,68,0.3); color: var(--red); }
        .alert-success { background: var(--green-bg); border: 1px solid rgba(34,197,94,0.3); color: var(--green); }
        .alert a { color: #fca5a5; }

        .row { display: flex; gap: 12px; }
        .form-group { margin-bottom: 16px; flex: 1; }
        .form-group label { display: block; margin-bottom: 6px; font-size: 0.85rem; font-weight: 500; color: var(--text2); }
        .input-wrapper { position: relative; }
        .input-wrapper i {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%); color: var(--text3); font-size: 0.95rem;
        }
        .input-wrapper input {
            width: 100%; padding: 11px 14px 11px 40px;
            background: var(--card2); border: 1px solid var(--border-light);
            border-radius: var(--radius); color: var(--text);
            font-size: 0.95rem; font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        .input-wrapper input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(99,102,241,0.15); }

        .btn {
            width: 100%; padding: 13px; border: none; border-radius: var(--radius);
            font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s;
            font-family: 'Inter', sans-serif; margin-top: 4px;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), #7c3aed);
            color: #fff; box-shadow: 0 4px 16px var(--accent-glow);
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px var(--accent-glow); }
        .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }

        .links { text-align: center; margin-top: 20px; font-size: 0.9rem; color: var(--text3); }
        .links a { color: var(--accent-light); text-decoration: none; font-weight: 500; }
        .links a:hover { color: #c7d2fe; }
    </style>
</head>
<body>
    <div class="bg-grid"></div>
    <div class="bg-orb-1"></div>
    <div class="bg-orb-2"></div>

    <div class="wrapper">
        <div class="brand">
            <div class="brand-icon">🧠</div>
            <h1>LocNguyen AI</h1>
            <p>Tạo tài khoản mới - Nhận 10,000 credits miễn phí</p>
        </div>

        <div class="card">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" autocomplete="off">
                <div class="form-group">
                    <label>Username</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" name="username" required minlength="3"
                               value="<?php echo sanitize($_POST['username'] ?? ''); ?>"
                               placeholder="Tối thiểu 3 ký tự">
                    </div>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" required
                               value="<?php echo sanitize($_POST['email'] ?? ''); ?>"
                               placeholder="your@email.com">
                    </div>
                </div>
                <div class="form-group">
                    <label>Họ tên</label>
                    <div class="input-wrapper">
                        <i class="fas fa-id-card"></i>
                        <input type="text" name="full_name"
                               value="<?php echo sanitize($_POST['full_name'] ?? ''); ?>"
                               placeholder="Tên hiển thị">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label>Mật khẩu</label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" required minlength="6" placeholder="Tối thiểu 6 ký tự">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Xác nhận</label>
                        <div class="input-wrapper">
                            <i class="fas fa-check"></i>
                            <input type="password" name="confirm_password" required placeholder="Nhập lại mật khẩu">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-rocket"></i> Đăng ký - Nhận 10K Credits
                </button>
            </form>

            <div class="links">
                Đã có tài khoản? <a href="login.php">Đăng nhập</a>
            </div>
        </div>
    </div>
</body>
</html>