#!/bin/bash
# =============================================================================
# Quick Rebuild - Rebuild only Python & PHP containers, keep MySQL data
# =============================================================================
set -e

echo "========================================"
echo " Quick Rebuild (Keep Database)"
echo "========================================"
echo ""

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Stop only app containers (keep mysql running)
echo -e "${YELLOW}[1/4] Stopping app containers...${NC}"
docker compose stop php-apache ai-gateway || true

# Remove old app containers
echo -e "${YELLOW}[2/4] Removing old app containers...${NC}"
docker compose rm -f php-apache ai-gateway || true

# Rebuild app images
echo -e "${YELLOW}[3/4] Rebuilding app images...${NC}"
docker compose build --no-cache php-apache ai-gateway

# Restart all
echo -e "${YELLOW}[4/4] Starting all services...${NC}"
docker compose up -d

echo ""
echo "========================================"
echo -e " ${GREEN}Rebuild Complete!${NC}"
echo "========================================"
echo ""
echo " Waiting 10s for services to be ready..."
sleep 10

# Run migration to fix api_keys table (status -> is_active)
echo ""
echo -e "${YELLOW}[Migration] Fixing api_keys table...${NC}"
docker compose exec -T mysql mysql -uroot -plocnguyen_ai_secret locnguyen_ai -e "
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER name;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS is_locked TINYINT(1) NOT NULL DEFAULT 0 AFTER full_key_hash;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS key_hash VARCHAR(255) DEFAULT NULL AFTER expires_at;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS key_prefix VARCHAR(20) DEFAULT NULL AFTER key_hash;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS key_suffix VARCHAR(10) DEFAULT NULL AFTER key_prefix;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS full_key_hash VARCHAR(255) DEFAULT NULL UNIQUE AFTER key_suffix;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS quota_type VARCHAR(20) NOT NULL DEFAULT 'unlimited' AFTER is_locked;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS quota_value INT NOT NULL DEFAULT 0 AFTER quota_type;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS quota_used INT NOT NULL DEFAULT 0 AFTER quota_value;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS quota_reset_at DATETIME NULL DEFAULT NULL AFTER quota_used;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS rpm_limit INT NOT NULL DEFAULT 0 AFTER quota_reset_at;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS tpm_limit INT NOT NULL DEFAULT 0 AFTER rpm_limit;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS last_used_ip VARCHAR(50) DEFAULT NULL AFTER tpm_limit;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS total_prompt_tokens BIGINT NOT NULL DEFAULT 0 AFTER last_used_ip;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS total_completion_tokens BIGINT NOT NULL DEFAULT 0 AFTER total_prompt_tokens;
  ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS total_tokens BIGINT NOT NULL DEFAULT 0 AFTER total_completion_tokens;
  -- Copy status -> is_active if needed
  UPDATE api_keys SET is_active = 1 WHERE is_active IS NULL;
" 2>/dev/null || echo "Migration skipped (table may already be correct)"

echo ""
echo " PHP Dashboard:  http://$(hostname -I | awk '{print $1}'):8080/login.php"
echo " AI Gateway API: http://$(hostname -I | awk '{print $1}'):8000/"
echo " Health Check:   http://$(hostname -I | awk '{print $1}'):8000/health"
echo " Debug Hash:     http://$(hostname -I | awk '{print $1}'):8000/debug/hash"
echo ""
echo " Login: tk=locnguyen, mk=Loc12345s@"
echo ""
echo " To view AI Gateway logs:"
echo "   docker compose logs ai-gateway --tail 50 -f"
echo ""