#!/bin/bash
# =============================================================================
# AI Gateway - Ubuntu Setup Script
# Port 8080: PHP Frontend (Apache)
# Port 8000: AI Gateway (Python FastAPI)
# Shared MySQL database on port 3306
# =============================================================================

set -e

echo "========================================"
echo " AI Gateway - Setup & Deploy"
echo "========================================"

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker not found. Installing..."
    sudo apt-get update
    sudo apt-get install -y docker.io docker-compose-v2
    sudo systemctl enable --now docker
    sudo usermod -aG docker $USER
    echo "✅ Docker installed. Please log out and back in, then re-run this script."
    exit 0
fi

cd "$(dirname "$0")"

echo "📦 Building Docker containers..."
docker compose build --no-cache

echo ""
echo "🚀 Starting services..."
docker compose up -d

echo ""
echo "⏳ Waiting for services to be ready..."
sleep 10

# Check container status
echo ""
echo "📊 Container status:"
docker compose ps

echo ""
echo "========================================"
echo " ✅ Deployment Complete!"
echo "========================================"
echo ""
echo " PHP Frontend:  http://localhost:8080"
echo " AI Gateway:    http://localhost:8000"
echo " Health Check:  http://localhost:8000/health"
echo ""
echo " Default Admin: locnguyen / Loc12345s@"
echo ""
echo " Useful commands:"
echo "   docker compose logs -f              # View all logs"
echo "   docker compose logs -f ai-gateway   # AI Gateway logs"
echo "   docker compose logs -f php-apache   # PHP logs"
echo "   docker compose restart              # Restart all"
echo "   docker compose down                 # Stop all"
echo "   docker compose down -v              # Stop all + delete DB"
echo "========================================"