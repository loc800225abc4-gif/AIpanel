@echo off
chcp 65001 > nul
title AI-Gateway - LocNguyen AI Platform
echo ========================================
echo   AI-Gateway Startup Script
echo ========================================
echo.

REM Check if PHP is available
where php >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] PHP not found in PATH. Apache must be configured separately.
    echo   Make sure XAMPP Apache is running on port 8080.
) else (
    echo [OK] PHP found in PATH.
)

REM Check if Python is available
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python not found! Please install Python 3.11+.
    pause
    exit /b 1
)
echo [OK] Python found in PATH.

echo.

REM Install Python dependencies (if needed)
echo [*] Checking Python dependencies...
pip install -r requirements.txt --quiet
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] Some packages may have failed to install.
)

echo.

echo ========================================
echo   Starting AI Gateway (Python - Port 8000)
echo ========================================
echo.
echo   PHP Frontend: http://localhost:8080
echo   AI Gateway:   http://localhost:8000
echo   Gateway Dashboard: http://localhost:8000/dashboard
echo.
echo   Press Ctrl+C to stop the gateway.
echo ========================================
echo.

python main.py

pause