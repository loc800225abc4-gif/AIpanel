<?php
function getDB() {
    static $db = null;
    if ($db === null) {
        try {
            mysqli_report(MYSQLI_REPORT_OFF);
            $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($db->connect_error) {
                error_log('DB connection failed: ' . $db->connect_error);
                return null;
            }
            $db->set_charset('utf8mb4');
            // Auto-migrate: add missing columns
            @$db->query("ALTER TABLE usage_logs ADD COLUMN input_tokens INT NOT NULL DEFAULT 0 AFTER request_type");
            @$db->query("ALTER TABLE usage_logs ADD COLUMN output_tokens INT NOT NULL DEFAULT 0 AFTER input_tokens");
            @$db->query("ALTER TABLE usage_logs ADD COLUMN estimated_cost DECIMAL(10,6) NOT NULL DEFAULT 0.000000 AFTER output_tokens");
            @$db->query("ALTER TABLE usage_logs ADD COLUMN actual_cost DECIMAL(10,6) NOT NULL DEFAULT 0.000000 AFTER estimated_cost");
            // ai_models missing columns
            @$db->query("ALTER TABLE ai_models ADD COLUMN api_key VARCHAR(255) DEFAULT NULL AFTER type");
            @$db->query("ALTER TABLE ai_models ADD COLUMN base_url VARCHAR(500) DEFAULT NULL AFTER api_key");
            @$db->query("ALTER TABLE ai_models ADD COLUMN temperature DECIMAL(3,2) NOT NULL DEFAULT 0.70 AFTER max_tokens");
            @$db->query("ALTER TABLE ai_models ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER status");
            // user_api_keys missing columns
            @$db->query("ALTER TABLE user_api_keys ADD COLUMN last_used DATETIME DEFAULT NULL AFTER api_key");
            // chat_history missing columns
            @$db->query("ALTER TABLE chat_history ADD COLUMN session_id VARCHAR(64) DEFAULT NULL AFTER user_id");
            @$db->query("ALTER TABLE chat_history ADD COLUMN model_id INT DEFAULT NULL AFTER session_id");
            @$db->query("ALTER TABLE chat_history ADD COLUMN tokens_prompt INT NOT NULL DEFAULT 0 AFTER content");
            @$db->query("ALTER TABLE chat_history ADD COLUMN tokens_completion INT NOT NULL DEFAULT 0 AFTER tokens_prompt");
            @$db->query("ALTER TABLE chat_history ADD COLUMN response_time_ms INT DEFAULT NULL AFTER tokens_total");
            // Ensure credit_logs table exists
            @$db->query("CREATE TABLE IF NOT EXISTS credit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                amount INT NOT NULL,
                type VARCHAR(50) NOT NULL,
                description TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user (user_id),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            // Ensure admin_settings table exists
            @$db->query("CREATE TABLE IF NOT EXISTS admin_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(100) NOT NULL UNIQUE,
                setting_value TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            // Ensure api_keys table exists (with gateway columns)
            @$db->query("CREATE TABLE IF NOT EXISTS api_keys (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                api_key VARCHAR(64) NOT NULL UNIQUE,
                name VARCHAR(200) NOT NULL DEFAULT 'Default Key',
                status VARCHAR(20) NOT NULL DEFAULT 'active',
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                last_used DATETIME DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME DEFAULT NULL,
                total_requests BIGINT NOT NULL DEFAULT 0,
                key_hash VARCHAR(255) DEFAULT NULL,
                key_prefix VARCHAR(20) DEFAULT NULL,
                key_suffix VARCHAR(10) DEFAULT NULL,
                full_key_hash VARCHAR(255) DEFAULT NULL UNIQUE,
                is_locked TINYINT(1) DEFAULT 0,
                quota_type VARCHAR(20) DEFAULT 'unlimited',
                quota_value INT DEFAULT 0,
                quota_used INT DEFAULT 0,
                quota_reset_at DATETIME NULL,
                rpm_limit INT DEFAULT 0,
                tpm_limit INT DEFAULT 0,
                last_used_ip VARCHAR(50) NULL,
                total_prompt_tokens INT DEFAULT 0,
                total_completion_tokens INT DEFAULT 0,
                total_tokens INT DEFAULT 0,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user (user_id),
                INDEX idx_key (api_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            // Add gateway columns to existing api_keys table (if missing)
            $gatewayColumns = [
                "is_active" => "TINYINT(1) DEFAULT 1 AFTER status",
                "expires_at" => "DATETIME DEFAULT NULL AFTER status",
                "key_hash" => "VARCHAR(255) DEFAULT NULL AFTER created_at",
                "key_prefix" => "VARCHAR(20) DEFAULT NULL AFTER key_hash",
                "key_suffix" => "VARCHAR(10) DEFAULT NULL AFTER key_prefix",
                "full_key_hash" => "VARCHAR(255) DEFAULT NULL UNIQUE AFTER key_suffix",
                "is_locked" => "TINYINT(1) DEFAULT 0 AFTER full_key_hash",
                "quota_type" => "VARCHAR(20) DEFAULT 'unlimited' AFTER is_locked",
                "quota_value" => "INT DEFAULT 0 AFTER quota_type",
                "quota_used" => "INT DEFAULT 0 AFTER quota_value",
                "quota_reset_at" => "DATETIME NULL AFTER quota_used",
                "rpm_limit" => "INT DEFAULT 0 AFTER quota_reset_at",
                "tpm_limit" => "INT DEFAULT 0 AFTER rpm_limit",
                "last_used_ip" => "VARCHAR(50) NULL AFTER last_used",
                "total_prompt_tokens" => "INT DEFAULT 0 AFTER total_requests",
                "total_completion_tokens" => "INT DEFAULT 0 AFTER total_prompt_tokens",
                "total_tokens" => "INT DEFAULT 0 AFTER total_completion_tokens",
                "updated_at" => "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at",
            ];
            foreach ($gatewayColumns as $col => $def) {
                @$db->query("ALTER TABLE api_keys ADD COLUMN $col $def");
            }

            // Ensure gateway-specific tables exist
            @$db->query("CREATE TABLE IF NOT EXISTS providers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(200) NOT NULL,
                base_url VARCHAR(500) NOT NULL,
                api_key TEXT NOT NULL,
                is_active TINYINT(1) DEFAULT 1,
                timeout INT DEFAULT 120,
                verify_ssl TINYINT(1) DEFAULT 1,
                supports_streaming TINYINT(1) DEFAULT 1,
                health_status VARCHAR(50) DEFAULT 'unknown',
                last_checked DATETIME DEFAULT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            @$db->query("CREATE TABLE IF NOT EXISTS model_mappings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                provider_id INT NOT NULL,
                external_model VARCHAR(200) NOT NULL,
                actual_model VARCHAR(200) NOT NULL,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            @$db->query("CREATE TABLE IF NOT EXISTS request_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                request_id VARCHAR(100) NOT NULL,
                timestamp DATETIME NOT NULL,
                ip_address VARCHAR(50) DEFAULT NULL,
                api_key_id INT DEFAULT NULL,
                api_key_name VARCHAR(200) DEFAULT NULL,
                endpoint VARCHAR(200) NOT NULL,
                method VARCHAR(10) NOT NULL,
                external_model VARCHAR(200) DEFAULT NULL,
                actual_model VARCHAR(200) DEFAULT NULL,
                provider_name VARCHAR(200) DEFAULT NULL,
                latency_ms FLOAT DEFAULT NULL,
                status_code INT NOT NULL,
                prompt_tokens INT DEFAULT 0,
                completion_tokens INT DEFAULT 0,
                total_tokens INT DEFAULT 0,
                error_message TEXT DEFAULT NULL,
                is_streaming TINYINT(1) DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_request_id (request_id),
                INDEX idx_timestamp (timestamp),
                INDEX idx_api_key_id (api_key_id),
                INDEX idx_endpoint (endpoint),
                INDEX idx_status_code (status_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (Exception $e) {
            return null;
        }
    }
    return $db;
}

function isLoggedIn() { return isset($_SESSION['user_id']); }

function getUser() {
    if (!isLoggedIn()) return null;
    try {
        $db = getDB();
        if (!$db) return null;
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        if (!$stmt) return null;
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } catch (Exception $e) { return null; }
}

function isAdmin() {
    // Check user_type from session (set in login.php for both users and admins tables)
    if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin') return true;
    // Also check users table for backward compatibility
    $user = getUser();
    return $user && isset($user['role']) && $user['role'] === 'admin';
}

function requireAdmin() {
    if (!isLoggedIn()) { header('Location: ' . SITE_URL . '/login.php'); exit; }
    if (!isAdmin()) { http_response_code(403); die(json_encode(['error' => 'Admin access required'])); }
}

function generateUUID() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function sanitize($text) { return htmlspecialchars($text ?? '', ENT_QUOTES, 'UTF-8'); }

function formatNumber($num) {
    if ($num >= 1000000) return round($num / 1000000, 1) . 'M';
    if ($num >= 1000) return round($num / 1000, 1) . 'K';
    return number_format($num);
}

function hashPassword($password) { return password_hash($password, PASSWORD_BCRYPT); }
function verifyPassword($password, $hash) { return password_verify($password, $hash); }

function dbQuery($sql) {
    $db = getDB();
    if (!$db) return false;
    $result = $db->query($sql);
    return $result;
}

function getActiveModels() {
    try {
        $result = dbQuery("SELECT * FROM ai_models WHERE is_active = 1 ORDER BY sort_order ASC");
        if (!$result) return [];
        $models = [];
        while ($row = $result->fetch_assoc()) { $models[] = $row; }
        return $models;
    } catch (Exception $e) { return []; }
}

function getModelById($id) {
    $id = intval($id);
    $result = dbQuery("SELECT * FROM ai_models WHERE id = $id AND is_active = 1");
    if (!$result) return null;
    return $result->fetch_assoc();
}

function getSetting($key, $default = '') {
    try {
        $db = getDB();
        if (!$db) return $default;
        $stmt = $db->prepare("SELECT setting_value FROM admin_settings WHERE setting_key = ?");
        if (!$stmt) return $default;
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) return $row['setting_value'];
    } catch (Exception $e) {}
    return $default;
}

function setSetting($key, $value) {
    $db = getDB();
    if (!$db) return false;
    $stmt = $db->prepare("INSERT INTO admin_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    if (!$stmt) return false;
    $stmt->bind_param("sss", $key, $value, $value);
    return $stmt->execute();
}

function updateSetting($key, $value) {
    return setSetting($key, $value);
}

function deductCredits($userId, $amount, $description = '') {
    $db = getDB();
    if (!$db) return false;
    $stmt = $db->prepare("UPDATE users SET credits = credits - ? WHERE id = ? AND credits >= ?");
    if (!$stmt) return false;
    $stmt->bind_param("iii", $amount, $userId, $amount);
    $stmt->execute();
    return $stmt->affected_rows > 0;
}

function generateApiKey() { return 'loc_sk_' . bin2hex(random_bytes(24)); }

function getUserById($id) {
    try {
        $db = getDB();
        if (!$db) return null;
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        if (!$stmt) return null;
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } catch (Exception $e) { return null; }
}

/**
 * Authenticate API key from Bearer token or query param.
 * Checks both user_api_keys and api_keys tables.
 * Returns array with user_id, api_key_id, and user data.
 */
function authenticateApiKey() {
    $apiKey = null;

    // 1. Check Authorization: Bearer header (multiple sources for compatibility)
    $authHeader = '';
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    } elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    } elseif (function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        foreach ($headers as $key => $value) {
            if (strtolower($key) === 'authorization') {
                $authHeader = $value;
                break;
            }
        }
    }

    if (!empty($authHeader) && preg_match('/^Bearer\s+(.+)$/i', $authHeader, $matches)) {
        $apiKey = trim($matches[1]);
    }

    // 2. Check X-API-Key header (alternative)
    if (!$apiKey) {
        $xApikey = $_SERVER['HTTP_X_API_KEY'] ?? ($_SERVER['REDIRECT_HTTP_X_API_KEY'] ?? '');
        if (!empty($xApikey)) {
            $apiKey = trim($xApikey);
        }
    }

    // 3. Check ?api_key= query param
    if (!$apiKey && !empty($_GET['api_key'])) {
        $apiKey = trim($_GET['api_key']);
    }

    if (!$apiKey) return null;

    $db = getDB();
    if (!$db) return null;

    // Hash the key using SHA256 (matches Python's hash_api_key)
    $keyHash = hash('sha256', $apiKey);
    
    // Try api_keys table (shared with Python gateway) - lookup by key_hash
    $stmt = $db->prepare("SELECT ak.id as api_key_id, ak.user_id, ak.key_hash, u.* 
                          FROM api_keys ak 
                          JOIN users u ON u.id = ak.user_id 
                          WHERE ak.key_hash = ? AND ak.is_active = 1 AND u.is_active = 1 
                          LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $keyHash);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            // Update last_used
            @$db->query("UPDATE api_keys SET last_used = NOW() WHERE id = " . intval($row['api_key_id']));
            return $row;
        }
    }
    
    // Fallback: try user_api_keys table (legacy)
    $stmt2 = $db->prepare("SELECT uk.id as api_key_id, uk.user_id, uk.api_key, u.* 
                           FROM user_api_keys uk 
                           JOIN users u ON u.id = uk.user_id 
                           WHERE uk.api_key = ? AND u.is_active = 1 
                           LIMIT 1");
    if ($stmt2) {
        $stmt2->bind_param("s", $apiKey);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        if ($row2 = $result2->fetch_assoc()) {
            @$db->query("UPDATE user_api_keys SET last_used = NOW() WHERE id = " . intval($row2['api_key_id']));
            return $row2;
        }
    }

    return null;
}

function logUsage($userId = null, $apiKeyId = null, $model = '', $provider = '', $requestType = '', $inputTokens = 0, $outputTokens = 0, $estimatedCost = 0, $actualCost = 0, $status = 'success', $responseTimeMs = 0, $ipAddress = '') {
    try {
        $db = getDB();
        if (!$db) return false;
        $stmt = $db->prepare("INSERT INTO usage_logs (user_id, api_key_id, model, provider, request_type, input_tokens, output_tokens, estimated_cost, actual_cost, status, response_time_ms, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) return false;
        $stmt->bind_param("iisssiiidids", $userId, $apiKeyId, $model, $provider, $requestType, $inputTokens, $outputTokens, $estimatedCost, $actualCost, $status, $responseTimeMs, $ipAddress);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    } catch (Exception $e) { return false; }
}

function dbSelectOne($sql, $default = null) {
    $result = dbQuery($sql);
    if (!$result) return $default;
    $row = $result->fetch_assoc();
    return $row ? reset($row) : $default;
}

function getUserCount() { return dbSelectOne("SELECT COUNT(*) as cnt FROM users", 0); }
function getTotalCredits() { return dbSelectOne("SELECT SUM(credits) as total FROM users", 0); }
function getTodayTokens() { return dbSelectOne("SELECT SUM(input_tokens + output_tokens) as total FROM usage_logs WHERE DATE(created_at) = CURDATE()", 0); }

function requireLoginApi() {
    if (!isLoggedIn()) { http_response_code(401); echo json_encode(['error'=>'Unauthorized']); exit; }
}