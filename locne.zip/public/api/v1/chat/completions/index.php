<?php
/**
 * OpenAI-compatible Chat Completions API
 * Endpoint: /api/v1/chat/completions
 * 
 * This PHP endpoint authenticates the API key, 
 * then proxies the request to the Python AI Gateway on port 8000.
 * The Python gateway handles: provider selection, credit check,
 * credit deduction, and streaming.
 * 
 * Usage with OpenAI SDK:
 *   from openai import OpenAI
 *   client = OpenAI(api_key="loc_sk_...", base_url="https://your-server.com/api/v1")
 *   response = client.chat.completions.create(model="model-id", messages=[...])
 */

error_reporting(0);
ini_set('display_errors', 0);

while (ob_get_level()) { ob_end_clean(); }

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => ['message' => 'Method not allowed. Use POST.', 'type' => 'invalid_request_error', 'code' => 'method_not_allowed']]);
    exit;
}

require_once __DIR__ . '/../../../../config/database.php';
require_once __DIR__ . '/../../../../config/functions.php';

// Authenticate
$apiUser = authenticateApiKey();
if (!$apiUser) {
    http_response_code(401);
    echo json_encode([
        'error' => [
            'message' => 'Invalid API key. Provide via Authorization: Bearer <key> or ?api_key=<key>',
            'type' => 'authentication_error',
            'code' => 'invalid_api_key'
        ]
    ]);
    exit;
}

$userId  = $apiUser['user_id'] ?? $apiUser['id'];
$apiKeyId = $apiUser['api_key_id'] ?? null;

// Extract API key
$apiKey = null;
$authHeader = '';
if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
} elseif (function_exists('apache_request_headers')) {
    $headers = apache_request_headers();
    foreach ($headers as $key => $value) {
        if (strtolower($key) === 'authorization') {
            $authHeader = $value;
            break;
        }
    }
}
if (!empty($authHeader) && preg_match('/^Bearer\s+(.+)$/i', $authHeader, $matches)) {
    $apiKey = trim($matches[1]);
}
if (!$apiKey) {
    $xApikey = $_SERVER['HTTP_X_API_KEY'] ?? ($_SERVER['REDIRECT_HTTP_X_API_KEY'] ?? '');
    if (!empty($xApikey)) $apiKey = trim($xApikey);
}
if (!$apiKey && !empty($_GET['api_key'])) {
    $apiKey = trim($_GET['api_key']);
}
if (!$apiKey) {
    http_response_code(401);
    echo json_encode(['error' => ['message' => 'Missing API key.', 'type' => 'authentication_error', 'code' => 'missing_api_key']]);
    exit;
}

// Parse request
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !is_array($input)) {
    http_response_code(400);
    echo json_encode(['error' => ['message' => 'Invalid JSON body.', 'type' => 'invalid_request_error', 'code' => 'invalid_json']]);
    exit;
}

if (empty($input['messages']) || !is_array($input['messages'])) {
    http_response_code(400);
    echo json_encode(['error' => ['message' => 'Missing required field: messages', 'type' => 'invalid_request_error', 'code' => 'missing_messages']]);
    exit;
}

$stream = !empty($input['stream']);

// Gateway URL
// Docker: http://ai-gateway:8000  |  bare-metal Ubuntu: http://localhost:8000
$gatewayUrl = getSetting('gateway_url', '');
if (empty($gatewayUrl)) {
    $gatewayUrl = getenv('GATEWAY_URL') ?: 'http://ai-gateway:8000';
    if (!@fsockopen('ai-gateway', 8000, $errno, $errstr, 1)) {
        $gatewayUrl = 'http://localhost:8000';
    }
    setSetting('gateway_url', $gatewayUrl);
}
$gatewayUrl = rtrim($gatewayUrl, '/');

$payload = json_encode($input);

if ($stream) {
    // ── STREAMING (SSE) ──
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL           => $gatewayUrl . '/v1/chat/completions',
        CURLOPT_RETURNTRANSFER=> false,
        CURLOPT_POST          => true,
        CURLOPT_POSTFIELDS    => $payload,
        CURLOPT_HTTPHEADER    => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'Accept: text/event-stream'
        ],
        CURLOPT_TIMEOUT       => 300,
        CURLOPT_CONNECTTIMEOUT=> 15,
        CURLOPT_WRITEFUNCTION => function($ch, $data) {
            echo $data;
            if (ob_get_level()) ob_flush();
            flush();
            return strlen($data);
        }
    ]);
    curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        echo "data: " . json_encode(['error' => ['message' => 'Cannot connect to AI gateway: ' . $error, 'type' => 'server_error']]) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
        exit;
    }

} else {
    // ── NON-STREAMING ──
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL           => $gatewayUrl . '/v1/chat/completions',
        CURLOPT_RETURNTRANSFER=> true,
        CURLOPT_POST          => true,
        CURLOPT_POSTFIELDS    => $payload,
        CURLOPT_HTTPHEADER    => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey
        ],
        CURLOPT_TIMEOUT       => 300,
        CURLOPT_CONNECTTIMEOUT=> 15,
        CURLOPT_SSL_VERIFYPEER=> false,
        CURLOPT_SSL_VERIFYHOST=> 0
    ]);

    $result      = curl_exec($ch);
    $httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $error       = curl_error($ch);
    curl_close($ch);

    if ($error) {
        http_response_code(502);
        echo json_encode(['error' => ['message' => 'Cannot connect to AI gateway: ' . $error, 'type' => 'server_error', 'code' => 'gateway_error']]);
        exit;
    }

    http_response_code($httpCode);
    if ($contentType) {
        header('Content-Type: ' . $contentType);
    }
    echo $result;
}