<?php
/**
 * Chat API - Proxy requests to Python AI Gateway (port 8000)
 * Translates between frontend format and OpenAI-compatible gateway format.
 * 
 * Frontend SSE format: data: {"delta":"text"} / data: {"done":true,"credits_remaining":N}
 * Gateway SSE format:  data: {"choices":[{"delta":{"content":"text"}}]} / data: {"usage":...}
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Read input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || (empty($input['message']) && empty($input['images']) && empty($input['files']))) {
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode(['error' => 'Message or files required']);
    exit;
}

$message   = $input['message'] ?? '';
$modelId   = $input['model_id'] ?? null;
$sessionId = $input['session_id'] ?? generateUUID();
$stream    = isset($input['stream']) ? (bool)$input['stream'] : true;
$images    = $input['images'] ?? [];
$files     = $input['files'] ?? [];

// ============ GET MODEL INFO ============
$modelName      = 'gpt-3.5-turbo';
$modelType      = 'chat';
$providerName   = '';
$apiKeyOverride = null;

if ($modelId) {
    $db2 = getDB();
    if ($db2) {
        $modelStmt = $db2->prepare("SELECT name, type, provider, api_key FROM ai_models WHERE id = ? AND is_active = 1");
        if ($modelStmt) {
            $modelStmt->bind_param("i", $modelId);
            $modelStmt->execute();
            $modelResult = $modelStmt->get_result();
            if ($modelRow = $modelResult->fetch_assoc()) {
                $modelName      = $modelRow['name'] ?: $modelName;
                $modelType      = $modelRow['type'] ?: 'chat';
                $providerName   = $modelRow['provider'] ?? '';
                $apiKeyOverride = $modelRow['api_key'] ?? null;
            }
        }
    }
}

// ============ AUTHENTICATION ============
$user = getCurrentUser();
$apiKey = null;
$keyId   = null;
$creditsRemaining = 999999;

if ($user) {
    $db = getDB();
    if ($db) {
        $stmt = $db->prepare("SELECT id, api_key, quota_used, quota_value, quota_type FROM api_keys WHERE user_id = ? AND is_locked = 0 ORDER BY id DESC LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("i", $user['id']);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $apiKey = $row['api_key'];
                $keyId  = $row['id'];
                
                if ($row['quota_type'] !== 'unlimited' && $row['quota_value'] > 0) {
                    if ($row['quota_used'] >= $row['quota_value']) {
                        header('Content-Type: application/json');
                        http_response_code(429);
                        echo json_encode(['error' => 'Quota exceeded for this key']);
                        exit;
                    }
                }
            }
        }
        
        $creditStmt = $db->prepare("SELECT credits FROM users WHERE id = ?");
        if ($creditStmt) {
            $creditStmt->bind_param("i", $user['id']);
            $creditStmt->execute();
            $creditResult = $creditStmt->get_result();
            if ($creditRow = $creditResult->fetch_assoc()) {
                $creditsRemaining = (int)$creditRow['credits'];
            }
        }
        
        if ($creditsRemaining <= 0) {
            header('Content-Type: application/json');
            http_response_code(402);
            echo json_encode(['error' => 'Insufficient credits']);
            exit;
        }
    }
}

// ============ BUILD GATEWAY REQUEST ============
$gatewayUrl = rtrim(getenv('GATEWAY_URL') ?: 'http://localhost:8000', '/');

$content = $message;
if (!empty($images)) {
    $contentParts = [['type' => 'text', 'text' => $message ?: 'Describe this image']];
    foreach ($images as $imgUrl) {
        $contentParts[] = ['type' => 'image_url', 'image_url' => ['url' => $imgUrl]];
    }
    $content = $contentParts;
}

$gatewayPayload = [
    'model'    => $modelName,
    'messages' => [['role' => 'user', 'content' => $content]],
    'stream'   => $stream,
];

$headers = ['Content-Type: application/json'];
if ($apiKey) {
    $headers[] = 'Authorization: Bearer ' . $apiKey;
}

// ============ SET SSE HEADERS FOR STREAMING ============
if ($stream) {
    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');
    header('Access-Control-Allow-Origin: *');
}

// ============ SEND TO GATEWAY ============
$ch = curl_init($gatewayUrl . '/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($gatewayPayload),
    CURLOPT_HTTPHEADER     => $headers,
    CURLOPT_TIMEOUT        => 300,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => false,
]);

$responseContent  = '';
$totalTokens      = 0;
$promptTokens     = 0;
$completionTokens = 0;

if ($stream) {
    $buffer = '';
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) use (&$buffer, &$responseContent, &$promptTokens, &$completionTokens, &$totalTokens) {
        $buffer .= $data;
        $lines = explode("\n", $buffer);
        // Keep last incomplete line in buffer
        $buffer = array_pop($lines);
        if (!str_ends_with($data, "\n")) {
            // Last chunk may be incomplete
        }
        
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || !str_starts_with($line, 'data: ')) continue;
            
            $jsonStr = substr($line, 6);
            if ($jsonStr === '[DONE]') continue;
            
            $parsed = json_decode($jsonStr, true);
            if (!$parsed) continue;
            
            // Extract delta content
            $delta = $parsed['choices'][0]['delta']['content'] ?? '';
            if ($delta !== '') {
                $responseContent .= $delta;
                // Send in frontend format: { delta: "text" }
                echo "data: " . json_encode(['delta' => $delta]) . "\n\n";
            }
            
            // Track usage from final chunk
            if (isset($parsed['usage'])) {
                $promptTokens     = $parsed['usage']['prompt_tokens'] ?? 0;
                $completionTokens = $parsed['usage']['completion_tokens'] ?? 0;
                $totalTokens      = $parsed['usage']['total_tokens'] ?? ($promptTokens + $completionTokens);
            }
        }
        
        if (ob_get_level()) ob_flush();
        flush();
        return strlen($data);
    });
} else {
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    header('Content-Type: application/json');
}

$startTime = microtime(true);
$response  = curl_exec($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);
$responseTimeMs = round((microtime(true) - $startTime) * 1000);

// ============ HANDLE NON-STREAMING RESPONSE ============
if (!$stream) {
    if ($curlError) {
        http_response_code(502);
        echo json_encode(['error' => 'Gateway error: ' . $curlError]);
        exit;
    }
    
    $respData = json_decode($response, true);
    
    if ($httpCode !== 200 || !$respData) {
        http_response_code($httpCode ?: 502);
        echo $response ?: json_encode(['error' => 'Bad gateway response']);
        exit;
    }
    
    // Extract
    $responseContent  = $respData['choices'][0]['message']['content'] ?? '';
    $promptTokens     = $respData['usage']['prompt_tokens'] ?? 0;
    $completionTokens = $respData['usage']['completion_tokens'] ?? 0;
    $totalTokens      = $respData['usage']['total_tokens'] ?? ($promptTokens + $completionTokens);
    
    echo json_encode([
        'content'  => $responseContent,
        'usage'    => ['prompt_tokens' => $promptTokens, 'completion_tokens' => $completionTokens, 'total_tokens' => $totalTokens]
    ]);
}

// ============ UPDATE CREDITS & LOG ============
$creditsToDeduct = 0;
if ($totalTokens > 0 && $user) {
    $costPer1K = 0.002;
    if (stripos($modelName, 'gpt-4') !== false) $costPer1K = 0.03;
    if (stripos($modelName, 'claude') !== false) $costPer1K = 0.015;
    if (stripos($modelName, 'gemini') !== false) $costPer1K = 0.001;
    
    $estimatedCost = ($totalTokens / 1000) * $costPer1K;
    $creditsToDeduct = max(1, (int)ceil($estimatedCost * 1000));
    
    $db3 = getDB();
    if ($db3) {
        $uid = (int)$user['id'];
        $db3->query("UPDATE users SET credits = GREATEST(0, credits - $creditsToDeduct) WHERE id = $uid");
        $creditsRemaining = max(0, $creditsRemaining - $creditsToDeduct);
        
        if ($keyId) {
            $kid = (int)$keyId;
            $ip = $db3->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
            $db3->query("UPDATE api_keys SET 
                total_requests = total_requests + 1,
                total_tokens = total_tokens + $totalTokens,
                total_prompt_tokens = total_prompt_tokens + $promptTokens,
                total_completion_tokens = total_completion_tokens + $completionTokens,
                quota_used = quota_used + $creditsToDeduct,
                last_used = NOW(),
                last_used_ip = '$ip'
                WHERE id = $kid");
        }
        
        // Save chat history
        saveChatMsg($user['id'], $sessionId, $modelId, 'user', $message, 0, 0, 0, 0);
        if ($responseContent) {
            saveChatMsg($user['id'], $sessionId, $modelId, 'assistant', $responseContent, $promptTokens, $completionTokens, $totalTokens, $responseTimeMs);
        }
        
        // Log usage
        logUsage($user['id'], $keyId, $modelName, $providerName, 'chat', $promptTokens, $completionTokens, round($estimatedCost, 6), round($estimatedCost, 6), 'success', $responseTimeMs, $_SERVER['REMOTE_ADDR'] ?? '');
    }
}

// ============ SEND FINAL SSE EVENT WITH CREDITS ============
if ($stream) {
    $finalData = [
        'done'              => true,
        'credits_remaining' => (int)$creditsRemaining,
        'tokens_used'       => $totalTokens,
        'credits_deducted'  => $creditsToDeduct
    ];
    echo "data: " . json_encode($finalData) . "\n\n";
    if (ob_get_level()) ob_flush();
    flush();
}

// ============ HELPERS ============
function getCurrentUser() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!empty($_SESSION['user_id'])) {
        return ['id' => $_SESSION['user_id'], 'username' => $_SESSION['username'] ?? '', 'email' => $_SESSION['email'] ?? ''];
    }
    return null;
}

function saveChatMsg($userId, $sessionId, $modelId, $role, $content, $pT, $cT, $tT, $rt) {
    $db = getDB();
    if (!$db) return;
    $stmt = $db->prepare("INSERT INTO chat_history (user_id, session_id, model_id, role, content, tokens_prompt, tokens_completion, tokens_total, response_time_ms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isisiiiii", $userId, $sessionId, $modelId, $role, $content, $pT, $cT, $tT, $rt);
        $stmt->execute();
    }
}